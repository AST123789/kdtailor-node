import React, { useEffect, useState } from 'react'
import { Link,useHistory } from 'react-router-dom';
import { GarmentColorData } from '../Function/GarmentColor';

function DryCleaningColors() {

    const [garmentcolorlist , setgarmentcolorlist] = useState([]);
    const history = useHistory()
    
    useEffect(()=>{
       if(!(localStorage.getItem("username")))
       {
        history.push('/')
       }
       else
       { 
              loadGarment()
       }
       },[])

    const loadGarment=()=>{
       GarmentColorData().then(res=>{
              const result = res;
              if(result!==undefined){
                     if(result.data == null){
                            setgarmentcolorlist([]);
                     }else{
                            setgarmentcolorlist(result.data);
                     }
              }else{
                     setgarmentcolorlist([]);
              }
       }).catch();
    }

    const GarmentColorCode=(colorName,colorCode)=>{
       localStorage.setItem('garmentcolor',colorName)
       localStorage.setItem('colorcode',colorCode)
       window.$('#drycolorModal').modal("hide")
       history.push("/GarmentType")
    }
    
    return (
        <>  
           <div className="modal" id="drycolorModal">
          <div className="modal-dialog">
            <div className="modal-content">
            
              {/* Modal Header */}
              <div className="modal-header">
                <h4 className="modal-title">Garment Colors</h4>
                <button type="button" className="close" data-dismiss="modal">&times;</button>
              </div>
              
              {/* Modal body */}
              <div className="modal-body">
                     <div style={{paddingTop:'20px',marginLeft:'20px',marginRight:'20px'}}>
                     {
                     garmentcolorlist.map((data)=>{
                            return(
                                   <Link to='/DryServices' onClick={()=>GarmentColorCode(data.color_name,data.color_code)}> 
                                          <div className="col-md-3 socail_grid_agile facebo"
                                          style={data.color_code==='#FFFF00'||data.color_code==='#FFFDD0'||data.color_code==='#FFC0CB'||data.color_code==='#e3dac9'||data.color_code==='#F0FFFF'?
                                          {backgroundColor:data.color_code,color:'#000' }:{backgroundColor:data.color_code}}>
                                                 {data.color_name}
                                          </div>
                                   </Link>
                            )
                     })
                     }
                     </div>
              </div>
              
              {/* Modal footer */}
              <div className="modal-footer">
                <button type="button"  onClick={(e)=>localStorage.setItem("number",Number(localStorage.getItem("number"))-1)} className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
              </div>
              
            </div>
          </div>
        </div>
        </>
    )
}

export default DryCleaningColors
