import React, { useEffect, useState } from 'react'
import { useHistory } from 'react-router'
import { SelectGarmentList, UpdatePriceData } from '../Function/Garment'


function PriceChange({chang}) {
    const history = useHistory()
    const [discountcash , setcash] = useState(0)
    const [sum , setsum] = useState('')
    const [garmentlist,setgarmentlist] = useState([]) 
    const [garmentdiscount,setgarmentdiscount] = useState('')
    useEffect(()=>{
        if(!(localStorage.getItem("username"))){
            history.push('/')
            
        }else{
            loadGarmentList()
            setsum(localStorage.getItem('garmentsumprice'))
        }
    },[])

    const loadGarmentList = ()=>{
        SelectGarmentList().then(res=>{
            const result = res;
            if(result !== undefined){
               if(result.data == null){
                  setgarmentlist([]);
               }else{
                  setgarmentlist(result.data);
               }
            }else{
               setgarmentlist([]);
            }
         }).catch();
    }
     
    const discount = (e) =>{
        e.preventDefault()
        garmentlist.forEach(function (elem) {   
            var req = {
                "garmentlistid":elem.garmentlistid,
                "garmentdiscount":Number(elem.garmentchildprice*garmentdiscount/100),
                "garmentfinalamount":parseFloat(Number(elem.garmentchildprice-elem.garmentchildprice*garmentdiscount/100)).toFixed(2)
            }
            UpdatePriceData(req).then(res=>{
                
            });
        });
        localStorage.setItem("discount",discountcash)
        chang()
    }

    return (
        <>
            <div className="modal" id="priceChange">
                <div className="modal-dialog" style={{textAlign:'center'}}>
                    <div className="modal-content" style={{width:'600px'}}>
                    
                        {/* Modal Header */}
                        <div className="modal-header">
                            <h4 className="modal-title" style={{fontWeight:'bold'}}></h4>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                        </div>
                    
                                {/* Modal body */}
                        <div className="modal-body">
                            <div className="wthree_general">
                                <div className="grid-1 graph-form agile_info_shadow">
                                    <form className="form-horizontal">
                                        <div className="form-group">
                                        </div> 
                                        <div className="form-group">
                                            <label className="col-md-4 control-label">Discount Percentage</label>
                                            <div className="col-md-4">
                                                <div className="input-group">							
                                                    <span className="input-group-addon">
                                                        <i className="fa fa-money"></i>
                                                    </span>
                                                    <input type="text"  style={{fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" onChange={(e)=>{setcash(e.target.value*localStorage.getItem('garmentsumprice')/100);setsum(localStorage.getItem('garmentsumprice')-e.target.value);setgarmentdiscount(e.target.value)}}/>
                                                </div>
                                            </div>
                                        </div>
                                    </form>                                                
                                </div>
                            </div>
                            <div className="wthree_general">                                                                                                                  
                                <div className="grid-1 graph-form agile_info_shadow">    
                                    <form className="form-horizontal">
                                        <div className="form-group">
                                            <label className="col-md-4 control-label" style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Balance</label>
                                                <div className="col-md-4">
                                                    <div className="input-group">							
                                                        <span className="input-group-addon">
                                                            <i className="fa fa-money"></i>
                                                        </span>
                                                        <input type="text" style={{color:'black',fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" readOnly value={parseFloat(localStorage.getItem('garmentsumprice')).toFixed(2)}/>
                                                    </div>
                                                </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="col-md-4 control-label" style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Total Tendered</label>
                                            <div className="col-md-4">
                                                <div className="input-group">
                                                    <span className="input-group-addon">
                                                        <i className="fa fa-money"></i>
                                                    </span>
                                                    <input type="text" style={{color:'black',fontWeight:'bold',fontSize:'20px'}} readOnly className="form-control1 icon" id="exampleInputPassword1" value={parseFloat(discountcash).toFixed(2)}/>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="col-md-4 control-label"style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Total Due</label>
                                            <div className="col-md-4">
                                                <div className="input-group input-icon right">
                                                    <span className="input-group-addon">
                                                        <i className="fa fa-money"></i>
                                                    </span>
                                                    <input id="text"  style={{color:'black',fontWeight:'bold',fontSize:'20px'}}  readOnly className="form-control1 icon" type="text" value={parseFloat(localStorage.getItem('garmentsumprice')-discountcash).toFixed(2)}/>
                                                </div>
                                            </div>                                               
                                        </div>          
                                    </form>                              
                                </div>
                            </div>
                        </div>
                            {/* Modal footer */}
                        <div className="modal-footer">
                            <button type="button" onClick={(e)=>discount(e) } className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal"   >Ok</button>
                            <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
                        </div>
                    
                    </div>
                </div>
            </div>
        </>
    )
}

export default PriceChange
