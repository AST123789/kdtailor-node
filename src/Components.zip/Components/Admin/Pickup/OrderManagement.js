import React, { useEffect } from 'react'
import { Link,useHistory } from 'react-router-dom'
import { useState } from 'react/cjs/react.development'
import { Selectorder, Updateorder } from '../../Function/Order'
import moment from 'moment';

export default function OrderManagement() {

    const [loadorderlist , setloadorderlist] = useState([])
    const [checkid , setcheckid] = useState([])
    const history = useHistory()
    const d = new Date()

    useEffect(()=>{
        if(!(localStorage.getItem("managementUsername"))){
            history.push('/')
        }
            loadOrderData()        
    },[])

    const loadOrderData = () =>{
        Selectorder().then((res)=>{
            const result = res;
            if(result!==undefined){
                if(result===null){
                    setloadorderlist([])
                }else{
                    setTimeout(function(){
                        setloadorderlist(result.data)
                    },1000)
                }
            }else{
                setloadorderlist([])
            }
        }).catch();
    }

    const checkfun = (id)=>{
        const array = checkid
        var c = 0
        for(var x=checkid.length;  x>=0; x--){
            if(checkid[x]===id){
                c=c+1
                break
            }
        
        }

        if(c==1){
            const s = arrayRemove(array,id)
            setcheckid(s)
            alert(`Removed list ${s}`)
        }
        else{
            array.push(id)
            setcheckid(array)
        }

    }
    
    function arrayRemove(arr, value) {
 
        return arr.filter(function(geeks){
            return geeks != value;
        });
      
     }

     const ChangeStatus = (e,status)=>{
         e.preventDefault()
         for(var x=0; x<checkid.length;x++){
            // alert(checkid.join());
            var req={
                "orderid":checkid.join(),
                "status":status
            }

            Updateorder(req).then((res)=>{
                const result = res;
                if(result!==undefined){
                    // alert(result.message)
                }
            }).catch();           
        }
        setcheckid([])
        setloadorderlist([])
        
        setTimeout(()=>{
            loadOrderData()
        },1000) 
        }

    const logout = ()=>{
        localStorage.removeItem('managementUsername')
        
        history.push('/')
    }

    return (
        <>
        <div style={{textAlign:'right',marginTop:'15px' }}><Link to="#" onClick={(e)=>logout()} style={{backgroundColor:'grey',padding:'15px',color:'white',fontWeight:'bold',fontSize:'20px'}}>LogOut </Link></div>
        <br></br>
        <div className="w3l-table-info agile_info_shadow">
            <div>
                <Link type="button" className="btn btn-warning" onClick={(e)=>ChangeStatus(e,"start")} to='#'>Start</Link>
                <Link type="button" className="btn btn-danger"  onClick={(e)=>ChangeStatus(e,"stop")} style={{marginLeft:'10px',marginRight:'10px'}} to='#'>Cancel Start</Link>
                <Link type="button" className="btn btn-success"  onClick={(e)=>ChangeStatus(e,"complete")} to='#'>Complete</Link>
            </div>    
            <table id="table">
                <thead>
                    <tr>
                        <th></th>
                        <th>Customer Name</th>
                        <th>Order Id</th>
                        <th>Details</th>
                        <th>Due Date</th>
                        <th>Instructions</th>
                        <th>Status</th>
                        {/* <th>Due Amount</th> */}
                    </tr>
                </thead>
                <tbody>
                    {
                    loadorderlist?
                    loadorderlist.length>0?loadorderlist.map((data)=>{
                            const d1 = new Date(moment(data.pickupdate).format("DD-MM-yyyy"))
                            const d2 = new Date(moment(d).format("MM-DD-YYYY"))
                            return(
                                <tr>
                                    <td style={data.status===null || data.status==='stop'?d1.getTime()<d2.getTime()?{backgroundColor:'red',color:'white',fontSize:'15px'}:
                                    data.pickupdate==moment(d).format("DD-MM-YYYY")?{backgroundColor:'yellow',color:'black',fontSize:'15px'}:
                                    {backgroundColor:'green',color:'white',fontSize:'15px'}:
                                    data.status==='start'?{backgroundColor:'#ADD8E6',color:'#000',fontSize:'15px'}:{display:'none',color:'white',fontSize:'15px'}}><input value={data.order_id} onChange={()=>checkfun(data.order_id)} type="checkbox"/></td>
                                    
                                    <td  style={data.status===null || data.status==='stop'?d1.getTime()<d2.getTime()?{backgroundColor:'red',color:'white',fontSize:'15px',fontWeight:'bold'}:
                                    data.pickupdate===moment(d).format("DD-MM-YYYY")?{backgroundColor:'yellow',color:'black',fontSize:'15px',fontWeight:'bold'}:
                                    {backgroundColor:'green',color:'white',fontSize:'15px',fontWeight:'bold'}:
                                    data.status==='start'?{backgroundColor:'#ADD8E6',color:'#000',fontSize:'15px'}:{display:'none',color:'white',fontSize:'15px',fontWeight:'bold'}}>{data.customername}</td>

                                    <td style={data.status===null || data.status==='stop'?d1.getTime()<d2.getTime()?{backgroundColor:'red',color:'white',fontSize:'15px'}:
                                    data.pickupdate===moment(d).format("DD-MM-YYYY")?{backgroundColor:'yellow',color:'black',fontSize:'15px'}:
                                    {backgroundColor:'green',color:'white',fontSize:'15px'}:
                                    data.status==='start'?{backgroundColor:'#ADD8E6',color:'#000',fontSize:'15px'}:{display:'none',color:'white',fontSize:'15px'}}>{data.orderid}</td>
                                    
                                    <td  style={data.status===null || data.status==='stop'?d1.getTime()<d2.getTime()?{backgroundColor:'red',color:'white',fontSize:'15px'}:
                                    data.pickupdate===moment(d).format("DD-MM-YYYY")?{backgroundColor:'yellow',color:'black',fontSize:'15px'}:
                                    {backgroundColor:'green',color:'white',fontSize:'15px'}:
                                    data.status==='start'?{backgroundColor:'#ADD8E6',color:'#000',fontSize:'15px'}:{display:'none',color:'white',fontSize:'15px'}}>{data.garmentname}<br></br>{data.garmentmiddlename} <br></br>{data.garmentchildname}</td>
                                    
                                    <td style={data.status===null || data.status==='stop'?d1.getTime()<d2.getTime()?{backgroundColor:'red',color:'white',fontSize:'15px'}:
                                    data.pickupdate===moment(d).format("DD-MM-YYYY")?{backgroundColor:'yellow',color:'black',fontSize:'15px'}:
                                    {backgroundColor:'green',color:'white',fontSize:'15px'}:
                                    data.status==='start'?{backgroundColor:'#ADD8E6',color:'#000',fontSize:'15px'}:{display:'none',color:'white',fontSize:'15px'}}>{data.pickupdate} {data.pickupday} {data.pickuptime}</td>
                                    
                                    <td style={data.status===null || data.status==='stop'?d1.getTime()<d2.getTime()?{backgroundColor:'red',color:'white',fontSize:'15px'}:
                                    data.pickupdate===moment(d).format("DD-MM-YYYY")?{backgroundColor:'yellow',color:'black',fontSize:'15px'}:
                                    {backgroundColor:'green',color:'white',fontSize:'15px'}:
                                    data.status==='start'?{backgroundColor:'#ADD8E6',color:'#000',fontSize:'15px'}:{display:'none',color:'white',fontSize:'15px'}}>Garment 1 of 1 /<br></br> Service: 1 of 1 grey</td>
                                    
                                    <td  style={data.status===null || data.status==='stop'?d1.getTime()<d2.getTime()?{backgroundColor:'red',color:'white',fontSize:'15px'}:
                                    data.pickupdate===moment(d).format("DD-MM-YYYY")?{backgroundColor:'yellow',color:'black',fontSize:'15px'}:
                                    {backgroundColor:'green',color:'white',fontSize:'15px'}:
                                    data.status==='start'?{backgroundColor:'#ADD8E6',color:'#000',fontSize:'15px'}:{display:'none',color:'white',fontSize:'15px'}}></td>
                                </tr>
                            )
                    }):<div><img src="loader.gif" alt="loader"/></div>:null
                    }
                </tbody>
            </table>
        </div>
        </>
    )
}
