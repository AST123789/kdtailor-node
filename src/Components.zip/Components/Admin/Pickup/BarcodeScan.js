import React, { useEffect, useState } from 'react'
import { Link,useHistory } from 'react-router-dom';
import { ReceiptServices } from '../../Function/Receipt';
import BarcodeNumber from '../wcommon/BarcodeNumber';
import PayPayment from './PayPayment';

function BarcodeScan() {
  const [id,setid] = useState("")
  const [receiptdata , setreceiptdata] = useState([])
  const [check,setcheck] = useState(0)
  const [ticketid,setticketid] = useState("")
  const history = useHistory()
  
  useEffect(()=>{
    if(!(localStorage.getItem("username"))){
        history.push('/')
        
    }else{
            var barcode = '';
            var interval;
            document.addEventListener('keydown', function(evt) {
                if (interval)
                    clearInterval(interval);
                if (evt.code == 'Enter') {
                    if (barcode)
                        handleBarcode(barcode);
                    barcode = '';
                    return;
                }
                if (evt.key != 'Shift')
                    barcode += evt.key;
                interval = setInterval(() => barcode = '', 20);
            });

            function handleBarcode(scanned_barcode) {
                setid(scanned_barcode)
                localStorage.setItem("scannedid",scanned_barcode)
                loadReceiptData(scanned_barcode)
                
            }
        }
  },[Number(localStorage.getItem("check"))])

  const loadReceiptData = (paymentid) =>{
    localStorage.setItem("scannedid",paymentid)
    ReceiptServices(paymentid).then(res=>{
        const result = res;
        if(result!==undefined){
            if(result==null){
                setreceiptdata([])
            }else{
                setreceiptdata(result.data)
                localStorage.setItem("payeddueamount",(result.data)[0].dueamount) 
                if(result.data[0].paymentstatus === 'Picked Up')
                {
                    alert("This Services Has Been Picked Up")
                    
                }else{
                    
                    setcheck(1)
                }
               
            }
        }else{
            setreceiptdata([])
        }
    }).catch();
}

  if(check=== 0 ){
    return (<div style={{textAlign:'center',marginTop:'15em'}}>
        <img style={{width:'200px',top:'500px'}} src="barcode-image.png"/>
        <br></br><h4>Please Scan QR Code</h4>
        {/* <br></br><input type="text" placeholder="Input Order Id"/> */}
        <br></br><Link className="button" to="#" data-toggle="modal" data-target="#barcodemodal" style={{padding:'10px',fontSize:'15px' , color:'white',marginRight:"10px"}}>Search</Link>
        <Link className="button" to="/afterSign" style={{padding:'10px',fontSize:'15px' , color:'white'}}>Back</Link>
        <div className="modal" id="barcodemodal">
          <div className="modal-dialog">
            <div className="modal-content">
            
              {/* Modal Header */}
              <div className="modal-header">
                <h4 className="modal-title">Enter Ticket Number</h4>
                <button type="button" className="close" data-dismiss="modal">&times;</button>
              </div>
              
              {/* Modal body */}
              <div className="modal-body">
              <div className="inner_content" style={{padding:'0rem'}}>
				    {/* /inner_content_w3_agile_info*/}
					{/* <div className="inner_content_w3_agile_info">
                    <div className="registration admin_agile"> */}
                        
                        <div className="signin-form profile admin" style={{width:"100%"}}>
                            
                            {/* <h2>Enter Ticket Number</h2> */}
                            <div className="login-form">
                                <form method="post">
                                    <input type="text" name="name" value={ticketid} onChange={(e)=>setticketid(e.target.value)} placeholder="Ticket Id" required=""/>
                                    <Link data-dismiss="modal" to="#" onClick={(e)=>loadReceiptData(ticketid)} style={{color:'#fff'}} ><div className="tp login_button">
                                            Search 
                                    </div></Link>
                                    
                                </form>
                            </div>
                        
                        {/* </div>
                    </div> */}
					{/* //inner_content_w3_agile_info*/}
				</div>
		{/* //inner_content*/}
				</div>
              </div>
              
              {/* Modal footer */}
              <div className="modal-footer">
                <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
              </div>
              
            </div>
          </div>
        </div>
    </div>)
  }

  return (
    <div className="w3l-table-info agile_info_shadow">
        <table id="table">
            <thead>
                <tr>
                    
                    <th>Customer Name</th>
                    <th>Order</th>
                    <th>Description</th>
                    <th>Due Date</th>
                    <th>Details</th>
                    <th>Instructions</th>
                    <th>Status</th>
                    {/* <th>Due Amount</th> */}
                </tr>
            </thead>
            <tbody>
                {
                    receiptdata?
                    receiptdata.length>0?
                    receiptdata.map((data)=>{
                    return(
                        <tr>
                        
                        <td>{data.customername}</td>
                        <td>{data.orderid}</td>
                        <td>{data.garmentname}<br></br>{data.garmentmiddlename}<br></br>{data.garmentchildname}</td>
                        <td>{data.pickupdate}</td>
                        <td>Garment 1 of 1 /<br></br> Service: 1 of 1 grey</td>
                        <td></td>
                        <td>{data.status}</td>
                        {/* <td> </td> */}
                        </tr>
                    )
                    })
                    :<div>Data not found</div>
                    :<div>Data not found</div>
                }
            </tbody>
        </table>
        <div style={{fontSize:'24px',fontFamily:'sans-serif',fontWeight:'bold',textAlign:'right'}}>DUE AMOUNT : $ {parseFloat(receiptdata[0].dueamount).toFixed(2)}    
        <button  className="btn btn-info" style={{marginLeft:'20px',background:'#000'}}  data-toggle="modal" data-target="#payment">Pay Amount</button>
        <Link to="afterSign" className="btn btn-info" style={{marginLeft:'20px',background:'#000'}} >Cancel</Link></div>
        <PayPayment/>
    </div>
  )
}

export default BarcodeScan