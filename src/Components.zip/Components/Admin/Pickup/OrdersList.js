import React from 'react'

export default function OrdersList() {
    return (
        <div className="w3l-table-info agile_info_shadow">
        <table id="table">
            <thead>
                <tr>
                    <th></th>
                    <th>Customer Name</th>
                    <th>Order</th>
                    <th>Description</th>
                    <th>Due Date</th>
                    <th>Details</th>
                    <th>Instructions</th>
                    <th>Status</th>
                    <th>Due Amount</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><input type="checkbox"/></td>
                    <td>Abhishek Goyal</td>
                    <td>1234567</td>
                    <td>DRESS-NORM-CAUSEL-<br></br>LINNING/SHORTEN <br></br>drs-shorten from waistno zip</td>
                    <td>FRI 30/07/2021 <br></br>1:00 PM</td>
                    <td>Garment 1 of 1 /<br></br> Service: 1 of 1 grey</td>
                    <td></td>
                    <td></td>
                    <td style={{fontSize:'24px',fontFamily:'sans-serif',fontWeight:'bold'}}>$25</td>
                </tr>
            </tbody>
        </table>
    </div>
    )
}
