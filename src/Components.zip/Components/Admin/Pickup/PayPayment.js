import React,{useEffect, useState} from 'react'
import { useHistory } from 'react-router'
import { Updatepayment } from '../../Function/Payment'
import { ReceiptServices } from '../../Function/Receipt'
import moment from 'moment'

function PayPayment() {

    const history = useHistory()
    const [cash,setcash] = useState(0)
    const [receiptdata , setreceiptdata] = useState([])
    const [check,setcheck] = useState(0)
    const [dueamount,setdueamount] = useState(0)
    const [paidamount,setpaidamount] = useState(0)
    const [card,setcard] = useState(0)
    const [account,setaccount] = useState(0)
    const [oldcashpayment , setoldcashpayment] = useState(0)
    const [oldcardpayment , setoldcardpayment] = useState(0)
    const [oldaccountpayment , setoldaccountpayment] = useState(0)
    const d = new Date()
    
    useEffect(()=>{
        if(!(localStorage.getItem("username"))){
            history.push('/')
            
        }else{
        loadReceiptData(localStorage.getItem("scannedid"))
       
        }
    },[])
    
    const updatePayment =(e)=>{
        e.preventDefault()
        var req = {
            "payment_id":localStorage.getItem('scannedid'),
            "paidamount":paidamount+Number(cash)+Number(card)+Number(account),
            "dueamount":dueamount,
            "status":"Picked Up",
            "cash":Number(oldcashpayment)+Number(cash),
            "card":Number(oldcardpayment)+Number(card),
            "account":Number(oldaccountpayment)+Number(account),
            "pickcash":Number(cash),
            "pickcard":Number(card),
            "pickaccount":Number(account),
            "pickamount":Number(cash)+Number(card)+Number(account),
            "pickdate":String(moment(d).format('YYYY-MM-DD'))
        }
       
        if(parseFloat(receiptdata.dueamount).toFixed(2)===parseFloat(Number(cash)+Number(card)+Number(account)).toFixed(2)){
        Updatepayment(req).then(res=>{
            const result = res;
            if(res!==undefined){
                 history.push('/pickupreceipt')
            }
        }).catch();
        }else{
            alert("Please Pay Full Due Amount")
        }
    }

    const loadReceiptData = (paymentid) =>{
        ReceiptServices(paymentid).then(res=>{
            const result = res;
            if(result!==undefined){
                if(result==null){
                    setreceiptdata([])
                }else{
                    setreceiptdata(result.data[0])
                    setdueamount(result.data[0].dueamount)
                    setpaidamount(result.data[0].paidamount)
                    setoldcashpayment(result.data[0].cash)
                    setoldcardpayment(result.data[0].card)
                    setoldaccountpayment(result.data[0].account)
                    localStorage.setItem("garmentsumprice",result.data[0].dueamount)  
                    for(var i=0;i<result.data.length;i++)
                    {
                        if(result.data[i].status==="complete")
                        setcheck(1)
                        else{
                            setcheck(0)
                            break
                        }
                    }
                }
            }else{
                setreceiptdata([])
            }
        }).catch();
    }

    if(check===0){
        return (
            <>
                <div className="modal" id="payment">
              <div className="modal-dialog" style={{textAlign:'center'}}>
                <div className="modal-content" style={{width:'600px'}}>
                
                  {/* Modal Header */}
                  <div className="modal-header">
                    <h4 className="modal-title" style={{fontWeight:'bold'}}>Tender Information</h4>
                    <button type="button" className="close" data-dismiss="modal">&times;</button>
                  </div>
                  
                  {/* Modal body */}
                <div className="modal-body">
                    
                <h1>Before payment please Complete the Garments or Services from the list</h1>
                  
                 </div>
                        {/* Modal footer */}
                    <div className="modal-footer">
                    
                    <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal" to="/barcodescan">Close</button>
                  </div>
                </div>
              </div>
            </div>
                
            </>
        )
    }else{
    return (
        <>
            <div className="modal" id="payment">
          <div className="modal-dialog" style={{textAlign:'center'}}>
            <div className="modal-content" style={{width:'600px'}}>
            
              {/* Modal Header */}
              <div className="modal-header">
                <h4 className="modal-title" style={{fontWeight:'bold'}}>Tender Information</h4>
                <button type="button" className="close" data-dismiss="modal">&times;</button>
              </div>
              
              {/* Modal body */}
            <div className="modal-body">
            <div className="wthree_general">																
                <div className="grid-1 graph-form agile_info_shadow">
                    <form className="form-horizontal">
                        <div className="form-group">
                            <label className="col-md-4 control-label">Cash</label>
                            <div className="col-md-4">
                                <div className="input-group">							
                                    <span className="input-group-addon">
                                        <i className="fa fa-money"></i>
                                    </span>
                                    <input type="text"  style={{fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" placeholder={cash} onChange={(e)=>{setcash(e.target.value);setdueamount(receiptdata.dueamount-e.target.value-card-account)}}/>
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <label className="col-md-4 control-label">Card</label>
                            <div className="col-md-4">
                                <div className="input-group">							
                                    <span className="input-group-addon">
                                        <i className="fa fa-money"></i>
                                    </span>
                                    <input type="text"  style={{fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" placeholder={card} onChange={(e)=>{setcard(e.target.value);setdueamount(receiptdata.dueamount-e.target.value-cash-account)}}/>
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <label className="col-md-4 control-label">Account</label>
                            <div className="col-md-4">
                                <div className="input-group">							
                                    <span className="input-group-addon">
                                        <i className="fa fa-money"></i>
                                    </span>
                                    <input type="text"  style={{fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" placeholder={account} onChange={(e)=>{setaccount(e.target.value);setdueamount(receiptdata.dueamount-e.target.value-cash-card)}}/>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div className="wthree_general">															
                <div className="grid-1 graph-form agile_info_shadow">
                    <form className="form-horizontal">
                        <div className="form-group">
                            <label className="col-md-4 control-label"style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Balance</label>
                            <div className="col-md-4">
                                <div className="input-group">							
                                    <span className="input-group-addon">
                                        <i className="fa fa-money"></i>
                                    </span>
                                    <input type="text" style={{color:'black',fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" readOnly value={parseFloat(receiptdata.dueamount).toFixed(2)}/>
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <label className="col-md-4 control-label"style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Total Tendered</label>
                            <div className="col-md-4">
                                <div className="input-group">
                                    <span className="input-group-addon">
                                        <i className="fa fa-money"></i>
                                    </span>
                                    <input type="text" style={{color:'black',fontWeight:'bold',fontSize:'20px'}} readOnly className="form-control1 icon" id="exampleInputPassword1" value={parseFloat(Number(cash)+Number(card)+Number(account)).toFixed(2)}/>
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <label className="col-md-4 control-label"style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Total Due</label>
                            <div className="col-md-4">
                                <div className="input-group input-icon right">
                                    <span className="input-group-addon">
                                        <i className="fa fa-money"></i>
                                    </span>
                                    <input id="text"  style={{color:'black',fontWeight:'bold',fontSize:'20px'}}  readOnly className="form-control1 icon" type="text" value={parseFloat(dueamount).toFixed(2)}/>
                                </div>
                            </div>
                        </div>  
                    </form>
                </div>
            </div>
             </div>
                    {/* Modal footer */}
                <div className="modal-footer">
                <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal" onClick={(e)=>updatePayment(e)}>Submit</button>
                <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal" to="/barcodescan">Close</button>
              </div>
            </div>
          </div>
        </div>
            
        </>
    )
    }
}

export default PayPayment
