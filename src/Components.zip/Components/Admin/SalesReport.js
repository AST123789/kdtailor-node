import React, { useEffect, useRef, useState } from 'react'
import { Link,useHistory } from 'react-router-dom';
import { SelectSalesReportData } from '../Function/SalesReport';
import moment from 'moment'
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import $ from 'jquery'

function SalesReport() {
  const [fromdate , setfromdate] = useState("")
  const [enddate , setenddate] = useState("")
  const [SalesList , setSaleslist] = useState([])
  const [check,setcheck] = useState(0)
  const history = useHistory()
  const [totalsum,settotalsum] = useState(0)
  const [paidsum,setpaidsum] = useState(0)
  const [totalcash , settotalcash] = useState(0)
  const [totalcard , settotalcard] = useState(0)
  const [totalaccount , settotalaccount] = useState(0)
  const [alterationvalue , setalterationvalue] = useState(0)
  const [drycleaningvalue , setdrycleaningvalue]=useState(0)

  const inputRef = useRef(null);
  const printDocument = () => {
    // html2canvas(inputRef.current).then((canvas) => {
    //   const imgData = canvas.toDataURL("image/jpeg");
    //   const pdf = new jsPDF('p','pt','a2');
    //   pdf.addImage(imgData, "JPEG", 0, 0);
    //   pdf.save("download.pdf");
    // });
    $('#printbutton').hide()
    $('#exitbutton').hide()
    $('#logoutbutton').hide()
    setTimeout(() => {
        window.print()
        $('#printbutton').show()
        $('#exitbutton').show()
        $('#logoutbutton').show()
    }, 2000);
  };
  useEffect(()=>{
    if(!(localStorage.getItem("salesUsername"))){
        history.push('/')
        
    }
  },[])

  const loadSalesReport = (e) =>{
      e.preventDefault()
      var req = {
          "fromdate":fromdate,
          "enddate":enddate
      }
      SelectSalesReportData(req).then(res=>{
          const result = res;
          if(result!==undefined){
            if(result===null){
                setSaleslist([])
            }else{
              console.log(result)
                setSaleslist(result.data)
                var total=0,paid=0,cash=0,card=0,account=0,alteration=0,drycleaning=0
                for(var i=0;i<result.data.length;i++)
                {
                    total = total+result.data[i].totalamount
                    paid = paid+(result.data[i]).paidamount
                    cash = cash+(result.data[i]).cash
                    card = card+(result.data[i]).card
                    account = account+(result.data[i]).account
                    alteration = alteration+(result.data[i]).alteration_value
                    drycleaning = drycleaning+(result.data[i]).drycleaning_value
                }
                settotalsum(total)
                setpaidsum(paid)
                settotalcash(cash)
                settotalcard(card)
                settotalaccount(account)
                setalterationvalue(alteration)
                setdrycleaningvalue(drycleaning)
                setcheck(1)
            }
        }else{
            setSaleslist([])
        }
      }).catch();
    }
  
    const logout = ()=>{
        localStorage.removeItem('salesUsername')
        history.push('/')
    }


  if(check=== 0 ){
    return (
        <>
          <div style={{textAlign:'right',marginTop:'15px' }}>
            <Link to="#" onClick={(e)=>logout()} style={{backgroundColor:'grey',padding:'15px',color:'white',fontWeight:'bold',fontSize:'20px'}}>LogOut </Link>
          </div>
          <div className="inner_content" style={{padding:'0rem'}}>
            <div className="inner_content_w3_agile_info">
              <div style={{textAlign:'center'}}>
                <img style={{width:'25%', height:'150px'}} src='kdtailor.jpeg'/>
              </div>
              <div className="registration admin_agile">
                <div className="signin-form profile admin">
                  <h2>Select The Period For Sale Reports</h2>
                  <div className="login-form">
                    <form action="main-page.html" method="post">
                      <input type="date" onChange={(e)=>setfromdate(e.target.value)} name="name"  placeholder="From Date" required=""/>
                      <input type="date" onChange={(e)=>setenddate(e.target.value)} name="password"  placeholder="End Date" required=""/>
                      <Link to="#"  onClick={(e)=>loadSalesReport(e)} style={{color:'#fff'}}><div className="tp login_button">
                          Submit
                      </div></Link>
                      
                    </form>
                  </div>
                
                </div>
                </div>
            </div>
          </div>
        </>
    )
  }

  return (
      <>
        <div style={{textAlign:'right',marginTop:'15px' }}>
          <Link id="logoutbutton"  to="#" onClick={(e)=>logout()} style={{backgroundColor:'grey',padding:'15px',color:'white',fontWeight:'bold',fontSize:'20px'}}>LogOut</Link>
        </div>
        <br></br>
        <div ref={inputRef} id="genratepdf" className="w3l-table-info agile_info_shadow" style={{backgroundColor: '#f5f5f5',
            width: '1400px',
            marginLeft: 'auto',
            marginRight: 'auto'}}>
            <table id="table">
                <thead>
                    <tr>
                        <th style={{fontSize:'12px'}}> Date</th>
                        <th style={{fontSize:'12px'}}>Customer Name</th>
                        <th style={{fontSize:'12px'}}>Payment Id</th>
                        <th style={{fontSize:'12px'}}>Alteration Amount</th>
                        <th style={{fontSize:'12px'}}>Dry Cleaning Amount</th>
                        <th style={{fontSize:'12px'}}>Total Amount</th>
                        <th style={{fontSize:'12px'}}>Cash Amount</th>
                        <th style={{fontSize:'12px'}}>Card Amount</th>
                        <th style={{fontSize:'12px'}}>Account Amount</th>
                        <th style={{fontSize:'12px'}}>Paid Amount</th>
                        <th style={{fontSize:'12px'}}>Return Amount</th>
                        <th style={{fontSize:'12px'}}>Status</th>
                        {/* <th>Due Amount</th> */}
                    </tr>
                </thead>
                <tbody>
                    {
                        SalesList?
                        SalesList.length>0?
                        SalesList.map((data)=>{
                        return(
                            <tr>
                            <td style={{fontSize:'12px'}}>{moment(data.createdate).format('DD-MM-YYYY')}</td>
                            <td style={{fontSize:'12px'}}>{data.name + " "+ data.surname}</td>
                            <td style={{fontSize:'12px'}}>{data.payment_id}</td>
                            <td style={{fontSize:'12px'}}>$ {parseFloat(Number(data.alteration_value)).toFixed(2)}</td>
                            <td style={{fontSize:'12px'}}>$ {parseFloat(Number(data.drycleaning_value)).toFixed(2)}</td>
                            <td style={{fontSize:'12px'}}>$ {parseFloat(data.totalamount).toFixed(2)}</td>
                            <td style={{fontSize:'12px'}}>$ {parseFloat(Number(data.cash)).toFixed(2)}</td>
                            <td style={{fontSize:'12px'}}>$ {parseFloat(Number(data.card)).toFixed(2)}</td>
                            <td style={{fontSize:'12px'}}>$ {parseFloat(Number(data.account)).toFixed(2)}</td>
                            <td style={{fontSize:'12px'}}>$ {parseFloat(data.paidamount).toFixed(2) }</td>
                            <td style={{fontSize:'12px'}}>- $ {parseFloat(Number(data.changedue)).toFixed(2)} by {data.changeduemode}</td>
                            <td style={{fontSize:'12px'}}>{data.paymentstatus}</td>
                            </tr>
                        )
                        })
                        :<div>Data not found</div>
                        :<div>Data not found</div>
                    }
                    <tr >
                    <td></td>
                    <td></td>
                    <td></td>
                    <td style={{fontSize:'20px' , fontWeight:'bold'}}> $ {parseFloat(alterationvalue).toFixed(2)}  </td>
                    <td style={{fontSize:'20px' , fontWeight:'bold'}}>$ {parseFloat(drycleaningvalue).toFixed(2)}</td>
                    <td style={{fontSize:'20px' , fontWeight:'bold'}}> $ {parseFloat(totalsum).toFixed(2)}  </td>
                    <td style={{fontSize:'20px' , fontWeight:'bold'}}>$ {parseFloat(totalcash).toFixed(2)}</td>
                    <td style={{fontSize:'20px' , fontWeight:'bold'}}>$ {parseFloat(totalcard).toFixed(2)}</td>
                    <td style={{fontSize:'20px' , fontWeight:'bold'}}>$ {parseFloat(totalaccount).toFixed(2)}</td>
                    <td style={{fontSize:'20px' , fontWeight:'bold'}}>$ {parseFloat(paidsum).toFixed(2)}</td>
                    
                    </tr>
                  
                </tbody>
            </table>
          <div style={{fontSize:'20px' , fontWeight:'bold' , textAlign:'right' , marginRight:'50px',paddingTop:'15px'}}>
            Total Due Amount $ {parseFloat(totalsum - paidsum).toFixed(2)}
          </div>
        </div>
        <button id="printbutton" className="btn btn-info" style={{marginLeft:'20px',marginTop:'40px',fontSize:'20px',background:'#000'}} onClick={printDocument}>Print</button>
        <Link to='/afterSign' id="exitbutton" className="btn btn-info" style={{marginLeft:'20px',marginTop:'40px',fontSize:'20px',background:'#000'}}>Exit</Link>
      </>
  )
}

export default SalesReport