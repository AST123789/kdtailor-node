import React, { useEffect } from 'react'
import { Link,useHistory } from 'react-router-dom'
import { useState } from 'react/cjs/react.development'
import { PantInnerChildServices, PantInnerServices, PantServicesCategoryData } from '../Function/PantService';
import SideBar from './wcommon/SideBar'
import $ from 'jquery'
import Model from './wcommon/Model';
import Header from './wcommon/header';
import RightSideBar from './wcommon/RightSideBar';

function PantServices() {
   
   const [panttype , setpanttype]=useState([]);
   const history = useHistory()

   useEffect(()=>{
      if(!(localStorage.getItem("username"))){
         history.push('/')
         
     }else{
      $('#MiddleDiv').hide()
      $('#ChildDiv').hide()
      loadType();
     }
   },[])

   const loadType=()=>{
      PantServicesCategoryData().then(res=>{
         const result = res;
         if(result!=undefined){
            if(result.data == null){
               setpanttype([]);
            }else{
               setpanttype(result.data);
            }
         }else{
            setpanttype([]);
         }
      }).catch();
   }

   const loadInnerChildServices = (e,middlename)=>{
      e.preventDefault()
      localStorage.setItem("childgarmentname",middlename)
      PantInnerChildServices(middlename).then(res=>{
         const result = res;
         if(result!==undefined){
            if(result.data==null){
               setpanttype([]);
            }else{
               setpanttype(result.data);
               $('#ParentDiv').hide()
               $('#MiddleDiv').hide()
               $('#ChildDiv').show()
            }
         }else{
            setpanttype([]);
         }
      }).catch();
   }

   const addgarment = (garmentname,price)=>{
      localStorage.setItem("childgarment",garmentname)
      localStorage.setItem("childprice",price)
   }

    return (
        <>
        <SideBar/>
       {/* <Header/> */}

  

                       <div className="buttons_w3ls_agile">
								
                              <div id="MiddleDiv"  className="col-md-6 button_set_one three agile_info_shadow">
                            
                                   
										 <h3  className="w3_inner_tittle two"> </h3>

											{
                                    panttype.map((data)=>{
                                       return(
                                          <Link type = "button" onClick={(e)=>loadInnerChildServices(e,data.services_middle_name)} class = "btn btn-primary" style={{backgroundColor:'black'}}>{data.services_middle_name}</Link>
                                       )
                                    })
                                 }

									     <div className="clearfix"></div>
								      </div>

                              <div id="ChildDiv" className="col-md-6 button_set_one three agile_info_shadow">
                            
                                   
										 <h3  className="w3_inner_tittle two"> </h3>

											{
                                    panttype.map((data)=>{
                                       return(
                                          <>
                                             <button onClick={(e)=>addgarment(data.services_child_name,data.services_child_price)} data-toggle="modal" data-target="#myModal"  class = "btn btn-primary" style={{backgroundColor:'black'}}><h5>{data.services_child_name}</h5><br></br><h4>${data.services_child_price}</h4></button>
                                          </>
                                          )
                                    })
                                 }

									     <div className="clearfix"></div>
								      </div>

                                   <RightSideBar/>

                                
                                </div>

                                <Model/>
        </>
    )
}

export default PantServices