import React, { useState,useEffect } from 'react'
import { Link , useHistory} from 'react-router-dom'
import { DeleteGarment, DeleteGarmentCategoryData, SelectGarmentList, SelectPriceById, TruncateGarmentCategoryData, Updategarment, Updateholddata, UpdatePriceData } from '../Function/Garment'
import SideBar from './wcommon/SideBar'
import $ from 'jquery'
import Header from './wcommon/header'
import Pickup from './Pickup'
import CustomerList from './CustomerList'
import Payment from './Payment'
import PriceChange from './PriceChange'
import { UpdateReferenceId } from '../Function/ViewReport'
import { FetchGarmentList } from '../Function/EditTicket'
import { DeletePayment } from '../Function/Payment'

function GarmentList() {
   const  history = useHistory()
    const [garmentlist,setgarmentlist] = useState([])
    const [category,setcategory] = useState([])
    const [filteredgarmentlist,setfilteredgarmentlist] = useState([])
    const [serviceid,setserviceid] = useState("")
    const [garment,setgarment] = useState("")
    const [instruction, setinstruction] = useState('')
    const [garmentprice,setgarmentprice]=useState([])
    const [referenceid , setreferenceid] = useState(localStorage.getItem("refernceid")?localStorage.getItem("refernceid")!=='null'?localStorage.getItem("refernceid"):'':'')
    const [discountcash , setcash] = useState(0)
    const [sum , setsum] = useState(localStorage.getItem('garmentsumprice'))
    
    useEffect(() => {
        if(!(localStorage.getItem("username"))){
            history.push('/')
            
        }else{
        $('#remove_garment').hide()
        $('#remove_service').hide()
        $('#add_garment').hide()
        $('#show_instruction').hide()
        $('#addServices').hide()
        $('#discount').hide()
        // $('#reference').hide()
        if(localStorage.getItem("ticketid")){
            if(Number(localStorage.getItem("fetchgarment"))===0){
                FetchGarmentListData()
                localStorage.setItem("fetchgarment",1)
            }
        }
        loadGarmentList()
        }
    }, [])

    const loadGarmentList=()=>{
        SelectGarmentList().then(res=>{
           const result = res;
           if(result !== undefined){
              if(result.data == null){
                 setgarmentlist([]);
              }else{
                 setgarmentlist(result.data)
                 PriceCalculate(result.data)
                 
                 if (result.data.length > 0) {
                    var car = []
                    result.data.forEach(function (elem) {
                        if (car.indexOf(elem.garmentname) === -1) {
                            car.push(elem.garmentname);
                        }
                    });
                }
                setcategory(car)
                if(result.data.length > 0){
                    localStorage.setItem("number",car.length)
                }
                else{
                    localStorage.setItem("number",0)
                }

                //Filter array
                var data =  result.data.filter(function(garment) {
                    return garment.garmentname === result.data[0].garmentname;
                });
                
                setfilteredgarmentlist(data)
              }
           }else{
              setgarmentlist([]);
           }
        }).catch();
        
     }

     const categoryList = (garmentcategory = category[0])=>{
        var data =  garmentlist.filter(function(garment) {
            return garment.garmentname === garmentcategory;
        });
        setfilteredgarmentlist(data)
        localStorage.setItem("garmentcolor",data[0].color)
        localStorage.setItem("colorcode",data[0].colorcode)
        if(garmentcategory.slice(3)==="drycleaning"){
            localStorage.setItem("customtype","Dry Cleaning")
        }
        else{
            localStorage.setItem("customtype","Alteration")
        }
        setgarment(garmentcategory) //setting garment
        $('#remove_garment').show()
        $('#addServices').show()
     }
    
     const deleteService=(e)=>{
         e.preventDefault()
         if(filteredgarmentlist.length===1){
            DeleteGarmentCategoryData(garment).then(res=>{
                localStorage.setItem("number",Number(localStorage.getItem("number"))-1)
             }).catch();
         }
         else{
            DeleteGarment(serviceid).then(res=>{ 
            }).catch();
         }

        loadGarmentList()
        loadGarmentList()
        
     }

     const UpdateGarmentData=(e)=>{
         e.preventDefault()
        var req = {
            "garmentid":serviceid,
            "instruction":instruction
        }
        Updategarment(req).then(res=>{
           
       }).catch();

       setinstruction("")
    //    window.location.reload()
       loadGarmentList()
       loadGarmentList()
    }

     const deleteGarment = (e)=>{
        DeleteGarmentCategoryData(garment).then(res=>{
            localStorage.setItem("number",Number(localStorage.getItem("number"))-1)
         }).catch();
         if(localStorage.getItem("ticketid")){
            window.location.reload()
         }
         loadGarmentList()
         loadGarmentList()
     }

     const ServiceUnHide=(e,id,inst)=>{
        e.preventDefault()
        setserviceid(id)
        setinstruction(inst)
        $('#remove_service').show()
        $('#show_instruction').show()
       
        localStorage.setItem("garmentid",id)
        SelectPriceById(Number(id)).then(res=>{
            const result = res
            if(result!=undefined){
                if(result===null){
                    setgarmentprice([])
                }else{
                    setgarmentprice(result.data)
                    setcash(result.data.pricediscount)
                }
            }else{
                setgarmentprice([])
            }
            $('#discount').show()
        }).catch();
     }
     localStorage.setItem("garmentlistprice",garmentprice.garmentchildprice)
     localStorage.setItem("garmentdiscount", garmentprice.pricediscount)
     
     const PriceCalculate = (price) =>{
        let sum = 0
        for(let j=0;j<price.length;j++){
          sum = sum + parseFloat(Number(price[j].garmentfinalamount).toFixed(2))
        }
        let sum_alteration = 0
        let sum_drycleaning=0
        for(let j=0;j<price.length;j++){
        if(price[j].type==='Alteration'){
            sum_alteration = sum_alteration+price[j].garmentfinalamount
        }
        else if(price[j].type==="Dry Cleaning"){
            sum_drycleaning = sum_drycleaning+price[j].garmentfinalamount
        }
    }
        localStorage.setItem("alteration_sum",sum_alteration)
        localStorage.setItem("drycleaning_sum",sum_drycleaning)
        localStorage.setItem("totalgarmentprice",sum)
        localStorage.setItem("garmentsumprice",Number(sum))
     }
     
     const Cancel = (e) =>{
        TruncateGarmentCategoryData().then(res=>{
        }).catch();
        loadGarmentList()
        loadGarmentList()
        localStorage.removeItem("customerid")
        localStorage.removeItem("customername")
        localStorage.removeItem("ticketid")
        localStorage.removeItem("pickupdate")
        localStorage.removeItem("pickuptime")
        localStorage.removeItem("pricecash")
        localStorage.removeItem("pricecard")
        localStorage.removeItem("priceaccount")
        localStorage.setItem("garmentsumprice",Number(0))
       
        history.push('/afterSign')
     }

     const GotoServices = (e)=>{
        localStorage.setItem("numbergarment",garment)
        if(garment.slice(3)==='jeans' || garment.slice(4)==='jeans'){
            history.push("/JeansServices")
        }else if(garment.slice(3)==='pant' || garment.slice(4)==='pant'){
            history.push("/PantServices")
        }else if(garment.slice(3)==='jacket'|| garment.slice(4)==='jacket'){
            history.push("/JacketServices")
        }else if(garment.slice(3)==='leather' || garment.slice(4)==='leather'){
            history.push("/leatherServices")
        }else if(garment.slice(3)==='skirt' || garment.slice(4)==='skirt'){
            history.push("/SkirtServices")
        }else if(garment.slice(3)==='dresses' || garment.slice(4)==='dresses'){
            history.push("/DressServices")
        }else if(garment.slice(3)==='shirtTop' || garment.slice(4)==='shirtTop'){
            history.push("/ShirtTopServices")
        }else if(garment.slice(3)==='drycleaning' || garment.slice(4)==='drycleaning'){
            history.push("/DryServices")
        }else if(garment.slice(3)==='other' || garment.slice(4)==='other'){
            history.push("/otherAlterationServices")
        }
     }
 
     const UpdateReferencedata = (e) =>{
         var req = {
             "reference_id":referenceid
         }
         localStorage.setItem("refernceid",referenceid)
         setreferenceid(localStorage.getItem("refernceid"))
         UpdateReferenceId(req).then(res=>{             
         })
         window.location.reload()
         
     }

      // EDIT LIST FUNCTIONING START 

      const FetchGarmentListData = ()=>{
        FetchGarmentList(localStorage.getItem("ticketid")).then(res=>{
            const result = res;
            if(result!==undefined){
                if(result==null){
                    
                }
                else{
                    localStorage.setItem("customerid",result.Data[0][0].customerid)
                    localStorage.setItem("customername",result.Data[0][0].customername)
                    localStorage.setItem("pickupdate",result.Data[0][0].pickupdate)
                    localStorage.setItem("pickuptime",result.Data[0][0].pickuptime)
                    localStorage.setItem("pricecash",result.Data[1][0].cash)
                    localStorage.setItem("priceaccount",result.Data[1][0].account)
                    localStorage.setItem("pricecard",result.Data[1][0].card)
                    localStorage.setItem("refernceid",result.Data[0][0].reference_id)
                    localStorage.setItem("prevpaidamount",result.Data[1][0].paidamount)
                    window.location.reload()
                }
            }
        }).catch()
    }

    const chang = (e)=>{
        loadGarmentList()
        loadGarmentList()
    }

// EDIT LIST FUNCTIONING END

const DeleteToken=(e)=>{
    DeletePayment().then(res=>{

    })
    localStorage.clear()
    history.push('/')
}
//  DISCOUNT OF PARTICULAR GARMENT SERVICES MODAL START

const UpdatePrice = (e) =>{
    var req = {
        "garmentlistid":Number(localStorage.getItem("garmentid")),
        "garmentdiscount":Number(discountcash),
        "garmentfinalamount":parseFloat(Number(localStorage.getItem('garmentlistprice')-discountcash)).toFixed(2)
    }
    UpdatePriceData(req).then(res=>{
    })
    // window.location.reload()
    loadGarmentList()
    loadGarmentList()
}

const UpdateHoldData = () =>{
    var req = {
        "hold":"hold"
    }
    Updateholddata(req).then(res=>{
        localStorage.removeItem("customerid")
        localStorage.removeItem("customername")
    })
    // window.location.reload()
    loadGarmentList()
    loadGarmentList()
}

    return (
        <>
            <SideBar />
                <Header/><br></br>                                
                    <div className="buttons_w3ls_agile" >
                        <div className="col-md-3 button_set_one three agile_info_shadow">
                            <Link to="/alteration" onClick={()=>localStorage.removeItem("numbergarment")}>
                                <div className="button">
                                    <p className="btnText">Add Garment</p>
                                </div>
                            </Link>

                            <Link to="#" onClick={()=>UpdateHoldData()}>      
                                <div className="button">
                                    <p className="btnText">Hold</p>
                                    
                                </div>
                            </Link>
  
                            <div  id="remove_garment" onClick={(e)=>deleteGarment(e)}>
                                <div className="button">
                                    <p className="btnText">Remove Garment</p>
                                    </div>
                            </div>
                                
                            <div  id="show_instruction">
                                <div className="button">
                                    <Link  to="#"   data-target='#instruction' data-toggle='modal'>
                                        <p className="btnText">Add Instruction</p>
                                    </Link>
                                </div>
                            </div>
                                   
                           <div id="addServices" onClick={(e)=>GotoServices(e)} >
                                <div className="button">
                                    <p className="btnText">Add Service</p>
                                        
                                </div>
                            </div>

                            <div  id="remove_service" onClick={(e)=>deleteService(e)}>
                                <div className="button" >
                                    <p className="btnText">Remove Service</p>
                                    
                        
                                </div>
                            </div>
                        </div>
                        <div className="col-md-2 button_set_one three agile_info_shadow">
                                {
                                    category ?category.length > 0?
                                   
                                    category.map((data)=>{
                                        return(
                                            <div className="button row" style={{margin:"10px",height:"100%",width:"100%"}} onClick={(e)=>categoryList(data)}>
                                                <div className="col-md-10">
                                                <p className="btnText" style={{paddingBottom:"15px"}}>{data}</p>
                                                </div>
                                            </div>
                                        )
                                    })
                                    :
                                <div>No data added</div> :<div>Data not found</div>
                                }  
                        </div>
                        <div className="col-md-4 button_set_one three agile_info_shadow">
                            {
                                filteredgarmentlist.length > 0?
                                
                                filteredgarmentlist.map((data)=>{
                                    return(
                                        <>
                                        <div key={data.order_id} className="button row" style={{margin:"10px",height:"100%",width:"100%"}} onClick={(e)=>ServiceUnHide(e,data.garmentlistid,data.instructions)}>
                                            <div className="col-md-10">
                                            <p className="btnText">{data.garmentname}/ {data.garmentmiddlename}/<br></br>{data.garmentchildname} <br></br><span style={{color:"yellow",fontSize:"20px"}}><b>$ {parseFloat(data.garmentchildprice).toFixed(2)} / $ {parseFloat(data.garmentfinalamount).toFixed(2)}</b></span></p>
                                            </div>
                                            <div className="col-md-2" style={{backgroundColor:data.colorcode,padding:"1%",color:'#fff'}}>{data.color}</div>
                                            
                                        </div>
                                        { data.instructions?   
                                        <div className="button row" style={{margin:"10px",height:"100%",width:"100%"}} >
                                            <div className="col-md-10">
                                            
                                            <p className="btnText">Instructions : {data.instructions}</p>
                                            </div>
                                        </div>:null
                                        }
                                        </>
                                    )
                                })
                                :
                            <div>No data added</div>
                            }  
                        </div>

                        <div className="col-md-3 button_set_one three one agile_info_shadow">
                            <div  className="button" id="discount" data-toggle="modal" data-target="#discountService">
                                <p className="btnText">Services Discount</p>
                            </div>

                            <div className="button"  data-toggle="modal" data-target="#pickupdate" >
                                <p className="btnText">Pickup Date/Time</p>
                            </div>

                            <div className="button" data-toggle="modal" data-target="#customerlist">
                                <p className="btnText">Customer</p>
                            </div>

                            <div className="button" data-toggle="modal" data-target="#priceChange">
                                <p className="btnText">Price Change</p>
                            </div>
                            
                            <div className="button" data-toggle="modal" id="reference" data-target="#referenceid">
                                <p className="btnText">Reference Id</p>
                                
                            </div>            

                            <div className="button"  data-toggle="modal" data-target="#payment" >
                                <p className="btnText">Payment</p>
                            </div>
                                
                            <div className="button" onClick={(e)=>Cancel(e)}>
                                <p className="btnText">Cancel</p>
                            </div>

                            <div className="button" onClick={(e)=>DeleteToken(e)}>
                                <p className="btnText">Delete Token</p>
                            </div>
                        </div>

                    </div>     

                    <Pickup/>   
                    <CustomerList/>
                    <Payment list = {garmentlist}/>
                    <PriceChange chang = {chang}/>

            {/* Add instruction */}
            <div className="modal" id="instruction">
              <div className="modal-dialog" style={{textAlign:'center'}}>
                <div className="modal-content" style={{width:'600px'}}>
                    {/* Modal Header */}
                    <div className="modal-header">
                    <h4 className="modal-title"  style={{fontWeight:'bold'}}>Instruction</h4>
                    <button type="button" className="close" data-dismiss="modal">&times;</button>
                    </div>
                    
                    {/* Modal body */}
                    <div className="modal-body">
                        
                    <textarea rows="4" value={instruction} cols="80" onChange={(e)=>setinstruction(e.target.value)}  placeholder='Enter Instruction'/>
                    
                    
                    </div>
                        {/* Modal footer */}
                    <div className="modal-footer">
                        <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}}  onClick={(e)=>UpdateGarmentData(e)} data-dismiss="modal">Submit</button>
                        <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal" to="/barcodescan">Close</button>
                    </div>
                </div>
              </div>
            </div>

            {/* Reference Id modal start */}

            <div className="modal" id="referenceid">
              <div className="modal-dialog" style={{textAlign:'center'}}>
                <div className="modal-content" style={{width:'600px'}}>
                    {/* Modal Header */}
                    <div className="modal-header">
                        <h4 className="modal-title"  style={{fontWeight:'bold'}}>Reference Id</h4>
                        <button type="button" className="close" data-dismiss="modal">&times;</button>
                    </div>
                    {/* Modal body */}
                    <div className="modal-body">
                        <div className="wthree_general">									
                            <div className="grid-1 graph-form agile_info_shadow">
                                <form className="form-horizontal">
                                    <div className="form-group">
                                        <label className="col-md-4 control-label">Reference Id</label>
                                        <div className="col-md-4">
                                            <div className="input-group">							
                                                <input type="text" value={referenceid} onChange={(e)=>setreferenceid(e.target.value)}  style={{fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" />
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                        {/* Modal footer */}
                    <div className="modal-footer">
                        <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}}  onClick={(e)=>UpdateReferencedata(e)} data-dismiss="modal">Submit</button>
                        <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal" to="/barcodescan">Close</button>
                    </div>
                </div>
              </div>
            </div>

            {/* DISCOUNT OF PARTICULAR GARMENT SERVICES MODAL START */}

            <div className="modal" id="discountService">
                <div className="modal-dialog" style={{textAlign:'center'}}>
                    <div className="modal-content" style={{width:'600px'}}>
            
                        {/* Modal Header */}
                        <div className="modal-header">
                            <h4 className="modal-title" style={{fontWeight:'bold'}}></h4>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                        </div>
              
                        {/* Modal body */}
                        <div className="modal-body">
                            <div className="wthree_general">
								<div className="grid-1 graph-form agile_info_shadow">
                                    <form className="form-horizontal">
                                        <div className="form-group">
                                           <label className="col-md-4 control-label">Discount Amount</label>
                                                <div className="col-md-4">
                                                    <div className="input-group">							
                                                        <span className="input-group-addon">
                                                            <i className="fa fa-money"></i>
                                                        </span>
                                                        <input type="text"  style={{fontWeight:'bold',fontSize:'20px'}} value={discountcash}  className="form-control1 icon" onChange={(e)=>{setcash(e.target.value);setsum(localStorage.getItem('garmentsumprice')-e.target.value)}}/>
                                                    </div>
                                                </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="col-md-4 control-label">Discount Percentage</label>
                                            <div className="col-md-4">
                                                <div className="input-group">							
                                                    <span className="input-group-addon">
                                                        <i className="fa fa-money"></i>
                                                    </span>
                                                    <input type="text"  style={{fontWeight:'bold',fontSize:'20px'}} value={discountcash*100/localStorage.getItem('garmentlistprice')}  className="form-control1 icon" onChange={(e)=>{setcash(e.target.value*localStorage.getItem('garmentlistprice')/100);setsum(localStorage.getItem('garmentlistprice')-e.target.value)}}/>
                                                </div>
                                            </div>
                                        </div>
                                    </form>                                                
                                </div>
                            </div>
                            <div className="wthree_general">                                                                                                                  
                                <div className="grid-1 graph-form agile_info_shadow">    
                                    <form className="form-horizontal">
                                        <div className="form-group">
                                            <label className="col-md-4 control-label" style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Balance</label>
                                                <div className="col-md-4">
                                                    <div className="input-group">							
                                                        <span className="input-group-addon">
                                                            <i className="fa fa-money"></i>
                                                        </span>
                                                        <input type="text" style={{color:'black',fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" readOnly value={parseFloat(localStorage.getItem('garmentlistprice')).toFixed(2)}/>
                                                    </div>
                                                </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="col-md-4 control-label" style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Total Tendered</label>
                                            <div className="col-md-4">
                                                <div className="input-group">
                                                    <span className="input-group-addon">
                                                        <i className="fa fa-money"></i>
                                                    </span>
                                                    <input type="text" style={{color:'black',fontWeight:'bold',fontSize:'20px'}} readOnly className="form-control1 icon" id="exampleInputPassword1" value={parseFloat(Number(discountcash)).toFixed(2)}/>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="col-md-4 control-label"style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Total Due</label>
                                            <div className="col-md-4">
                                                <div className="input-group input-icon right">
                                                    <span className="input-group-addon">
                                                        <i className="fa fa-money"></i>
                                                    </span>
                                                    <input id="text"  style={{color:'black',fontWeight:'bold',fontSize:'20px'}}  readOnly className="form-control1 icon" type="text" value={parseFloat(localStorage.getItem('garmentlistprice')-discountcash).toFixed(2)}/>
                                                </div>
                                            </div>                                               
                                        </div>          
                                    </form>                              
                                </div>
                            </div>
                </div>
                    {/* Modal footer */}
                <div className="modal-footer">
                    <button type="button" onClick={(e)=>UpdatePrice(e) } className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal"   >Ok</button>
                    <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
                </div>
              
                    </div>
                </div>
            </div>
        </>
    )
}

export default GarmentList
