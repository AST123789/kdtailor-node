import React, { useEffect,useState } from 'react'
import { useHistory } from 'react-router-dom';
import moment from 'moment';

function Pickup() {

const history = useHistory()

useEffect(()=>{
  
  if(!(localStorage.getItem("username"))){
    history.push('/')
}     
},[]);

const [date , setdate] = useState(localStorage.getItem("pickupdate")?localStorage.getItem("pickupdate"):'');
const [slicetime,setslicetime] = useState(localStorage.getItem("pickuptime")?localStorage.getItem("pickuptime").slice(0,2):'');
const [sliceminute,setsliceminute] = useState('00')
const [slicetemp,setslicetemp] = useState(localStorage.getItem("pickuptime")?localStorage.getItem("pickuptime").slice(6,8):'')

let datecontainer =[];
for(var i=0;i<28;i++){
  let days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  var dt = new Date()
  dt.setDate(dt.getDate()+i)
  var d = dt.toLocaleDateString("en-US")
  datecontainer.push(moment(d).format('DD-MM-YYYY') + " " + days[dt.getDay()]) 
}   

let timecontainer = ["09 AM","10 AM","11 AM","12 PM","13 PM","14 PM","15 PM","16 PM","17 PM"];
let slicecontainer = ["00","15","30","45"];

const settimevalue = (e,data)=>{
  e.preventDefault()
  setslicetemp(data.slice(3,5))
  setslicetime(data.slice(0,2))
}

const submitDateTime = (e) =>{
  e.preventDefault()
  localStorage.setItem("pickupdate",date.slice(0,10))
  localStorage.setItem("pickupday",date.slice(11))
  localStorage.setItem('pickuptime',slicetime+":"+sliceminute+" "+slicetemp)
  history.push("/GarmentList")
}

return (
    <>
    <div className="modal" id="pickupdate">
      <div className="modal-dialog">
        <div className="modal-content">
        
          {/* Modal Header */}
          <div className="modal-header">
            <h4 className="modal-title">Pickup Date</h4>
            <button type="button" className="close" data-dismiss="modal">&times;</button>
          </div>
          
          {/* Modal body */}
          <div className="modal-body">
            {/* Modal footer */}
            <div className="row" style={{display:'flex', justifyContent:'center',alignItems:'center' , width:'100%'}}>
              <div className="col-6" style={{margin:'5px'}}>
                <select className="new-select" onChange={(e)=>setdate(e.target.value)}>
                  {
                      localStorage.getItem("pickupdate")?<option selected value={localStorage.getItem("pickupdate")}>
                              {localStorage.getItem("pickupdate")}</option>:
                                <option disabled selected value={"null"}>--Please Select--</option>
                  }
                  {
                      datecontainer.map((data)=>{

                          return(
                            <>
                              <option value={data}>{data}</option>
                          </>
                          )
                      })
                  }
                </select>
              </div>
              <div className="col-6">          
                <select className="new-select" onChange={(e)=>settimevalue(e,e.target.value)}>
                  {
                    localStorage.getItem("pickuptime")?<option selected value={localStorage.getItem("pickuptime")}>
                            {localStorage.getItem("pickuptime").slice(0,2)+ ' '+localStorage.getItem("pickuptime").slice(6,8)}</option>:
                              <option selected value={"null"}>--Please Select--</option>
                  }
                  
                  {
                      timecontainer.map((data)=>{
                          return(
                            <option value={data}>{data}</option>
                            )
                      })
                  }
                </select>
              </div>
            </div>
            <div className="row" style={{display:'flex', justifyContent:'center',alignItems:'center' , width:'100%'}}>
              <div className="col-6"></div>
                <div className="col-6">          
                  <select className="new-select" onChange={(e)=>setsliceminute(e.target.value)}>
                    {
                      localStorage.getItem("pickuptime")?<option selected value={localStorage.getItem("pickuptime")}>
                              {localStorage.getItem("pickuptime")}</option>:
                                <option disabled selected value={"null"}>--Please Select--</option>
                    }
                    {
                        slicecontainer.map((data)=>{
                            return(
                              <option value={data}>{slicetime+":"+data+" "+slicetemp}</option>
                              )
                        })
                    }
                  </select>
                </div>
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal" onClick={(e)=>submitDateTime(e)}>OK</button>
            <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>    
    </>
  )
}

export default Pickup
