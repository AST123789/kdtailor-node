import React, { useEffect, useState,useRef } from 'react'
import { Link, useHistory } from 'react-router-dom';
import moment from 'moment'
import { SelectViewReportData } from '../Function/ViewReport';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import $ from 'jquery'


function CustomerReport() {

  const [customername , setcustomername] = useState("")  
  const [check,setcheck] = useState(0)
  const history = useHistory()
  const [totalsum,settotalsum] = useState(0)
  const [paidsum,setpaidsum] = useState(0)
  const [SalesList , setSaleslist] = useState([])

    const d = new Date()
  const inputRef = useRef(null);

  const printDocument = () => {
    // html2canvas(inputRef.current).then((canvas) => {
    //   const imgData = canvas.toDataURL("image/jpeg");
    //   const pdf = new jsPDF('p','pt','a4');
    //   pdf.addImage(imgData, "JPEG", 0, 0);
    //   pdf.save("download.pdf");
    // });
    $('#printbutton').hide()
    $('#exitbutton').hide()
    setTimeout(() => {
        window.print()
        $('#printbutton').show()
        $('#exitbutton').show()
    }, 2000);
  };

  useEffect(()=>{
    if(!(localStorage.getItem("username"))){
        history.push('/')
    }else{
        loadSalesReport()
    }
  },[])

  const loadSalesReport = () =>{
    var req = {
        "customerid":Number(localStorage.getItem("customerid")),
        "startdate":localStorage.getItem("startdates"),
        "enddate":localStorage.getItem("enddates")
    }

    SelectViewReportData(req).then(res=>{
        const result = res;
        if(result!==undefined){
          if(result===null){
              setSaleslist([])
          }else{
              setcheck(1)
              setSaleslist(result.data)

              var total = 0;
              var paidtotal = 0;
              
              for(var i=0; i<(result.data).length;i++ ){
                paidtotal = paidtotal+result.data[i].paidamount
                total = total+result.data[i].garmentfinalamount
              }

              settotalsum(Number(total))
              setpaidsum(Number(paidtotal))
              setcustomername(result.data[0].customername)
              
          }
      }else{
          setSaleslist([])
      }
    }).catch();
  }
  
  if(check===0){
      return(
          <div><img src="loader.gif" alt="loader"/></div>
      )
  }

  
  return (
      <div>
        
    <div ref={inputRef} id="genratepdf" className="w3l-table-info" style={{backgroundColor: '#fff',
        width: '800px',
        minHeight:'600px',
        marginLeft: 'auto',
        marginRight: 'auto'}}>
            
            <div style={{height:'100%',padding:'33px'}}>
            <div style={{textAlign:'center'}}>
						<img style={{width:'50%', height:'150px'}} src='kdlogo.png' alt="logo"/>
            </div>
            <div className="row" style={{marginTop:'60px'}}>
                <div className="col-md-6" style={{margin:'0px'}}>
                    <p style={{fontSize:'18px'}}>Address: 
                        <br></br>Shop 212,Centrepoint Shopping Center, 
                        <br></br>70 Murray Street, Hobart 7000
                        <br></br><b>PH: 0362 006 963</b>
                        <br></br>kdtailor21@gmail.com
                        <br></br>ABN: 83 654 448 192
                        <br></br>Date: {moment(d).format("DD-MM-YYYY")}
                    </p>
                </div>
                <div className="col-md-6" style={{margin:'0px'}}>
                    <p style={{fontSize:'18px'}}><b>Customer Name: {customername}</b></p>
                </div>
            </div>
        <table id="table" style={{border:'1px solid black'}}>
            <thead>
                <tr>
                    {/* <th> Date</th> */}
                    <th style={{textAlign:'center',border:'1px solid black'}}>Description</th>
                    <th style={{textAlign:'center',border:'1px solid black'}}>Invoice No.</th>
                    <th style={{textAlign:'center',border:'1px solid black'}}>Reference</th>
                    <th style={{textAlign:'center',border:'1px solid black'}}>UNIT</th>
                    <th style={{textAlign:'center',border:'1px solid black'}}>COST PER UNIT ($)</th>
                    <th style={{textAlign:'center',border:'1px solid black'}}>Amount ($)</th>
                    
                    {/* <th>Due Amount</th> */}
                </tr>
            </thead>
            <tbody style={{backgroundColor:'white'}}>
                {
                    SalesList?
                    SalesList.length>0?
                    SalesList.map((data)=>{
                    return(
                        <tr>
                        {/* <td>{moment(data.createdate).format('DD-MM-YYYY')}</td> */}
                        <td style={{border:'1px solid black'}}>{data.garmentchildname}</td>
                        <td style={{border:'1px solid black'}}>{data.orderid}</td>
                        <td style={{border:'1px solid black'}}>{data.reference_id}</td>
                        <td style={{textAlign:'center',border:'1px solid black'}}>1</td>
                        <td style={{textAlign:'center',border:'1px solid black'}}>$ {parseFloat(data.garmentfinalamount).toFixed(2)}</td>
                        <td style={{textAlign:'center',border:'1px solid black'}}>$ {parseFloat(data.garmentfinalamount).toFixed(2)}</td>
                        {/* <td>$ {parseFloat(data.paidamount).toFixed(2)}</td> */}
                       
                        </tr>
                    )
                    })
                    :<div>Data not found</div>
                    :<div>Data not found</div>
                }
                <tr >
                <td colSpan='4'></td>
                <td style={{textAlign:'center',border:'1px solid black'}}>Total</td>
                <td style={{fontSize:'20px' , fontWeight:'bold',border:'1px solid black'}}> $ {parseFloat(Number(totalsum).toFixed(2))}  </td>
                </tr>
                <tr>
                <td colSpan='4'></td>
                <td style={{textAlign:'center',border:'1px solid black'}}>Deposit Paid</td>
                <td style={{fontSize:'20px' , fontWeight:'bold',border:'1px solid black'}}>$ {paidsum==="NaN"?0:parseFloat(Number(paidsum)).toFixed(2)}</td>
                </tr>
                <tr>
                <td colSpan='4'></td>
                <td style={{textAlign:'center',border:'1px solid black'}}>Balance</td>
                <td style={{fontSize:'20px' , fontWeight:'bold',border:'1px solid black'}}>$ {parseFloat(Number(totalsum)-Number(paidsum).toFixed(2))}</td>
                </tr>
               
            </tbody>
        </table>
            <div className="row" style={{marginTop:'60px'}}>
                <div className="col-md-6" style={{margin:'0px'}}>
                    <p style={{fontSize:'18px'}}>Bank Details: <b>CommonWealth Bank</b> 
                        <br></br>Account Name: <b>K D TAILOR PTY LTD</b>
                        <br></br>BSB: <b>062692</b>
                        <br></br>Account NO: <b>47156156</b>
                    </p>
                </div>
                <div className="col-md-6" style={{margin:'0px'}}>
                   
                </div>
            </div>
            <div style={{textAlign:'center',fontSize:'18px',marginTop:'10px'}}>
						Thank you for your business
            </div>
            </div>
           
    </div>
    
    <button id="printbutton" className="btn btn-info" style={{marginLeft:'20px',marginTop:'40px',fontSize:'20px',background:'#000'}} onClick={printDocument}>Print</button>
    <Link to='/afterSign' id="exitbutton" className="btn btn-info" style={{marginLeft:'20px',marginTop:'40px',fontSize:'20px',background:'#000'}}>Exit</Link>  
    </div>
  )
}

export default CustomerReport