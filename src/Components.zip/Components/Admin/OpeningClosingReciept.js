import { data } from 'jquery';
import React, { useEffect } from 'react'
import { useState } from 'react/cjs/react.development';
import { SelectPaymentid, UpdateOrderId } from '../Function/Payment';
import { ReceiptServices } from '../Function/Receipt';
import Barcodes from 'react-barcode'
import { useHistory } from 'react-router';
import moment from 'moment';
import { InsertOpeningClosingBalance, SelectOpeningClosingBalance } from '../Function/OpeningClosingBalance';
const API_Base_Url = process.env.REACT_APP_API_BASE_URL;

export default function OpeningClosingReciept() {

    const history = useHistory()
    var myVar= ""
    useEffect(()=>{
        if(!(localStorage.getItem("username"))){
            history.push('/')
            
        }else{
            loadData();
           
        }
        
        
    },[])
    
    const [receiptdata , setreceiptdata] = useState([])
    const [check , setcheck]=useState(null)   
    const d = new Date()
    const date = moment(d).format('YYYY-MM-DD')


    
    
    const loadData = () =>{
        var req={
            "date":date
        }
        SelectOpeningClosingBalance(req).then(res=>{
            const result = res;
            if(result!==undefined){
                if(result===null){
                    setreceiptdata([])
                }else{
                    setreceiptdata(result.data)
                    setcheck(1)
                    setTimeout(function(){
                        window.print()
                        
                        // stopColor()
                        history.push('/afterSign')
                     }, 2000);
                    
                }
                               
            }else{
                setreceiptdata([])
            }
        }).catch()
    }
   
    if(check===null){
        return<div></div>
    }
    return (
        <>
        {/* <div> */}
        {/* <image style={{width:'50px'}} ref={inputRef} /> */}
        
        {/* </div> */}
        <div className="ticket" style={{}}>
            <img src={API_Base_Url+"getFile/kdlogo.png"} alt="Logo"/><br></br>
            <p style={{marginTop:'15px',fontSize:'20px',marginBottom:'15px'}} className="centered">
                <br></br>ABN : 83 654 448 192
                <br></br>Shop 212 ,Centrepoint Shopping Center, 70 Murray Street, Hobart 7000
                <br></br>0362006963</p>

                <div className="row centered">
                    <div className="col-md-12" style={{margin:'0px'}}>
                    <p style={{marginTop:'15px',fontSize:'20px',marginBottom:'15px'}} className="centered">
                    <br></br>Date : {moment(receiptdata.date).format("DD-MM-YYYY")}
                    <br></br>Opening Balance :{parseFloat(Number(receiptdata.openingbalance)).toFixed(2)}
                    <br></br>Closing Balance :{parseFloat(Number(receiptdata.closingbalance)).toFixed(2)}
                    </p>
                        
                    </div>
                </div>
          
        </div>
        
        {/* <button id="btnPrint" onClick={printreceipt} className="hidden-print" hidden>Print</button> */}
        </>
    )
}
