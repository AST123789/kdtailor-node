import React, { useEffect } from 'react'
import { Link,useHistory } from 'react-router-dom'
import { useState } from 'react/cjs/react.development'
import SideBar from './wcommon/SideBar'
import $ from 'jquery'
import Model from './wcommon/Model';
import Header from './wcommon/header'
import { JacketInnerServices, JackettInnerChildServices, ServicesCategoryData } from '../Function/JacketServices'

function JacketServices() {

   const [jackettype , setjackettype]=useState([]);
   const history = useHistory()

   useEffect(()=>{
    if(!(localStorage.getItem("username"))){
      history.push('/')
      
  }else{
      $('#MiddleDiv').hide()
      $('#ChildDiv').hide()
      $('#ChildDiv1').hide()
      $('#ChildDiv2').hide()
      loadType();
  }
   },[])

   const loadType=()=>{
      ServicesCategoryData().then(res=>{
         const result = res;
         if(result!==undefined){
            if(result.data == null){
               setjackettype([]);
            }else{
               setjackettype(result.data);
            }
         }else{
            setjackettype([]);
         }
      }).catch();
   }

   const loadInnerServices = (e,parentname)=>{
      e.preventDefault()
      localStorage.setItem("middlegarment",parentname)
      JacketInnerServices(parentname).then(res=>{
         const result = res;
         if(result!==undefined){
            if(result.data==null){
               setjackettype([]);
            }else{
               setjackettype(result.data);
               $('#ParentDiv').hide()
               $('#MiddleDiv').show()
               $('#ChildDiv1').show()
            }
         }else{
            setjackettype([]);
         }
      }).catch();
   }

   const loadInnerChildServices = (e,middlename)=>{
      e.preventDefault()
      localStorage.setItem("childgarmentname",middlename)
      JackettInnerChildServices(localStorage.getItem("middlegarment"),middlename).then(res=>{
         const result = res;
         if(result!==undefined){
            if(result.data==null){
               setjackettype([]);
            }else{
               setjackettype(result.data);
               $('#ChildDiv').show()
               $('#ChildDiv2').show()
               $('#MiddleDiv').hide()
               $('#ChildDiv1').hide()
            }
         }else{
            setjackettype([]);
         }
      }).catch();
   }

   const addgarment = (garmentname,price)=>{
      localStorage.setItem("childgarment",garmentname)
      localStorage.setItem("childprice",price)
   }
   const ReturnRequest=(e)=>{
      e.preventDefault()
    //   setjackettype([])
      $('#ChildDiv1').hide()
      $('#MiddleDiv').hide()
      $('#ParentDiv').show()
      loadType()
   }
   const ReturnRequest1=(e)=>{
    e.preventDefault()
    setjackettype([])
    loadInnerServices(e,localStorage.getItem("middlegarment"))
    $('#ChildDiv').hide()
    $('#ChildDiv1').show()
    $('#ChildDiv2').hide()
    $('#MiddleDiv').show()
 }

    return (
        <>
        <SideBar/>
        <Header/>
        

                       <div className="buttons_w3ls_agile">
								
                       <div id="ParentDiv"  className="col-md-8 button_set_one three agile_info_shadow">
                            
                                   
                            <h3  className="w3_inner_tittle two"> </h3>

                               {
                       jackettype?
                       jackettype.length>0?
                       jackettype.map((data)=>{
                          return(
                             <Link type = "button" onClick={(e)=>loadInnerServices(e,data.services_parent_name)} class = "btn btn-primary" style={{backgroundColor:'black'}}>{data.services_parent_name}</Link>
                          )
                       }):<div style={{textAlign:'center'}}><img src="loader.gif"/></div>:<div>Data Not Found</div>
                    }

                            <div className="clearfix"></div>
                         </div>
                              <div id="MiddleDiv"  className="col-md-8 button_set_one three agile_info_shadow">
                            
                                   
										 <h3  className="w3_inner_tittle two"> </h3>

											{
                                    jackettype?
                                    jackettype.length>0?
                                    jackettype.map((data)=>{
                                       return(
                                          <Link type = "button" onClick={(e)=>loadInnerChildServices(e,data.services_middle_name)} class = "btn btn-primary" style={{backgroundColor:'black'}}>{data.services_middle_name}</Link>
                                       )
                                    }):<div style={{textAlign:'center'}}><img src="loader.gif"/></div>:<div>Data Not Found</div>
                                 }

									     <div className="clearfix"></div>
								      </div>

                              <div id="ChildDiv" className="col-md-8 button_set_one three agile_info_shadow">
                            
                                   
										 <h3  className="w3_inner_tittle two"> </h3>

											{
                                    jackettype?
                                    jackettype.length>0?
                                    jackettype.map((data)=>{
                                       return(
                                          <>
                                          
                                          <button onClick={(e)=>addgarment(data.service_child_name,parseFloat(data.services_child_price).toFixed(2))} data-toggle="modal" data-target="#myModal"  class = "btn btn-primary" style={{backgroundColor:'black'}}><h5>{data.service_child_name}</h5><br></br><h4>$ {parseFloat(data.services_child_price).toFixed(2)}</h4></button>
                                          </>
                                          )
                                    }):<div style={{textAlign:'center'}}><img src="loader.gif"/></div>:<div>Data Not Found</div>
                                 }

									     <div className="clearfix"></div>
								      </div>

                                 <div className="col-md-3  button_set_one three one agile_info_shadow">
                           <div id="holder">

                           <div  className="button">
                                    <Link onClick={(e)=>localStorage.setItem("number",Number(localStorage.getItem("number"))-1)} to='/Garmentlist'>
                                       <p className="btnText">Garment List</p>
                                                    
                                    </Link>
                           </div>
                           
                                 <div  className="button">
                                    <Link to='/GarmentType'>
                                       <p className="btnText">Return To Top</p>
                                                    
                                    </Link>
                                 </div>
                                 <div id="ChildDiv1" className="button" style={{height:'100%'}} >
                                       <Link  onClick={(e)=>ReturnRequest(e)}>
                                             <p className="btnText">Return To Previous Department</p>
                                       </Link>
                                 </div>
                                 <div id="ChildDiv2" className="button" style={{height:'100%'}} >
                                       <Link  onClick={(e)=>ReturnRequest1(e)}>
                                             <p className="btnText">Return To Prev Department</p>
                                       </Link>
                                 </div>         
                                                 
                                            
                           </div>
                  </div>  

                                
                                </div>

                                <Model/>
        </>
    )
}

export default JacketServices