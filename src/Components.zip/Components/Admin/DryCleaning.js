import React, { useEffect,useState } from 'react'
import { Link,useHistory } from 'react-router-dom'
import SideBar from './wcommon/SideBar'
import $ from 'jquery'
import Model from './wcommon/Model';
import { DryInnerChildServices, DryServicesCategoryData } from '../Function/DryCleaning'

function DryServices() {
   // localStorage.setItem("garmentlist",JSON.stringify({}))
   const [drytype , setdrytype]=useState([]);
   const history = useHistory()
   useEffect(()=>{
      if(!(localStorage.getItem("username"))){

         history.push('/')
         
     }else{
        $('#ChildDiv').hide()
        $('#ChildDiv1').hide()
      loadType();
     }
   },[])

   const loadType=()=>{
      DryServicesCategoryData().then(res=>{
         const result = res;
         if(result!==undefined){
            if(result.data == null){
               setdrytype([]);
            }else{
               setdrytype(result.data);
               localStorage.setItem('idgarment','drycleaning')
            }
         }else{
            setdrytype([]);
         }
      }).catch();
   }

   const loadInnerChildServices = (e,middlename)=>{
      e.preventDefault()
      localStorage.setItem("childgarmentname",middlename)
      DryInnerChildServices(middlename).then(res=>{
         const result = res;
         if(result!==undefined){
            if(result.data==null){
               setdrytype([]);
            }else{
               setdrytype(result.data);
               $('#MiddleDiv').hide()
               $('#ChildDiv').show()
               $('#ChildDiv1').show()
            }
         }else{
            setdrytype([]);
         }
      }).catch();
   }

   const addgarment = (garmentname,price)=>{
      localStorage.setItem("childgarment",garmentname)
      localStorage.setItem("childprice",price)
   }

   const ReturnRequest=(e)=>{
    e.preventDefault()
    setdrytype([])
    $('#ChildDiv').hide()
    $('#ChildDiv1').hide()
    $('#MiddleDiv').show()
    loadType()
 }
    return (
        <>
        <SideBar/>
            <div className="buttons_w3ls_agile">
               <div id="MiddleDiv"  className="col-md-8 button_set_one three agile_info_shadow">
                     <h3  className="w3_inner_tittle two"> </h3>

                  {
                     drytype.map((data)=>{
                        return(
                           <Link type = "button" onClick={(e)=>loadInnerChildServices(e,data.garment_middle_name)} class = "btn btn-primary" style={{backgroundColor:'black'}}>{data.garment_middle_name}</Link>
                        )
                     })
                  }

                  <div className="clearfix"></div>
               </div>

               <div id="ChildDiv" className="col-md-8 button_set_one three agile_info_shadow">
               
                     
                  <h3  className="w3_inner_tittle two"> </h3>

                  {
                     drytype.map((data)=>{
                        return(
                           <>
                           {/* <Link  data-toggle="modal" data-target="#myModal"  class = "btn btn-primary" style={{backgroundColor:'black'}}><h5>{data.services_child_name}</h5><br></br><h4>${data.services_child_price}</h4></Link> */}
                           <button onClick={(e)=>addgarment(data.garment_child_name,data.garment_child_price)} data-toggle="modal" data-target="#myModal"  class = "btn btn-primary" style={{backgroundColor:'black'}}><h5>{data.garment_child_name}</h5><br></br><h4>${parseFloat(data.garment_child_price).toFixed(2)}</h4></button>
                           </>
                           )
                     })
                  }

                  <div className="clearfix"></div>
               </div>

               <div className="col-md-4  button_set_one three one agile_info_shadow">
                  <div id="holder">

                        <div  className="button">
                                 <Link to='/Garmentlist'>
                                    <p className="btnText">Garment List</p>
                                                
                                 </Link>
                        </div>
                        <div  className="button">
                           <Link to='/GarmentType'>
                              <p className="btnText">Return To Top</p>
                                          
                           </Link>
                        </div>
                        <div id="ChildDiv1" className="button" style={{height:'100%'}} >
                              <Link  onClick={(e)=>ReturnRequest(e)}>
                                    <p className="btnText">Return To Previous Department</p>
                              </Link>
                        </div>     
                  </div>
               </div>
            </div>
         <Model/>
        </>
    )
}

export default DryServices