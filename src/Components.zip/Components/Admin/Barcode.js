import React from 'react';
import Barcodes from 'react-barcode'
export default function Barcode() {

    // const { inputRef } = useBarcode({
    //     value: "receiptdata",
    //     options: {
    //       background: '#ccffff',
    //     }
    //   });
    // localStorage.setItem("barcodedata",inputRef)
    return (
        <div>
              <Barcodes value="http://github.com/kciter" />
        </div>
    )
}
