import React,{ useState,useEffect } from 'react'
import { Link,Prompt,useHistory } from 'react-router-dom'
import { InsertCustomerData, SelectCustomerList } from '../Function/customer'
import Footer from './wcommon/footer'
import $ from 'jquery'

function Registeration() {

    const [firstname,setfirstname] = useState("")
    const [lastname,setlastname] = useState("")
    const [number,setnumber] = useState("")
    const [email,setemail] = useState("")
    const [check,setcheck] = useState(0)
    const [enablebutton,setenablebutton] = useState(0)
    const history = useHistory()

    // useEffect(()=>{
        
    // },[])
    const openFullscreen = (e) =>{
        e.preventDefault()
        setenablebutton(1)
        var elem = document.documentElement;

         if (elem.requestFullscreen) {
            elem.requestFullscreen();
          } else if (elem.webkitRequestFullscreen) {
            elem.webkitRequestFullscreen();
          } else if (elem.msRequestFullscreen) { 
            elem.msRequestFullscreen();
            // closeFullscreen()
          }
    }

      function ExitScreen(e){
        // <Prompt message="Are you sure you want to leave?" />
          e.preventDefault()
          window.location.reload()
      }

    const submit = (e)=>{
        e.preventDefault()
        var req={
            "name":firstname,
            "surname":lastname,
            "phone":number,
            "email":email
        }
        
        InsertCustomerData(req).then((response)=>{
            const result = response
            if(result !== undefined)
            {
                // alert(result.message)
            }
            else{
                alert("Something went wrong. Please try again")
            }
        }).catch()

        if(Number(localStorage.getItem("customerregisterationnum"))===1){
            SelectCustomerList().then(res=>{
            const result = res;
            if(result!==undefined){
               if(result.data == null){
                  
               }else{ 
                  localStorage.setItem("customername",result.data[0].name+" "+result.data[0].surname)
                  localStorage.setItem("customerid",result.data[0].cust_id)
               }
            }
         }).catch();
         setTimeout(function(){
            
         },1000)
        }
        else{
            setcheck(1)
            setTimeout(function(){
                setcheck(0)
                setfirstname("")
                setlastname("")
                setnumber("")
                setemail("")
            },1000)
        }
    }

    return (
        <>
        <div className="inner_content" style={{padding:'0rem'}}>
				    {
                        enablebutton===0?<button onClick={(e)=>openFullscreen(e)}>Enable</button>:<button onClick={(e)=>ExitScreen(e)}>Exit</button>
                    }
					<div className="inner_content_w3_agile_info">
					<div style={{textAlign:'center'}}>
						<img style={{width:'25%', height:'150px'}} src='kdtailor.jpeg'/>
                    </div>
                    {
                        check===1?<div style={{textAlign:'center',color:'white',fontSize:'30px',backgroundColor:'green',border:'2px solid black',margin:'3%'}}>Customer Successfully registered</div>:null
                    }
                    
                    <div className="registration admin_agile">
                        <div className="signin-form profile admin">
                            <h2>Customer Registeration</h2>
                            <div className="login-form">
                                <form method="post">
                                    <input type="text" name="name" placeholder="Enter Firstname" value={firstname} required onChange={(e)=>setfirstname(e.target.value)}/>
                                    <input type="text" name="lastname" placeholder="Enter Lastname" value={lastname} required onChange={(e)=>setlastname(e.target.value)}/>
                                    <input type="text" name="number" placeholder="Enter Phone number" value={number} required onChange={(e)=>setnumber(e.target.value)}/>
                                    <input type="email" name="email" placeholder="Enter Email" value={email} onChange={(e)=>setemail(e.target.value)}/>
                                    <Link onClick={(e)=>submit(e)} style={{color:'#fff'}}>
                                        <div className="tp login_button">
                                            Register 
                                        </div>
                                    </Link>
                                </form>
                            </div>
                        </div>
                    </div>
				</div>
				</div>
                <Footer/>
                </>
    )
}

export default Registeration
