import React, { useEffect } from 'react'
import { useState } from 'react/cjs/react.development';
import { ReceiptServices } from '../Function/Receipt';
import Barcodes from 'react-barcode'
import { useHistory } from 'react-router';
import moment from 'moment';
const API_Base_Url = process.env.REACT_APP_API_BASE_URL;

export default function ViewTicketReciept() {

    const history = useHistory()
    useEffect(()=>{
        if(!(localStorage.getItem("username"))){
            history.push('/')
            
        }else{
        loadReceiptData(localStorage.getItem("paymentid"))
        }
    },[])

    const [receiptdata , setreceiptdata] = useState([])   
    const d = new Date()

    const loadReceiptData = (paymentid) =>{
        ReceiptServices(paymentid).then(res=>{
            const result = res;
            if(result!==undefined){
                if(result==null){
                    setreceiptdata([])
                }else{
                    setreceiptdata(result.data)
                    setTimeout(function(){
                        window.print()
                        localStorage.clear()
                        history.push('/')
                    },1000)
                }
            }else{
                setreceiptdata([])
            }
        }).catch();
    }

    return (
        <>
        {
            receiptdata?
            receiptdata.length>0?
        (<div className="ticket"  style={{}}>
            <img src={API_Base_Url+"getFile/kdlogo.png"} alt="Logo"/><br></br>
            <p style={{marginTop:'15px',fontSize:'20px',marginBottom:'15px'}} className="centered">
                ABN : 83 654 448 192
                <br></br>Shop 212 ,Centrepoint Shopping Centre, 70 Murray Street, Hobart 7000
                <br></br>0362006963
            </p>

                <h2 style={{textAlign:'center',marginBottom:'15px',fontSize:'23px',fontWeight:'bold'}}>{receiptdata[0].payment_id}</h2>

                <div className="row">
                    <div  className="col-md-12" style={{margin:'0px'}}>
                    <p><span style={{fontWeight:'bold', fontSize:'20px',textTransform:'uppercase'}}>{receiptdata[0].customername}</span>
                    <br></br><span style={{fontWeight:'bold', fontSize:'22px'}}>{receiptdata[0].phone}</span>
                            <br></br>{moment(d).format("DD-MM-YYYY")} {moment(d).format("h:mm a")}
                            </p>
                            </div>
                </div>
                <hr></hr>
                <div className="row">
                    <div className="col-md-5" style={{margin:'0px'}}>
                        <p>Secured by:
                            <br></br>Pickup:
                        </p>
                    </div>
                    <div className="col-md-7" style={{margin:'0px'}}>
                        <p>KETAN
                            <br></br>{receiptdata[0].pickupdate} {receiptdata[0].pickuptime}
                        </p>
                    </div>
                </div>
                
                
            <table>
                <thead>
                    <tr>
                        <th className="description">Description</th>
                        <th className="quantity">Qty.</th>
                        <th className="price">Total</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        
                        receiptdata.map((item)=>{
                            
                            return(
                               <tr>
                                <td className="description">{item.garmentchildname}<br></br>Color:{item.color}<br></br>Price: $ {parseFloat(item.garmentchildprice).toFixed(2)} Discount:  $ {parseFloat(item.pricediscount).toFixed(2)}<br></br>{item.instructions?"Instructions: "+item.instructions:null}<br></br><span style={{fontWeight:'bold', fontSize:'17px'}}>{receiptdata[0].paymentstatus==="ordered"?null:"Services Picked Up"}</span></td>
                                <td className="quantity">1</td>
                                <td className="price">$ {parseFloat(item.garmentfinalamount).toFixed(2)}</td>
                               </tr>
                            )
                            
                        })
                    }
                    <tr>
                        {/* <td className="description"></td> */}
                        <td className="quantity" colSpan='2' style={{textAlign:'right'}}>Total Garments : </td>
                        <td className="price">{receiptdata.length}</td>
                    </tr>
                    
                    <tr>
                        
                        <td className="quantity" colSpan='2' style={{textAlign:'right'}}>Grand Total(Inc GST):</td>
                        <td className="price">$ {parseFloat(receiptdata[0].totalamount).toFixed(2)}</td>
                       
                    </tr>
                    <tr>
                        {/* <td className="description"></td> */}
                        <td className="quantity" colSpan='2' style={{textAlign:'right'}}>GST:</td>
                        <td className="price">$ {parseFloat(10*(receiptdata[0].totalamount)/100).toFixed(2)}</td>
                    </tr>
                
                    {
                        receiptdata[0].cash?<tr>
                        
                        <td className="quantity" colSpan='2' style={{textAlign:'right'}}>Cash Amount</td>
                        <td className="price">$ {parseFloat(receiptdata[0].cash).toFixed(2)}</td>
                    </tr>:null
                    }
                    {
                        receiptdata[0].card?<tr>
                        
                        <td className="quantity" colSpan='2' style={{textAlign:'right'}}>Card Amount</td>
                        <td className="price">$ {parseFloat(receiptdata[0].card).toFixed(2)}</td>
                    </tr>:null
                    }
                    {
                        receiptdata[0].account?<tr>
                        
                        <td className="quantity" colSpan='2' style={{textAlign:'right'}}>Account Amount</td>
                        <td className="price">$ {parseFloat(receiptdata[0].account).toFixed(2)}</td>
                    </tr>:null
                    }
                    
                    <tr>
                        {/* <td className="description"></td> */}
                        <td className="quantity" colSpan='2' style={{textAlign:'right'}}>Paid Amount</td>
                        <td className="price">$ {parseFloat(receiptdata[0].paidamount).toFixed(2)}</td>
                    </tr>
                    
                    <tr>
                        {/* <td className="description"></td> */}
                        <td className="quantity" colSpan='2' style={{textAlign:'right'}}>Due Amount</td>
                        <td className="price">$ {parseFloat(receiptdata[0].dueamount).toFixed(2)}</td>
                    </tr>
                </tbody>
            </table>
            <div className="centered" >
            <Barcodes  value={receiptdata[0].payment_id} />
            
            </div>

            <div className='centered' >
                    <h3 style={{marginTop:'10px'}}>Please Collect Your Garments Within 3 Months</h3>                   
                    <img src="qrcode.png" alt='qr'/>
                    <h3 style={{marginTop:'10px',marginBottom:'10px'}}>Please provide google review by scanning Qr Code</h3>
            </div>
           
        </div>):<div><img src="loader.gif" alt="logo"/></div>:<div>No Data Found</div>
        }
        </>
    )
}
