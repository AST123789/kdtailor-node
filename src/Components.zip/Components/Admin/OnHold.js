import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { SelectGarmentOnHoldList, Updateholddata, UpdateUnholddata } from '../Function/Garment';
import $ from 'jquery'

function OnHold() {
    const [garmentorderlist , setgarmentorderlist] = useState([]);
    
   useEffect(()=>{
       garmentList();
       garmentList()
   },[]); 

    const garmentList = () => {
        SelectGarmentOnHoldList().then(res=>{
            const result = res;
            if(res !== undefined)
            {
                if(res === null)
                {
                    setgarmentorderlist([])
                }
                else{
                    setgarmentorderlist(result.data)
                }
            }
            else{
                setgarmentorderlist([])
            }
        })
}    

const UpdateUnHoldData = (id,name) =>{
    var req = {
        "customerid":id,
        "hold":'unhold'
    }
    UpdateUnholddata(req).then(res=>{
        localStorage.setItem("customerid",id)
        localStorage.setItem("customername",name)
    })
    window.$('#onhold').modal('hide')
}

  return (
    <div className="modal" id="onhold">
    <div className="modal-dialog" style={{textAlign:'center'}}>
        <div className="modal-content" style={{width:'900px'}}>
            {/* Modal Header */}
            <div className="modal-header">
                <h4 className="modal-title">Garment List</h4>
                <button type="button" className="close" data-dismiss="modal">&times;</button>
            </div>
            {/* Modal body */}
            <div className="modal-body">
                <div className="w3l-table-info agile_info_shadow">
                    <div className="row">
                    <div className="search-form col-md-6">		
                        {/* <input type="text" data-toggle="dropdown" className="form-control" placeholder="Search customer" value={searchtext} onChange={(e)=>SearchFilter(e)}/>			 */}
                        {/* <i className="fa fa-search"></i>	             */}
                    </div>
                    <div className="col-md-6">
                    
                    </div>
                    </div>
                    <table id="table">
                        <thead>
                            <tr >
                            <th>Id</th>
                            <th>Name</th>
                            <th>Check</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                garmentorderlist.length > 0?
                                garmentorderlist.map((data)=>{
                                    return(
                                        <tr >
                                        <td>{data.customerid}</td>
                                        <td style={{textTransform:'uppercase'}}>{data.customername}</td>
                                        <td>
                                        <Link to="/GarmentList" onClick={()=>UpdateUnHoldData(data.customerid,data.customername)} type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}}>Unhold</Link>
                                            {/* <select onChange={(e)=>setdatahold(e.target.value)}>
                                                <option>{data.hold}</option>
                                                {
                                                    data.hold==='hold'?
                                                        <option value="unhold">Un Hold</option>:
                                                        <option value="hold">Hold</option>
                                                }
                                                
                                            </select> */}
                                        </td>
                                        
                                        </tr>
                                    )
                                })
                                :<tr>Data not found</tr>
                            }
                        </tbody>
                    </table>
                </div>
            </div>
                {/* Modal footer */}
            <div className="modal-footer">
                <Link to="/GarmentList" onClick={()=>window.$('#onhold').modal('hide')} type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} >Ok</Link>
                <button type="button"  className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
  )
}

export default OnHold;
