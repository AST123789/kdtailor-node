import React, { useEffect, useState } from 'react'
import { SelectCustomerData, SelectCustomerList, UpdateCustomerData } from '../Function/customer';
import {Link , useHistory} from 'react-router-dom'
// import SearchField from "react-search-field";
import $ from 'jquery'
import moment from 'moment';
import CustomerDetail from './CustomerDetail';
import { SelectTicketData } from '../Function/ViewTicket';

function CustomerList() {

    const [CustomerList,setCustomerList] = useState([])
    const [searchtext , setsearchtext] = useState('')
    const [tempcustomerlist , settempcustomerlist] = useState([])
    const [customerdata,setcustomerdata] = useState([])
    const [receiptdata , setreceiptdata] = useState([])
    const history = useHistory();

    useEffect(()=>{
        if(!(localStorage.getItem("username"))){
            history.push('/')
            
        }else{
            fetchCustomerList()
            fetchCustomerList()
        }
       
    },[])

    const fetchCustomerList = ()=>{
        SelectCustomerList().then(res=>{
            const result = res;
            if(result!=undefined){
               if(result.data == null){
                  setCustomerList([]);
               }else{ 
                  setCustomerList(result.data);
                  settempcustomerlist(result.data)
               }
            }else{
               setCustomerList([]);
            }
         }).catch();
    }

    const statechange =(e,id,name,surname)=>{
        e.preventDefault()
        localStorage.setItem("customerid",id)
        localStorage.setItem("customername",name+" "+surname)
        history.push('/GarmentList')
    }

    const createcust = (e)=>{
        e.preventDefault()
        window.$('#customerlist').modal('hide')
        localStorage.setItem("customerregisterationnum",1)
        history.push('/registeration')
    }

    const SearchFilter=(e)=>{
        e.preventDefault()
        const searchWord = e.target.value;
		setsearchtext(searchWord);
		const newFilter = tempcustomerlist.filter((value) => {
            if(value.name.toLowerCase().includes(searchWord.toLowerCase())){
                return value.name.toLowerCase().includes(searchWord.toLowerCase());
            }
            else if(value.surname.toLowerCase().includes(searchWord.toLowerCase())){
                return value.surname.toLowerCase().includes(searchWord.toLowerCase());
            }
            else if(value.email.toLowerCase().includes(searchWord.toLowerCase())){
                return value.email.toLowerCase().includes(searchWord.toLowerCase());
            }
            else if(value.phone.toLowerCase().includes(searchWord.toLowerCase())){
                return value.phone.toLowerCase().includes(searchWord.toLowerCase());
            }
		});

		if (searchWord === "") {
		    setCustomerList(CustomerList);
		} else {
		    setCustomerList(newFilter);
		}
    }

    const statecustomer = (e,cust_id)=>{
        e.preventDefault()
        Number(localStorage.setItem("customerid",cust_id))
        window.$('#customerlist').modal("hide")
        loadcustomerData()
    }

    const updatedata = (e,cust_id)=>{
        history.push(`/updatecustomer/${cust_id}`)
    }

    const changedata = (e)=>{
        e.preventDefault()
        setsearchtext('')
        fetchCustomerList()
    }

    const loadcustomerData = () =>{
        SelectCustomerData(Number(localStorage.getItem("customerid"))).then(res=>{
            const result = res;
            if(result!==undefined){
                if(result==null){
                    setcustomerdata([])
                }else{
                    setcustomerdata(result.data)
                }
            }else{
                setcustomerdata([])
            }
        }).catch();
        }

        const loadReceiptData = (e,paymentid) =>{
            e.preventDefault()
            SelectTicketData(paymentid).then(res=>{
                const result = res;
                if(result!==undefined){
                    if((result.data).length===0){
                        setreceiptdata([])
                       
                    }else{
                        setreceiptdata(result.data) 
                        
                    }
                }else{
                    setreceiptdata([])
                    // alert("data not found")
                    history.push('/afterSign')
                    
        
                }
            }).catch();
        }
        
        const setid=(e,id)=>{
            localStorage.setItem("paymentid",id) 
            window.$('#customerdetail').modal("hide")
        }
    return (
        <>
            <div className="modal" id="customerlist">
                <div className="modal-dialog" style={{textAlign:'center'}}>
                    <div className="modal-content" style={{width:'900px'}}>
                        {/* Modal Header */}
                        <div className="modal-header">
                            <h4 className="modal-title">Customer Data</h4>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                        </div>
                        {/* Modal body */}
                        <div className="modal-body">
                            <div className="w3l-table-info agile_info_shadow">
                                <div className="row">
                                <div className="search-form col-md-6">		
                                    <input type="text" data-toggle="dropdown" className="form-control" placeholder="Search customer" value={searchtext} onChange={(e)=>SearchFilter(e)}/>			
                                    {/* <i className="fa fa-search"></i>	             */}
                                </div>
                                <div className="col-md-6">
                                <button type="button" onClick={(e)=>createcust(e)} className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold',float:'right',marginBottom:'30px'}} data-dismiss="modal">Create Customer</button>
                                </div>
                                </div>
                                <table id="table">
                                    <thead>
                                        <tr>
                                        <th>Reference Id</th>
                                        <th>Firstname</th>
                                        <th>Surname</th>
                                        <th>Phone</th>
                                        <th>Email</th>
                                        <th>View Detail</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            CustomerList.length > 0?
                                            CustomerList.map((data)=>{
                                                return(
                                                    <tr key={data.cust_id}>
                                                    <Link onClick={(e)=>statechange(e,data.cust_id,data.name,data.surname)} data-dismiss="modal"><td><button  className="btn btn" style={{backgroundColor:'black',color:'white',padding:'6px 21px',fontWeight:'bold',}}>{data.cust_id}</button> <span style={{display:'none'}}>{data.name} {data.surname}</span></td></Link>
                                                    <td ><Link to="#" style={{ fontWeight:'bold',textTransform:'uppercase'}} data-dismiss="modal" onClick={(e)=>updatedata(e,data.cust_id)}>{data.name}</Link></td>
                                                    <td style={{textTransform:'uppercase'}}>{data.surname}</td>
                                                    <td>{data.phone}</td>
                                                    <td>{data.email}</td>
                                                    
                                                    <button  onClick={(e)=>statecustomer(e,data.cust_id)} type="button" data-target="#customerdetail" data-toggle="modal"><td><button className="btn btn" style={{backgroundColor:'black',color:'white',padding:'6px 21px',fontWeight:'bold'}}>View</button></td></button>
                                                    </tr>
                                                )
                                            })
                                            :<tr>Data not found</tr>
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                            {/* Modal footer */}
                        <div className="modal-footer">
                            <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Ok</button>
                            <button type="button" onClick={(e)=>changedata(e)} className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

            {/* <CustomerDetail /> */}
            <div className="modal" id="customerdetail">
                <div className="modal-dialog" style={{textAlign:'center'}}>
                    <div className="modal-content" style={{width:'800px'}}>
                        {/* Modal Header */}
                        <div className="modal-header">
                            <h4 className="modal-title">Customer Data</h4>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                        </div>
                        {/* Modal body */}
                        <div className="modal-body">
                            <div className="w3l-table-info agile_info_shadow">
                                <table id="table">
                                    <thead>
                                        <tr>
                                            <th>Token Number</th>
                                            <th>Order Id</th>
                                            <th>Total amount</th>
                                            <th>Due Amount</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>Receipt</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            customerdata?
                                            customerdata.length>0?
                                            customerdata.map((data)=>{
                                                let date = moment.utc(data.createdate).format('DD/MM/YYYY')
                                            return(
                                                <tr key={data.payment_id}>
                                                <td onClick={(e)=> loadReceiptData(e,data.payment_id)} data-target='#ordersdetail' data-toggle='modal' >{data.payment_id}</td>
                                                <td>{data.orderid}</td>
                                                <td>$ {parseFloat(data.totalamount).toFixed(2)}</td>
                                                <td>$ {parseFloat(data.dueamount).toFixed(2)}</td>
                                                <td>{date}</td>
                                                <td>{data.paymentstatus}</td>
                                                <td><Link onClick={(e)=>setid(e,data.payment_id)} className="btn btn-info" style={{marginLeft:'20px',background:'#000'}} to="/viewReceipt">Receipt</Link></td>
                                                </tr>
                                            )
                                            })
                                            :<tr>Data not found</tr>
                                            :<tr>Data not found</tr>
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div className="modal-footer">
                            <Link to="ViewReport" onClick={()=>window.$('#customerdetail').modal('hide')} type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}}>View Report</Link>
                            <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>



            {/* Orders Details */}
            {/* <CustomerDetail /> */}
            <div className="modal" id="ordersdetail">
                <div className="modal-dialog" style={{textAlign:'center'}}>
                    <div className="modal-content" style={{width:'800px'}}>
                        {/* Modal Header */}
                        <div className="modal-header">
                            <h4 className="modal-title">Orders Data</h4>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                        </div>
                        {/* Modal body */}
                        <div className="modal-body">
                            <div className="w3l-table-info agile_info_shadow">
                            <table id="table">
            <thead>
                <tr>
                    {/* <th></th> */}
                    <th>Customer Name</th>
                    <th>Order</th>
                    <th>Description</th>
                    <th>Due Date</th>
                    <th>Details</th>
                    <th>Instructions</th>
                    <th>Status</th>
                    <th>Receipt</th>
                </tr>
            </thead>
            <tbody>
                {
                    receiptdata?
                    receiptdata.length>0?
                    receiptdata.map((data)=>{
                    return(
                        <tr key={data.payment_id}>
                        {/* <td><input type="checkbox"/></td> */}
                        <td>{data.customername}</td>
                        <td>{data.orderid}</td>
                        <td>{data.garmentname}<br></br>{data.garmentmiddlename}<br></br>{data.garmentchildname}</td>
                        <td>{data.pickupdate}</td>
                        <td>Garment 1 of 1 /<br></br> Service: 1 of 1</td>
                        <td>{data.instructions?data.instructions:null}</td>
                        <td>{data.status?data.status:null}</td>
                        </tr>
                    )
                    })
                    :<tr>Data Not Found</tr>
                    :<tr>Data Not Found</tr>
                }
            </tbody>
        </table>
                            </div>
                        </div>

                        <div className="modal-footer">
                            
                            <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

            
        </>
    )
}

export default CustomerList