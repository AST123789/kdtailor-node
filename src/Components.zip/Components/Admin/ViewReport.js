import React, { useEffect, useState } from 'react'
import { Link,useHistory } from 'react-router-dom';
import moment from 'moment'
import { SelectViewReportData } from '../Function/ViewReport';


function ViewReport() {
  const [fromdate , setfromdate] = useState("")
  const [enddate , setenddate] = useState("")
  const [SalesList , setSaleslist] = useState([])
  const [check,setcheck] = useState(0)
  const history = useHistory()
  const [referenceCategory,setreferenceCategory] = useState([])
  
  localStorage.setItem("startdates",fromdate);
  localStorage.setItem("enddates",enddate);
  

  useEffect(()=>{
    if(!(localStorage.getItem("username"))){
        history.push('/')
        
    }
  },[])

  const loadSalesReport = (e) =>{
      e.preventDefault()
      var req = {
          "customerid":Number(localStorage.getItem("customerid")),
          "startdate":fromdate,
          "enddate":enddate
      }
      
      SelectViewReportData(req).then(res=>{
          const result = res;
          if(result!==undefined){
            if(result===null){
                setSaleslist([])
            }else{
                setSaleslist(result.data)

                if(result.data.length>0){
                    var category = []
                    result.data.forEach(function (elem){
                        if(category.indexOf(elem.reference_id)===-1){
                            category.push(elem.reference_id);
                        }
                    });
                }
                setreferenceCategory(category)
                localStorage.setItem("paymentid",result.data[0].payment_id)
                setcheck(1)
            }
        }else{
            setSaleslist([])
        }
      }).catch();
    }
    
    const logout = ()=>{
        localStorage.removeItem('username')
        
        history.push('/')
    }

  if(check=== 0 ){
    return (
        <>
        <div style={{textAlign:'right',marginTop:'15px' }}><Link to="#" onClick={(e)=>logout()} style={{backgroundColor:'grey',padding:'15px',color:'white',fontWeight:'bold',fontSize:'20px'}}>LogOut </Link></div>
        <div className="inner_content" style={{padding:'0rem'}}>
				    {/* /inner_content_w3_agile_info*/}
					<div className="inner_content_w3_agile_info">
					<div style={{textAlign:'center'}}>
						<img style={{width:'25%', height:'150px'}} src='kdtailor.jpeg' alt="logo"/></div>
							<div className="registration admin_agile">
                                <div className="signin-form profile admin">
                                    <h2>Select The Period For Sale Reports</h2>
                                    <div className="login-form">
                                        <form action="main-page.html" method="post">
                                            <input type="date" onChange={(e)=>setfromdate(e.target.value)} name="name"  placeholder="From Date" required=""/>
                                            <input type="date" onChange={(e)=>setenddate(e.target.value)} name="password"  placeholder="End Date" required=""/>
                                            <Link to="#"  onClick={(e)=>loadSalesReport(e)} style={{color:'#fff'}}><div className="tp login_button">
                                                    Submit
                                            </div></Link>
                                            
                                        </form>
                                    </div>
                                
                                </div>

				            </div>
					{/* //inner_content_w3_agile_info*/}
				    </div>
		{/* //inner_content*/}
				</div>
                </>
    )
  }

  return (
      <>
    <div style={{textAlign:'right',marginTop:'15px' }}><Link to="#" onClick={(e)=>logout()} style={{backgroundColor:'grey',padding:'15px',color:'white',fontWeight:'bold',fontSize:'20px'}}>LogOut</Link></div>
    <br></br>
    <div  id="genratepdf" className="w3l-table-info agile_info_shadow" style={{backgroundColor: '#f5f5f5',
        width: '100%',
        minHeight: '297mm',
        marginLeft: 'auto',
        marginRight: 'auto'}}>
            {
                    referenceCategory.map((category)=>{
                        let referencecategoryby = SalesList.filter(function (cat) {
                                return  cat.reference_id === category;
                            }).map(function (data) {
                                
                                return data;
                            })
                           
                            return(
                                <table id="table">
            <thead>
                <tr>
                    <th> Date</th>
                    <th>Customer Name</th>
                    <th>Invoice No.</th>
                    <th>Reference</th>
                    <th>Customer Id</th>
                    <th>Reciept No.</th>
                    <th>Service Name</th>
                    <th>Service Price</th>
                    
                    
                    {/* <th>Due Amount</th> */}
                </tr>
            </thead>
            <tbody>
                {   
                    referencecategoryby?
                    referencecategoryby.length>0?

                    referencecategoryby.map((data)=>{
                    return(
                        <tr>
                        <td>{moment(data.currentdate).format('DD-MM-YYYY')}</td>
                        <td>{data.customername}</td>
                        <td>{data.orderid}</td>
                        <td>{data.reference_id}</td>
                        <td>{data.customerid}</td>
                        <td>{data.payment_id}</td>
                        <td>{data.garmentchildname}</td>
                        <td>{data.garmentfinalamount}</td>
                        </tr>
                    )
                    })
                    :<div>Data not found</div>
                    :<div>Data not found</div>
                } 
  
            </tbody>
        </table>
                                )
                            })
                    
            }
            <Link className="btn btn-info" style={{marginLeft:'20px',marginTop:'40px',fontSize:'20px',background:'#000'}} to="/printViewReport">Export PDF</Link>
        
                {/* <div style={{fontSize:'20px' , fontWeight:'bold' , textAlign:'right' , marginRight:'50px',paddingTop:'15px'}}>Total Due Amount $ {parseFloat(totalsum - paidsum).toFixed(2)}</div> */}
        
    </div>
    {/* <button onClick={(e)=>download_pdf()}>Download Pdf</button> */}
    
    </>
  )
}

export default ViewReport