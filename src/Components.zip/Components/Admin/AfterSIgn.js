
import moment from 'moment'
import React, { useEffect, useState } from 'react'
import { Link,useHistory } from 'react-router-dom'
import { InsertOpeningClosingBalance, SelectBalance, SelectOpeningClosingBalance, UpdateClosingBalance } from '../Function/OpeningClosingBalance'
import { SelectSalesReportData } from '../Function/SalesReport'
import CustomerList from './CustomerList'
import EditTicketNumber from './EditTicket'
import SideBar from './wcommon/SideBar'
import TicketNumber from './wcommon/TicketNumber'
import $ from 'jquery'
import OnHold from './OnHold'

function AfterSign() {


    const history = useHistory()
    const d = new Date()
    const [fromdate , setfromdate] = useState(moment(d).format("YYYY-MM-DD"))
    const [enddate , setenddate] = useState(moment(d).format("YYYY-MM-DD"))
    const [SalesList , setSaleslist] = useState([])
    const [check,setcheck] = useState(0)
    const [totalsum,settotalsum] = useState(0)
    const [paidsum,setpaidsum] = useState(0)
    const [totalcash , settotalcash] = useState(0)
    const [totalcard , settotalcard] = useState(0)
    const [totalaccount , settotalaccount] = useState(0)
    const [openingbalance , setopeningbalance] = useState(0)
    const [closingbalance, setclosingbalance] = useState(0)
    const [fetchdata , setfetchdata] = useState([])
    const [checkopeningbalance,setcheckopeningbalance]=useState(null)
    const [checkclosingbalance,setcheckclosingbalance]=useState(null)

    useEffect(()=>{
        localStorage.setItem("number",0)
        if(!(localStorage.getItem("username"))){
            history.push('/')
            
        }else{
            localStorage.setItem("balancedata",0)
            loadData();
            loadSalesReport();
            selectBalance();
        }
    },[])

    const loadSalesReport = () =>{
        window.$('#cashdrawer').modal('hide')
          var req = {
              "fromdate":fromdate,
              "enddate":enddate
          }
    
          SelectSalesReportData(req).then(res=>{
              const result = res;
              if(result!==undefined){
                if(result===null){
                    setSaleslist([])
                }else{
                    setSaleslist(result.data)
                    var total=0,paid=0,cash=0,card=0,account=0
                    for(var i=0;i<(result.data).length;i++)
                    {
                        total = total+result.data[i].totalamount
                        paid = paid+(result.data[i]).paidamount
                        cash = cash+(result.data[i]).cash
                        card = card+(result.data[i]).card
                        account = account+(result.data[i]).account
                    }
                    settotalsum(total)
                    setpaidsum(paid)
                    // settotalcash(cash)
                    // settotalcard(card)
                    // settotalaccount(account)
                    setcheck(1)
                }
            }else{
                setSaleslist([])
            }
          }).catch();
            
        }

    const OpeningFunction = (e) =>{
        var req = {
            "date":fromdate,
            "openingbalance":openingbalance
        }
        InsertOpeningClosingBalance(req).then(res=>{
            const result = res;
            if(result!==undefined)
            {
                
            }
        }).catch()
        setopeningbalance('')
        loadData();
        loadData();
    }


    const ClosingFunction = (e) =>{
        var req = {
            "date":fromdate,
            "closingbalance":Number(closingbalance)
        }

        UpdateClosingBalance(req).then(res=>{
            const result = res;
            if(result!==undefined)
            {
              
            }
        }).catch()
        setclosingbalance('')
        
    }

    const selectBalance = (e) =>{
        var req = {
            "date":fromdate,
        }

        SelectBalance(req).then(res=>{
            const result = res;
            // alert("hi")
            if(result!==undefined)
            {
                let sumcash=0
                let sumcard=0
                let sumaccount=0
                for(let j=0;j<result.data.length;j++){
                    sumcash = sumcash+result.data[j].cash
                    sumcard = sumcard+result.data[j].card
                    sumaccount = sumaccount+result.data[j].account
                }
                settotalcash(sumcash)
                settotalcard(sumcard)
                settotalaccount(sumaccount)
            }
        }).catch()
        setclosingbalance('')
        
    }
    console.log(fromdate,totalcash,totalcard,totalaccount)
    const loadData = () =>{
        var req={
            "date":fromdate
        }
        SelectOpeningClosingBalance(req).then(res=>{
            const result = res;
            if(result!==undefined){
                if(result===null){
                    setfetchdata([])
                }else{
                    setfetchdata(result.data)
                    if(result.data)
                    {
                        setcheckopeningbalance(Number(result.data.openingbalance))
                        setcheckclosingbalance(result.data.closingbalance)
                    }
                    else
                    {
                        setcheckopeningbalance(null)
                        setcheckclosingbalance(null)
                    }
                }
                               
            }else{
                setfetchdata([])
            }
        }).catch()
    }

    const OpenCashDrawer = ()=>{
            var req = {
                "date":fromdate,
                "openingbalance":checkopeningbalance?checkopeningbalance:0
            }

            InsertOpeningClosingBalance(req).then(res=>{
                const result = res;
                if(result!==undefined)
                {   
                   
                }
            }).catch()
        }

    return (
        <>
            <SideBar/>
            <div className="buttons_w3ls_agile">
                <div className="button_set_one three one agile_info_shadow">
                    <div id="holder">
                        <Link to="/barcodescan">
                            <div className="button">
                                <p className="btnText">Pick Up</p>
                            </div>
                        </Link>
                        <Link to="/alteration">
                        <div className="button">
                            <p className="btnText">Drop Off</p>
                        </div>
                        </Link>
                        <div className="button" data-toggle="modal" data-target="#ticketnumber">
                            <p className="btnText">View Ticket</p>
                        </div>
                        <div className="button" data-toggle="modal" data-target="#customerlist">
                            <p className="btnText">View Customer</p>
                        </div>
                        <div className="button" data-toggle="modal" data-target="#editticket">
                            <p className="btnText">Edit Ticket</p>
                        </div>
                        <div className="button"  data-toggle="modal" data-target="#cashdrawer">
                            <p className="btnText">opening/Closing </p>
                        </div>
                        <div className="button"  data-toggle="modal" data-target="#onhold">
                            <p className="btnText">UnHold </p>
                        </div>
                    </div>         
                </div>
            </div>
            <TicketNumber/>
            <CustomerList/>
            <EditTicketNumber/>
            <OnHold/>


            {/* THIS MODAL IS TWO TYPES OF CATEGORY LIKE OPENING AND CLOSING BUTTON  */}

            <div className="modal" id="cashdrawer">
                <div className="modal-dialog" style={{textAlign:'center'}}>
                    <div className="modal-content" style={{width:'600px'}}>
            
                        {/* Modal Header */}
                        <div className="modal-header">
                            <h4 className="modal-title" style={{fontWeight:'bold'}}>Date : {moment(fromdate).format('DD-MM-YYYY')}</h4>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                        </div>
              
                        {/* Modal body */}
                        <div className="modal-body">
                        <div className="button" onClick={()=>loadSalesReport()} data-toggle="modal" data-target="#openingModal">
                                    <p className="btnText">opening Balance </p>
                                 </div>
                                 <div className="button" onClick={()=>loadSalesReport()} data-toggle="modal" data-target="#closingModal" >
                                    <p className="btnText">Closing Balance</p>
                                 </div>
                          </div>

                            
                    {/* Modal footer */}
                <div className="modal-footer">
                    
                    <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
                </div>
               
            </div>             
            </div>
            </div>
          

            {/* THIS MODAL IS ONLY INSERT AN OPENING BALANCE  */}

            <div className="modal" id="openingModal">
                <div className="modal-dialog" style={{textAlign:'center'}}>
                    <div className="modal-content" style={{width:'600px'}}>
            
                        {/* Modal Header */}
                        <div className="modal-header">
                            <h4 className="modal-title" style={{fontWeight:'bold'}}>Date : {moment(fromdate).format('DD-MM-YYYY')}</h4>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                        </div>
              
                        {/* Modal body */}
                        <div className="modal-body">
                            <div className="wthree_general">
								<div className="grid-1 graph-form agile_info_shadow">
                                    <form className="form-horizontal">
                                        <div className="form-group">
                                            
                                        </div>
                                       
                                            
                                          
                                            <div className="form-group">
                                            <label className="col-md-4 control-label">Opening Balance</label>
                                            <div className="col-md-4">
                                                <div className="input-group">							
                                                    <span className="input-group-addon">
                                                        <i className="fa fa-money"></i>
                                                    </span>
                                                    <input type="text" onChange={(e)=>setopeningbalance(e.target.value)} style={{fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" />
                                                </div>
                                            </div>
                                        </div>
                                        <div style={{textAlign:'right' }}><Link to='printOpeningBalance'  target={'_blank'} onClick={()=>OpenCashDrawer()}  style={{color:'blue'}}>If You Want to check cash in Cash Drawer??</Link></div>
                                        
                                       
                                    </form>                                                
                                </div>
                            </div>
                            
                    {/* Modal footer */}
                <div className="modal-footer">
                    
                        <button type="button" onClick={(e) =>OpeningFunction(e)}  className="btn btn" 
                            style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} 
                            data-dismiss="modal"   >Submit Opening</button>
                        
                    
                    <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
                </div>
                {/* </>
                            } */}
            </div>             
            </div>
          </div>
            </div>

            {/* THIS MODAL IS ONLY INSERT AN CLOSING BALANCE  */}

            <div className="modal" id="closingModal">
                <div className="modal-dialog" style={{textAlign:'center'}}>
                    <div className="modal-content" style={{width:'600px'}}>
            
                        {/* Modal Header */}
                        <div className="modal-header">
                            <h4 className="modal-title" style={{fontWeight:'bold'}}>Date : {moment(fromdate).format('DD-MM-YYYY')}</h4>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                        </div>
              
                        {/* Modal body */}
                        <div className="modal-body">
                            {/* {
                                
                                    checkclosingbalance?
                                    <div><h4>Data is Already Submitted of this Date</h4></div>:
                                    <> */}
                            <div className="wthree_general">                                                                                                                  
                                <div className="grid-1 graph-form agile_info_shadow">    
                                    <form className="form-horizontal">
                                        <div className="form-group">
                                            <label className="col-md-4 control-label" style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Cash Amount</label>
                                                <div className="col-md-4">
                                                    <div className="input-group">							
                                                        <span className="input-group-addon">
                                                            <i className="fa fa-money"></i>
                                                        </span>
                                                        <input type="text" style={{color:'black',fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" readOnly value={parseFloat(totalcash).toFixed(2)}/>
                                                    </div>
                                                </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="col-md-4 control-label" style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Opening Balance</label>
                                                <div className="col-md-4">
                                                    <div className="input-group">							
                                                        <span className="input-group-addon">
                                                            <i className="fa fa-money"></i>
                                                        </span>
                                                        <input type="text" style={{color:'black',fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" readOnly value={parseFloat(checkopeningbalance).toFixed(2)}/>
                                                    </div>
                                                </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="col-md-4 control-label" style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Card Amount</label>
                                            <div className="col-md-4">
                                                <div className="input-group">
                                                    <span className="input-group-addon">
                                                        <i className="fa fa-money"></i>
                                                    </span>
                                                    <input type="text" style={{color:'black',fontWeight:'bold',fontSize:'20px'}} readOnly value={parseFloat(totalcard).toFixed(2)} className="form-control1 icon" id="exampleInputPassword1" />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="col-md-4 control-label"style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Account Amount</label>
                                            <div className="col-md-4">
                                                <div className="input-group input-icon right">
                                                    <span className="input-group-addon">
                                                        <i className="fa fa-money"></i>
                                                    </span>
                                                    <input id="text"  style={{color:'black',fontWeight:'bold',fontSize:'20px'}} value={parseFloat(totalaccount).toFixed(2)}  readOnly className="form-control1 icon" type="text" />
                                                </div>
                                            </div>                                               
                                        </div>          
                                    </form>                              
                                </div>
                            </div>

                            <div className="wthree_general">
								<div className="grid-1 graph-form agile_info_shadow">
                                    <form className="form-horizontal">
                                        
                                        <div className="form-group">
                                            <label className="col-md-4 control-label">Closing Balance</label>
                                            <div className="col-md-4">
                                                <div className="input-group">							
                                                    <span className="input-group-addon">
                                                        <i className="fa fa-money"></i>
                                                    </span>
                                                    
                                                    <input type="text" onChange={(e)=>setclosingbalance(e.target.value)}   style={{fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" />
                                                </div>
                                            </div>
                                        </div>
                                        <div style={{textAlign:'right' }}><Link to='printOpeningBalance'  target={'_blank'} onClick={()=>OpenCashDrawer()}  style={{color:'blue'}}>If You Want to check cash in Cash Drawer??</Link></div>
                                    </form>                                                
                                </div>
                            </div>
                            
                    {/* Modal footer */}
                <div className="modal-footer">
                    
                        <button type="button" onClick={(e) =>ClosingFunction(e)}  className="btn btn" 
                            style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} 
                            data-dismiss="modal"   >Submit Closing</button>    
                   
                    
                    <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
                </div>
                {/* </>
                            } */}
            </div>             
            </div>
          </div>
            </div>
        </>
    )
}

export default AfterSign
