import React, { useEffect } from 'react'
import { Link,useHistory,useParams } from 'react-router-dom'
import { useState } from 'react/cjs/react.development'
import { SelectCustomerById, UpdateCustomerData } from '../Function/customer'
import Footer from './wcommon/footer'

function UpdateCustomerList() {
    const {cust_id} = useParams()
    const [firstname,setfirstname] = useState("")
    const [lastname,setlastname] = useState("")
    const [number,setnumber] = useState("")
    const [email,setemail] = useState("")
    const history = useHistory()

    useEffect(()=>{
        
        loadCustomerId()
    },[])
    

    const loadCustomerId = ()=>{
        
        var req = {
            "cust_id":Number(cust_id)
            
        }

        SelectCustomerById(req).then((res)=>{
            var result = res
            if(result.data !== undefined)
            {
                setfirstname(result.data.name)
                setlastname(result.data.surname)
                setnumber(result.data.phone)
                setemail(result.data.email)
            }
        })
    }

    const submit = (e)=>{

        e.preventDefault()
        var req={
            "cust_id":Number(cust_id),
            "name":firstname,
            "surname":lastname,
            "phone":number,
            "email":email
        }
        
        UpdateCustomerData(req).then((response)=>{
            const result = response
            if(result !== undefined)
            {
                alert(result.message)
            }
            else{
                alert("No")
            }
        }).catch()
        history.goBack()
        // history.push('/GarmentList')
    }

    return (
        <>
        <div className="inner_content" style={{padding:'0rem'}}>
				    {/* /inner_content_w3_agile_info*/}
					<div className="inner_content_w3_agile_info">
					<div style={{textAlign:'center'}}>
						<img style={{width:'25%', height:'150px'}} src='kdtailor.jpeg' alt="logo"/></div>
							<div className="registration admin_agile">
								
												<div className="signin-form profile admin">
													
													<h2>Customer Registeration</h2>
													<div className="login-form">
														<form method="post">
															<input type="text" name="name" value={firstname} placeholder="Enter Firstname" required onChange={(e)=>setfirstname(e.target.value)}/>
															<input type="text" name="lastname" value={lastname} placeholder="Enter Lastname" required onChange={(e)=>setlastname(e.target.value)}/>
                                                            <input type="text" name="number" value={number} placeholder="Enter Phone number" required onChange={(e)=>setnumber(e.target.value)}/>
															<input type="email" name="email" value={email} placeholder="Enter Email" onChange={(e)=>setemail(e.target.value)}/>
															<Link onClick={(e)=>submit(e)} style={{color:'#fff'}}><div className="tp login_button">
																 Update
															</div></Link>
															
														</form>
													</div>
												
												</div>

					

				    </div>
					{/* //inner_content_w3_agile_info*/}
				</div>
		{/* //inner_content*/}
				</div>
                <Footer/>
                </>
    )
}


export default UpdateCustomerList
