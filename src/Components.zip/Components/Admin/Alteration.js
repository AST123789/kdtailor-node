import React, { useEffect } from 'react'
import { Link,useHistory } from 'react-router-dom'
import DryCleaningColors from './DryCLeaningColor'
import GarmentColors from './GarmentColors'
import SideBar from './wcommon/SideBar'

function Alteration() {
    const history = useHistory()
    useEffect(()=>{
        if(!(localStorage.getItem("username"))){
            history.push('/')
            
        }else{
            localStorage.removeItem("customtype")
        }
    },[])

    const color = (e,type)=>{
        localStorage.setItem("customtype",type)
        localStorage.setItem("number",Number(localStorage.getItem("number"))+1)
        e.preventDefault()
    }
    
    return (
        <>
            <SideBar/>
            <div className="buttons_w3ls_agile">
                <div className="button_set_one three one agile_info_shadow">
                    <div id="holder">
                        <Link onClick={(e)=>color(e,"Alteration")} data-toggle="modal" data-target="#colorModal">
                            <div className="button">
                                <p className="btnText">Alteration</p>
                            </div>
                        </Link>
                        <Link onClick={(e)=>color(e,"Dry Cleaning")} data-toggle="modal" data-target="#drycolorModal">
                            <div className="button">
                                <p className="btnText">Dry Cleaning</p>
                            </div>
                        </Link>
                        <Link to="/GarmentList" ><div className="button">
                                <p className="btnText">Cancel</p>
                            </div>
                        </Link>
                    </div>         
               </div>
            </div>
            <GarmentColors/>
            <DryCleaningColors/>
        </>
    )
}

export default Alteration
