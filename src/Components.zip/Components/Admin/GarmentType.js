import React, { useEffect, useState } from 'react'
import { Link, useHistory } from 'react-router-dom'
import Footer from './wcommon/footer'
import Header from './wcommon/header'
import SideBar from './wcommon/SideBar'

function GarmentType() {
    useEffect(()=>{
        if(!(localStorage.getItem("username")))
        {
            history.push('/')            
        }else{
        
        }
        
       
    } , [])

const garmentgetcolor = localStorage.getItem('garmentcolor')
const [id,setid]=useState('');
const history = useHistory();

const selectGarmentType=(idGarment)=>{
    if(idGarment=='pant'){
        localStorage.setItem('idgarment','pant')
        setid(localStorage.getItem('idgarment'))
        // history.push('/PantServices')
       
    }
    else  if(idGarment=='jacket'){
        localStorage.setItem('idgarment','jacket')
        setid(localStorage.getItem('idgarment'))
       
    }
    else  if(idGarment=='jeans'){
        localStorage.setItem('idgarment','jeans')
        setid(localStorage.getItem('idgarment'))
       
    } else  if(idGarment=='leather'){
        localStorage.setItem('idgarment','leather')
        setid(localStorage.getItem('idgarment'))

    }else  if(idGarment=='skirt'){
        localStorage.setItem('idgarment','skirt')
        setid(localStorage.getItem('idgarment'))
    
    }else  if(idGarment=='dress'){
        localStorage.setItem('idgarment','dresses')
        setid(localStorage.getItem('idgarment'))

    }else  if(idGarment=='shirtTop'){
        localStorage.setItem('idgarment','shirtTop')
        setid(localStorage.getItem('idgarment'))
    
    }else  if(idGarment=='other'){
        localStorage.setItem('idgarment','other')
        setid(localStorage.getItem('idgarment'))
    }
}

    return (
        <>
        <SideBar/>
        <Header/>
        <div className="buttons_w3ls_agile " style={{paddingTop: '40px'}}>

            <div className="col-md-12 button_set_one two agile_info_shadow">
                        <div id="">
                            <Link className='col-md-3' to="/JeansServices" onClick={()=>selectGarmentType('jeans')}>
                                <div className="button">
                                    <p className="btnText">Jeans</p>
                                </div>
                            </Link>
                            <Link className='col-md-3' to="/PantServices" onClick={()=>selectGarmentType('pant')}>
                                <div className="button">
                                    <p className="btnText">Pant</p>
                                </div>
                            </Link>
                            <Link className='col-md-3' to="/JacketServices" onClick={()=>selectGarmentType('jacket')}>
                                <div className="button">
                                    <p className="btnText">Jacket</p>
                                </div>
                            </Link>
                            <Link className='col-md-3' to="/leatherServices" onClick={()=>selectGarmentType('leather')}>
                                <div className="button">
                                    <p className="btnText">Leather</p>
                                </div>
                            </Link>
                            <Link className='col-md-3' to="/skirtServices" onClick={()=>selectGarmentType('skirt')}>
                                <div className="button">
                                    <p className="btnText">Skirts</p>
                                </div>
                            </Link>
                            <Link  className='col-md-3' to="/dressServices" onClick={()=>selectGarmentType('dress')}>
                                <div className="button">
                                    <p className="btnText">Dresses</p>
                                </div>
                            </Link>
                            <Link className='col-md-3' to="/shirtTopServices" onClick={()=>selectGarmentType('shirtTop')}>
                                <div className="button">
                                    <p className="btnText">Shirt/Top/T-Shirt</p>
                                </div>
                            </Link>
                            <Link className='col-md-3' to="/otherAlterationServices" onClick={()=>selectGarmentType('other')}>
                                <div className="button">
                                    <p className="btnText">Other</p>
                                </div>
                            </Link>
                            <Link className='col-md-3' to="/GarmentList" >
                                <div className="button">
                                    <p className="btnText">Cancel</p>
                                </div>
                            </Link>
                        </div>                            
                    </div>
        </div>
        
</>
    )
}

export default GarmentType
