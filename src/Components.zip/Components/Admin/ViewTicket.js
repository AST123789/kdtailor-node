import React, { useEffect, useState } from 'react'
import { Link, useHistory } from 'react-router-dom';
import { SelectTicketData } from '../Function/ViewTicket';

function ViewTicket() {

  const [receiptdata , setreceiptdata] = useState([])
  const history = useHistory()

  useEffect(()=>{
    if(!(localStorage.getItem("username"))){
        history.push('/')
    }else{
            loadReceiptData(localStorage.getItem("ticketid"))
        }
  },[])

  const loadReceiptData = (paymentid) =>{
    SelectTicketData(paymentid).then(res=>{
        const result = res;
        if(result!==undefined){
            if((result.data).length===0){
                setreceiptdata([])
               
            }else{
                setreceiptdata(result.data) 
                localStorage.setItem("paymentid",(result.data)[0].payment) 
            }
        }else{
            setreceiptdata([])
            // alert("data not found")
            history.push('/afterSign')
            

        }
    }).catch();
}

  return (
      
    <div className="w3l-table-info agile_info_shadow">
        <table id="table">
            <thead>
                <tr>
                    {/* <th></th> */}
                    <th>Customer Name</th>
                    <th>Order</th>
                    <th>Description</th>
                    <th>Due Date</th>
                    <th>Details</th>
                    <th>Instructions</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                {
                    receiptdata?
                    receiptdata.length>0?
                    receiptdata.map((data)=>{
                    return(
                        <tr key={data.payment_id}>
                        {/* <td><input type="checkbox"/></td> */}
                        <td>{data.customername}</td>
                        <td>{data.orderid}</td>
                        <td>{data.garmentname}<br></br>{data.garmentmiddlename}<br></br>{data.garmentchildname}</td>
                        <td>{data.pickupdate}</td>
                        <td>Garment 1 of 1 /<br></br> Service: 1 of 1</td>
                        <td>{data.instructions?data.instructions:null}</td>
                        <td>{data.status?data.status:null}</td>
                        </tr>
                    )
                    })
                    :<div><img src="loader.gif" alt="loader"/></div>
                    :<div>Data Not Found</div>
                }
            </tbody>
        </table>
        <Link  className="btn btn-info" style={{marginLeft:'20px',background:'#000'}} to="/viewReceipt">Receipt</Link>
        <Link  className="btn btn-info" style={{marginLeft:'20px',background:'#000'}} to="/AfterSign">Cancel</Link>
    </div>
    // </div>
  )
}

export default ViewTicket