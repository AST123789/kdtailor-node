import React, { useEffect, useState } from 'react'
import { useHistory } from 'react-router'
import {UpdatePriceData } from '../Function/Garment'


function DiscountService(props) {

    
    const history = useHistory()
    const [discountcash , setcash] = useState(0)
    const [sum , setsum] = useState('')
    
    useEffect(()=>{
        if(!(localStorage.getItem("username"))){
            history.push('/')
            
        }else{
            setsum(localStorage.getItem('garmentsumprice'))
        }
    },[])

    const UpdatePrice = (e) =>{
        var req = {
            "garmentlistid":Number(localStorage.getItem("garmentid")),
            "garmentdiscount":Number(discountcash),
            "garmentfinalamount":parseFloat(Number(localStorage.getItem('garmentlistprice')-discountcash)).toFixed(2)
        }
        
        UpdatePriceData(req).then(res=>{
            
        })
        window.location.reload()
    }

    return (
        <>
            <div className="modal" id="discountService">
                <div className="modal-dialog" style={{textAlign:'center'}}>
                    <div className="modal-content" style={{width:'600px'}}>
            
                        {/* Modal Header */}
                        <div className="modal-header">
                            <h4 className="modal-title" style={{fontWeight:'bold'}}></h4>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                        </div>
              
                        {/* Modal body */}
                        <div className="modal-body">
                            <div className="wthree_general">
								<div className="grid-1 graph-form agile_info_shadow">
                                    <form className="form-horizontal">
                                        <div className="form-group">
                                            {/* {
                                               category.length>0 ?
                                               category.map((data)=>{
                                                   return(
                                                    <div> <input  value={data} onChange={(e)=>setgarmenttype(e.target.value)} name="check" type="radio"/>{data} </div> 
                                                   )
                                                }):null 
                                                
                                            } */}
                                           <label className="col-md-4 control-label">Discount Amount</label>
                                                <div className="col-md-4">
                                                    <div className="input-group">							
                                                        <span className="input-group-addon">
                                                            <i className="fa fa-money"></i>
                                                        </span>
                                                        <input type="text"  style={{fontWeight:'bold',fontSize:'20px'}} value={discountcash}  className="form-control1 icon" onChange={(e)=>{setcash(e.target.value);setsum(localStorage.getItem('garmentsumprice')-e.target.value)}}/>
                                                    </div>
                                                </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="col-md-4 control-label">Discount Percentage</label>
                                            <div className="col-md-4">
                                                <div className="input-group">							
                                                    <span className="input-group-addon">
                                                        <i className="fa fa-money"></i>
                                                    </span>
                                                    <input type="text"  style={{fontWeight:'bold',fontSize:'20px'}} value={discountcash*100/localStorage.getItem('garmentlistprice')}  className="form-control1 icon" onChange={(e)=>{setcash(e.target.value*localStorage.getItem('garmentlistprice')/100);setsum(localStorage.getItem('garmentlistprice')-e.target.value)}}/>
                                                </div>
                                            </div>
                                        </div>
                                    </form>                                                
                                </div>
                            </div>
                            <div className="wthree_general">                                                                                                                  
                                <div className="grid-1 graph-form agile_info_shadow">    
                                    <form className="form-horizontal">
                                        <div className="form-group">
                                            <label className="col-md-4 control-label" style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Balance</label>
                                                <div className="col-md-4">
                                                    <div className="input-group">							
                                                        <span className="input-group-addon">
                                                            <i className="fa fa-money"></i>
                                                        </span>
                                                        <input type="text" style={{color:'black',fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" readOnly value={parseFloat(localStorage.getItem('garmentlistprice')).toFixed(2)}/>
                                                    </div>
                                                </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="col-md-4 control-label" style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Total Tendered</label>
                                            <div className="col-md-4">
                                                <div className="input-group">
                                                    <span className="input-group-addon">
                                                        <i className="fa fa-money"></i>
                                                    </span>
                                                    <input type="text" style={{color:'black',fontWeight:'bold',fontSize:'20px'}} readOnly className="form-control1 icon" id="exampleInputPassword1" value={parseFloat(Number(discountcash)).toFixed(2)}/>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="col-md-4 control-label"style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Total Due</label>
                                            <div className="col-md-4">
                                                <div className="input-group input-icon right">
                                                    <span className="input-group-addon">
                                                        <i className="fa fa-money"></i>
                                                    </span>
                                                    <input id="text"  style={{color:'black',fontWeight:'bold',fontSize:'20px'}}  readOnly className="form-control1 icon" type="text" value={parseFloat(localStorage.getItem('garmentlistprice')-discountcash).toFixed(2)}/>
                                                </div>
                                            </div>                                               
                                        </div>          
                                    </form>                              
                        </div>
                    </div>
                </div>
                    {/* Modal footer */}
                <div className="modal-footer">
                    <button type="button" onClick={(e)=>UpdatePrice(e) } className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal"   >Ok</button>
                    <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
                </div>
              
            </div>
          </div>
        </div>
</>
    )
}

export default DiscountService
