import React, { useEffect, useState } from 'react'
import { useHistory } from 'react-router'
import { SelectCustomerData } from '../Function/customer'
import moment from 'moment'
import { Link } from 'react-router-dom'

function CustomerDetail() {
    const [customerdata,setcustomerdata] = useState([])
    const history = useHistory()

  useEffect(()=>{
    if(!(localStorage.getItem("username"))){
        history.push('/')
    }else{
            setInterval(loadcustomerData(Number(localStorage.getItem("customerid"))),2000)
        }
  },[])

  const loadcustomerData = (id) =>{
    SelectCustomerData(id).then(res=>{
        const result = res;
        if(result!==undefined){
            if(result==null){
                setcustomerdata([])
            }else{
                setcustomerdata(result.data)
            }
        }else{
            setcustomerdata([])
        }
    }).catch();
    }

    const setid=(e,id)=>{
        localStorage.setItem("paymentid",id) 
    }

    return (
        <div className="modal" id="customerdetail">
            <div className="modal-dialog" style={{textAlign:'center'}}>
                <div className="modal-content" style={{width:'800px'}}>
                    {/* Modal Header */}
                    <div className="modal-header">
                        <h4 className="modal-title">Customer Data</h4>
                        <button type="button" className="close" data-dismiss="modal">&times;</button>
                    </div>
                    {/* Modal body */}
                    <div className="modal-body">
                        <div className="w3l-table-info agile_info_shadow">
                            <table id="table">
                                <thead>
                                    <tr>
                                        <th>Token Number</th>
                                        <th>Order Id</th>
                                        <th>Total amount</th>
                                        <th>Due Amount</th>
                                        <th>Date</th>
                                        {/* <th>Status</th> */}
                                        <th>Receipt</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        customerdata?
                                        customerdata.length>0?
                                        customerdata.map((data)=>{
                                            let date = moment.utc(data.createdate).format('DD/MM/YYYY')
                                        return(
                                            <tr>
                                            <td>{data.payment_id}</td>
                                            <td>{data.orderid}</td>
                                            <td>{parseFloat(data.totalamount).toFixed(2)}</td>
                                            <td>{parseFloat(data.dueamount).toFixed(2)}</td>
                                            <td>{date}</td>
                                            {/* <td>{data.status}</td> */}
                                            <td><Link onClick={(e)=>setid(e,data.payment_id)} className="btn btn-info" style={{marginLeft:'20px',background:'#000'}} to="/viewReceipt">Receipt</Link></td>
                                            </tr>
                                        )
                                        })
                                        :<div>Data not found</div>
                                        :<div>Data not found</div>
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div className="modal-footer">
                    <button onClick={()=>window.location.reload()} type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    )
}


export default CustomerDetail
