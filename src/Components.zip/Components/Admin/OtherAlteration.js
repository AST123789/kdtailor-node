import React, { useEffect,useState } from 'react'
import { Link,useHistory } from 'react-router-dom'
import Model from './wcommon/Model';
import Header from './wcommon/header';
import { OtherAlterationData } from '../Function/OtherAlteration';
import SideBar from './wcommon/SideBar';

function OtherAlterServices() {

   const [alterationtype , setalterationtype]=useState([]);
   const history = useHistory()

   useEffect(()=>{
      if(!(localStorage.getItem("username"))){
         history.push('/')
     }else{
      loadType();
     }
   },[])

   const loadType=()=>{
      OtherAlterationData().then(res=>{
         const result = res;
         if(result!==undefined){
            if(result.data == null){
               setalterationtype([]);
            }else{
               setalterationtype(result.data);
            }
         }else{
            setalterationtype([]);
         }
      }).catch();
   }

   const addgarment = (garmentname,price)=>{

      localStorage.setItem("childgarment",garmentname)
      localStorage.setItem("childprice",price)
   }

    return (
        <>
         <SideBar/>
         <Header/>

        <div className="buttons_w3ls_agile">

            <div id="ChildDiv" className="col-md-8 button_set_one three agile_info_shadow">   
               <h3  className="w3_inner_tittle two"> </h3>

               {
                  alterationtype.map((data)=>{
                     return(
                        <>
                        <button onClick={(e)=>addgarment(data.services_child_name,data.services_child_price)} data-toggle="modal" data-target="#myModal"  class = "btn btn-primary" style={{backgroundColor:'black',margin:"5px",width:'max-content'}}><h5>{data.services_child_name}</h5><br></br><h4>$ {parseFloat(data.services_child_price).toFixed(2)}</h4></button>
                        </>
                        )
                  })
               }

               <div className="clearfix"></div>
            </div>
            

            <div className="col-md-3  button_set_one three one agile_info_shadow">
                    <div id="holder">
                              <div  className="button">
                                    <Link onClick={(e)=>localStorage.setItem("number",Number(localStorage.getItem("number"))-1)} to='/Garmentlist'>
                                       <p className="btnText">Garment List</p>
                                                    
                                    </Link>
                              </div>

                            <div  className="button">
                            <Link to='/GarmentType'>
                                <p className="btnText">Return To Top</p>      
                            </Link>
                            </div>    
                    </div>
            </div>

        </div>

        <Model/>
        </>
    )
}

export default OtherAlterServices
