import React, { useEffect } from 'react'
import { Link,useHistory } from 'react-router-dom'
import { useState } from 'react/cjs/react.development'
import { PantInnerChildServices, PantInnerServices, PantServicesCategoryData } from '../Function/PantService';
import SideBar from './wcommon/SideBar'
import $ from 'jquery'
import Model from './wcommon/Model';
import Header from './wcommon/header';

function PantServices() {
   // localStorage.setItem("garmentlist",JSON.stringify({}))
   const [panttype , setpanttype]=useState([]);
   const history = useHistory()
   useEffect(()=>{
      // $('#MiddleDiv').hide()
      if(!(localStorage.getItem("username"))){
         history.push('/')
         
     }else{
      $('#ChildDiv').hide()
      $('#ChildDiv1').hide()
      loadType();
     }
   },[])

   const loadType=()=>{
      PantServicesCategoryData().then(res=>{
         const result = res;
         if(result!=undefined){
            if(result.data == null){
               setpanttype([]);
            }else{
               setpanttype(result.data);
            }
         }else{
            setpanttype([]);
         }
      }).catch();
   }

   const loadInnerChildServices = (e,middlename)=>{
      e.preventDefault()
      localStorage.setItem("childgarmentname",middlename)
      PantInnerChildServices(middlename).then(res=>{
         const result = res;
         if(result!==undefined){
            if(result.data==null){
               setpanttype([]);
            }else{
               
               setpanttype(result.data);
               
               $('#MiddleDiv').hide()
               $('#ChildDiv').show()
               $('#ChildDiv1').show()
            }
         }else{
            setpanttype([]);
         }
      }).catch();
   }

   const addgarment = (garmentname,price)=>{

      localStorage.setItem("childgarment",garmentname)
      localStorage.setItem("childprice",price)
   }

   const ReturnRequest=(e)=>{
      e.preventDefault()
      setpanttype([])
      $('#ChildDiv').hide()
      $('#ChildDiv1').hide()
      $('#MiddleDiv').show()
      loadType()
   }
    return (
        <>
         <SideBar/>
         <Header/>

      <div className="buttons_w3ls_agile">
      
            {/* <div id="ParentDiv" className="col-md-6 button_set_one three agile_info_shadow">
            
                  
               <h3  className="w3_inner_tittle two"> </h3>

               {
                  panttype.map((data)=>{
                     return(
                        <Link type = "button" onClick={(e)=>loadInnerServices(e,data.services_parent_name)} class = "btn btn-primary" style={{backgroundColor:'black'}}>{data.services_parent_name}</Link>
                     )
                  })
               }

               <div className="clearfix"></div>
            </div> */}

            <div id="MiddleDiv"  className="col-md-8 button_set_one three agile_info_shadow">
            
                  
               <h3  className="w3_inner_tittle two"> </h3>

               {
                  panttype?
                  panttype.length>0?
                  panttype.map((data)=>{
                     return(
                        <Link type = "button" onClick={(e)=>loadInnerChildServices(e,data.services_middle_name)} class = "btn btn-primary" style={{backgroundColor:'black'}}>{data.services_middle_name}</Link>
                     )
                  }):<div style={{textAlign:'center'}}><img src="loader.gif"/></div>
                  :<div>Data Not Found</div>
               }

               <div className="clearfix"></div>
            </div>

            <div id="ChildDiv" className="col-md-8 button_set_one three agile_info_shadow">
            
                  
               <h3  className="w3_inner_tittle two"> </h3>

               {
                  panttype.map((data)=>{
                     return(
                        <>
                        {/* <Link  data-toggle="modal" data-target="#myModal"  class = "btn btn-primary" style={{backgroundColor:'black'}}><h5>{data.services_child_name}</h5><br></br><h4>${data.services_child_price}</h4></Link> */}
                        <button onClick={(e)=>addgarment(data.services_child_name,data.services_child_price)} data-toggle="modal" data-target="#myModal"  class = "btn btn-primary" style={{backgroundColor:'black',margin:"5px",width:'max-content'}}><h5>{data.services_child_name}</h5><br></br><h4>$ {parseFloat(data.services_child_price).toFixed(2)}</h4></button>
                        </>
                        )
                  })
               }

               <div className="clearfix"></div>
            </div>
            

                  <div className="col-md-3  button_set_one three one agile_info_shadow">
                           <div id="holder">

                              <div  className="button">
                                    <Link onClick={(e)=>localStorage.setItem("number",Number(localStorage.getItem("number"))-1)} to='/Garmentlist'>
                                       <p className="btnText">Garment List</p>
                                                    
                                    </Link>
                              </div>
                                 <div  className="button">
                                    <Link to='/GarmentType'>
                                       <p className="btnText">Return To Top</p>
                                                    
                                    </Link>
                                 </div>
                                 <div id="ChildDiv1" className="button" style={{height:'100%'}} >
                                       <Link  onClick={(e)=>ReturnRequest(e)}>
                                             <p className="btnText">Return To Previous Department</p>
                                       </Link>
                                 </div>
                                                
                                                 
                                            
                           </div>
                  </div>

               
               </div>

               <Model/>
        </>
    )
}

export default PantServices
