import React, { useEffect } from 'react'
import { Link ,useHistory} from 'react-router-dom'
import { useState } from 'react/cjs/react.development'
import { Logindata } from '../Function/Login'
import Footer from './wcommon/footer'
import $ from 'jquery'

function MainPage() {

	// const [passcode,setpasscode] = useState("")

	useEffect(()=>{
		// callMac()
		// if(localStorage.getItem("feature")===3){
		// 	localStorage.setItem("feature",0)
		// }
		// $(window).on('load',function(){
		// 	var delayMs = 1500; // delay in milliseconds
		// 	localStorage.setItem("feature",0)
		// 	setTimeout(function(){
		// 		window.$('#passwordpopup').modal('show')
		// 	}, delayMs);
		// }); 
		// closeFullscreen()	
	},[])
	
	//   const openFullscreen = () =>{
	// 	if(passcode==="abhi"){
	// 		localStorage.setItem("feature",1)
	// 		window.$('#passwordpopup').modal('hide')
	// 		var elem = document.documentElement;
			
	// 		if (elem.requestFullscreen) {
	// 			elem.requestFullscreen();
	// 		} else if (elem.webkitRequestFullscreen) {
	// 			elem.webkitRequestFullscreen();
	// 		} else if (elem.msRequestFullscreen) { 
	// 			elem.msRequestFullscreen();
	// 		}
	// 	history.push('/afterSign')
	// 	}
	// 	else{
	// 	}
	// }
	
	// function closeFullscreen() {
	// 	try{
	// 		$(document).bind('fullscreenchange webkitfullscreenchange mozfullscreenchange msfullscreenchange', function (e) {
	// 			var fullscreenElement = document.fullscreenElement || document.webkitFullscreenElement || document.mozFullscreenElement || document.msFullscreenElement;
	// 			if (!fullscreenElement) {
	// 				// let person = prompt("Please enter your name:", "");
	// 				// 	if (person == null || person === "") {
	// 				// 		alert("Contact your administrator")
	// 				// 		localStorage.setItem("feature",0)
	// 				// 		window.location.reload()
	// 				// 	} else {
	// 				// 	  console.log("Done")
	// 				// 	}
	// 				// 	$(window).on('load', function() {
	// 				// 		window.$('#passwordpopup').modal('show');
	// 				// 	});
	// 					window.location.reload()
	// 			} else {
	// 				setenable(1)
	// 			}
	// 			// window.location.reload()
	// 		  });	
	// 	}
	// 	catch(error){
	// 		openFullscreen()
	// 	}
	//   }

		const [username , setusername] = useState("")
		const [password , setpassword] = useState("")
		// const [enable , setenable] = useState(0)

		const history = useHistory()
		const handelRequest = (e,field) =>{
			e.preventDefault()
			if(field==="username"){
				const value = e.target.value
				setusername(value)
			}
			if(field==="password"){
				const value = e.target.value
				setpassword(value)
			}
		}

		const loginRequest = (e) =>{
			e.preventDefault()
			if(username===""){
				return alert("Please enter valid email")
			}
			else if(password===""||password===null){
				return alert("Please enter valid Password")
			}
			getlogin();
		}

		const getlogin = () =>{
			try{
				var req = {
					"username":username,
					"password":password
				}

				Logindata(req).then((res)=>{
					const result=res;
					if(result!==undefined){
						if(result.data.type==='order'){
							localStorage.setItem("username",username)
							history.push('/afterSign')
						}else if(result.data.type==='sales'){
							localStorage.setItem("salesUsername",username)
							history.push('/SalesReport')
						}else if(result.data.type==='management'){
							localStorage.setItem("managementUsername",username)
							history.push('/order-management')
						}
				}else{
						alert("not")
				}
				}).catch()
			}catch (error) {
				console.log(error)
		}
	}

	// if(Number(localStorage.getItem("feature"))===0){
	// 	return(
	// 	<>
	// 		<div className="inner_content" style={{padding:'0rem'}}>
	// 			<div className="inner_content_w3_agile_info">
	// 			<div style={{textAlign:'center'}}>
	// 				<img style={{width:'25%', height:'150px'}} src='kdlogo.png'/>
	// 			</div>
	// 			{/* <div className="button" onClick={(e)=>openFullscreen()}>
	// 				<p className="btnText">Click</p>
	// 			</div> */}
	// 			</div>
	// 		</div>
	// 		<div className="modal" id="passwordpopup" data-backdrop="static" data-keyboard="false">
    //     <div className="modal-dialog" style={{textAlign:'center'}}>
    //         <div className="modal-content" style={{width:'600px'}}>
    //             {/* Modal Header */}
    //             <div className="modal-header">
    //             <h4 className="modal-title"  style={{fontWeight:'bold'}}>Instruction</h4>
    //             <button type="button" className="close" data-dismiss="modal">&times;</button>
    //             </div>
                
    //             {/* Modal body */}
    //             <div className="modal-body">
    //             <input type="password" value={passcode} onChange={(e)=>setpasscode(e.target.value)}  style={{fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" />
    //             </div>
    //                 {/* Modal footer */}
    //             <div className="modal-footer">
    //                 <button type="button" onClick={(e)=>openFullscreen()} className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}}>Open</button>
    //             </div>
    //         </div>
    //     </div>
    // </div>
	// 		{/* <PassPopUp/> */}
	// 	</>
	// 	)
	// }

    return (
        <>
        
			<div className="inner_content" style={{padding:'0rem'}}>
						{/* /inner_content_w3_agile_info*/}
						<div className="inner_content_w3_agile_info">
						<div style={{textAlign:'center'}}>
							<img style={{width:'25%', height:'150px'}} src='kdlogo.png'/></div>
								<div className="registration admin_agile">
									<div className="signin-form profile admin">
										<h2>Admin Login</h2>
										<div className="login-form">
											<form action="main-page.html" method="post">
												<input type="text" name="name" onChange={(e)=>handelRequest(e,"username")} placeholder="Username" required=""/>
												<input type="password" name="password" onChange={(e)=>handelRequest(e,"password")} placeholder="Password" required=""/>
												<Link to="#" onClick={(e)=>loginRequest(e)} style={{color:'#fff'}}><div className="tp login_button">
													LOGIN 
												</div></Link>
												
											</form>
										</div>
									</div>
								</div>
									{/* //inner_content_w3_agile_info*/}
						</div>
			{/* //inner_content*/}
			</div>
			<Footer/>
			{/* <PassPopUp/> */}
			{/* <div class="bodybg">
            <div class="login-page ">
                <div class="login2-body ">
                    <div class="loginflex">	
                        <div class="login-left-pnl">
                            <h4 class="logo-icon"><img src={process.env.PUBLIC_URL + '/images/logo-icon.png'} class="mr-10" alt="Logo-icon"/> Productivity Automated</h4>
                            <div class="logo1">    
                                <h4>Login</h4>
                            </div>
                            <form class="loginform">
                        <div class="form-group ">	  
                            <input type="text" class="form-control loignh" placeholder="Email id"  onChange={(e)=>handelRequest(e,"username")} required/>        
                        </div>
                        <div class="form-group ">		
                            <input type="password" class="form-control loignh" placeholder="Password"  onChange={(e)=>handelRequest(e,"password")} required/>       
                        </div>		
                        <div class="captcha">
                            <div class="spinner">
                                <label>
                                    <input type="checkbox" onclick="$(this).attr('disabled','disabled');"/>
                                    <span class="checkmark"><span>&nbsp;</span></span>
                                </label>
                            </div>
                            <div class="text">
                                I'm not a robot
                            </div>
                            <div class="logo">
                                <img src="https://forum.nox.tv/core/index.php?media/9-recaptcha-png/"/>
                                <p>reCAPTCHA</p>
                                <small>Privacy - Terms</small>
                            </div> 
                        </div>
                        <div class="form-group custom-checkbox">
                        <input type="checkbox" id="html"/>
                        <label for="html">&nbsp; keep me signed in</label>
                        </div>	
                        <div class="">
                            <div class="">
							<Link to="#" onClick={(e)=>loginRequest(e)} style={{color:'#fff'}}><div className="tp login_button btn btn-green btn-block">
								LOGIN 
							</div></Link>
                            <button type="submit" class="btn btn-green btn-block">LOGIN</button>
                            </div>        
                        <div class="login-footer-link">   
                            <span class="text1">Forgot Password?</span>
                            <a href="#">Click here </a>
                            <span class="text2">to reset</span>
                        </div>       
                    </div>
                </form> 
                        </div>

                        <div class="login-right-pnl"><img src={process.env.PUBLIC_URL + '/images/login-img.png'}  alt=""/></div>
                        </div>
                    <div class="dvlby">Developed by - Trioca Technologies Pvt Ltd <img src={process.env.PUBLIC_URL + '/images/edit.png'} alt=""/></div>
                </div>
            </div>	
        </div> */}
		</>
    )
}

export default MainPage
