import React from 'react'

export default function RightSideBar() {
    return (
        <div className="col-md-6  button_set_one three one agile_info_shadow">
                                    
                                
                                            <div id="holder">
                                                <div className="button">
                                                    <p className="btnText">Return To Top</p>
                                                    
                                                 </div>
                                                 <div className="button">
                                                    <p className="btnText">Return To Previous Department</p>
                                                    
                                                 </div>
                                                 <div className="button">
                                                    <p className="btnText">Retrn To Previous Category</p>
                                                    
                                                 </div>
                                                 
                                            
                                            </div>
                                    
                                        
                                </div>
    )
}
