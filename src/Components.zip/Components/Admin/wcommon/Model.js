import React, { useEffect } from 'react'
import { Link,useHistory } from 'react-router-dom';
import { useState } from 'react/cjs/react.development';
import { Insertgarment } from '../../Function/Garment';
import { ServiceModel } from '../../Function/Model'

function Model() {

    const [servicedata , setservicedata] = useState([]);
    const history = useHistory()
    

    useEffect(()=>{
        loadServiceModel();
    },[]);

    const loadServiceModel = ()=>{
        ServiceModel().then(res=>{
            const result = res;
            if(result!==undefined){
               if(result.data == null){
                  setservicedata([]);
               }else{
                  setservicedata(result.data);
               }
            }else{
               setservicedata([]);
            }
        }).catch();
    }
    

    const addgarment = (e,service)=>{
      e.preventDefault()
      var req={}

      if(localStorage.getItem("middlegarment")){
        req = {
          "garmentname":localStorage.getItem("numbergarment")?localStorage.getItem("numbergarment"):localStorage.getItem("number")+"# "+localStorage.getItem("idgarment"),
          "garmentmiddlename":localStorage.getItem("middlegarment")+"/ "+localStorage.getItem("childgarmentname"),
          "garmentchildname":localStorage.getItem("childgarment"),
          "garmentprice":localStorage.getItem("childprice"),
          "garmentcolor":localStorage.getItem("garmentcolor"),
          "service":service,
          "type":localStorage.getItem("customtype"),
          "garmentdiscount":parseFloat(Number(0)).toFixed(2),
          "garmentfinalamount":localStorage.getItem("childprice"),
          "colorcode":localStorage.getItem("colorcode")
        }
      }
      else if(localStorage.getItem("childgarmentname")){
        req = {
          "garmentname":localStorage.getItem("numbergarment")?localStorage.getItem("numbergarment"):localStorage.getItem("number")+"# "+localStorage.getItem("idgarment"),
          "garmentmiddlename":localStorage.getItem("childgarmentname"),
          "garmentchildname":localStorage.getItem("childgarment"),
          "garmentprice":localStorage.getItem("childprice"),
          "garmentcolor":localStorage.getItem("garmentcolor"),
          "service":service,
          "type":localStorage.getItem("customtype"),
          "garmentdiscount":parseFloat(Number(0)).toFixed(2),
          "garmentfinalamount":localStorage.getItem("childprice"),
          "colorcode":localStorage.getItem("colorcode")
        }}
        else{
          req = {
            "garmentname":localStorage.getItem("numbergarment")?localStorage.getItem("numbergarment"):localStorage.getItem("number")+"# "+localStorage.getItem("idgarment"),
            "garmentmiddlename":"other",
            "garmentchildname":localStorage.getItem("childgarment"),
            "garmentprice":localStorage.getItem("childprice"),
            "garmentcolor":localStorage.getItem("garmentcolor"),
            "service":service,
            "type":localStorage.getItem("customtype"),
            "garmentdiscount":parseFloat(Number(0)).toFixed(2),
            "garmentfinalamount":localStorage.getItem("childprice"),
            "colorcode":localStorage.getItem("colorcode")
          }
      }
    
      Insertgarment(req).then(res=>{
        const result = res;
        if(result!==undefined){
           window.$("#myModal").modal("hide");
           history.push("/GarmentList")
        }

      localStorage.removeItem("childgarmentname")  
      localStorage.removeItem("childgarment")  
      localStorage.removeItem("childprice")  
      localStorage.removeItem("middlegarment")
      localStorage.removeItem("garmentcolor")
      localStorage.removeItem("colorcode")
    }).catch();   
    }

    return (
        <>
        {/* The Modal */}
        <div className="modal" id="myModal">
          <div className="modal-dialog">
            <div className="modal-content">
            
              {/* Modal Header */}
              <div className="modal-header">
                <h4 className="modal-title">Modal Services</h4>
                <button type="button" className="close" data-dismiss="modal">&times;</button>
              </div>
              
              {/* Modal body */}
              <div className="modal-body">
                {
                    servicedata.length > 0?
                        servicedata.map((data)=>{
                            return(
                              <tr  >
                                <Link onClick={(e)=>addgarment(e,data.feature)} class = "btn btn" style={{width:'100%',marginBottom:'10px',backgroundColor:'black',color:'white',fontSize:'15px',fontWeight:'bold'}}>{data.feature}</Link>
                                </tr>
                            )
                        })
                    :<div>No data found</div>
                }
              </div>
              
              {/* Modal footer */}
              <div className="modal-footer">
                <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
              </div>
              
            </div>
          </div>
        </div>
        
  </>
      
    )
}

export default Model
