import React from 'react'
import { Link } from 'react-router-dom'
import { TruncateGarmentCategoryData } from '../../Function/Garment'

function SideBar() {
	const logout = ()=>{
		
		if(localStorage.getItem("salesUsername")&&localStorage.getItem("managementUsername")){
			var valuesale = localStorage.getItem("salesUsername")
			var valuemanagement = localStorage.getItem("managementUsername")
			localStorage.clear()
			localStorage.setItem("feature",1)
			localStorage.setItem("salesUsername",valuesale) 
			localStorage.setItem("managementUsername",valuemanagement)
			TruncateGarmentCategoryData().then(res=>{
            
			}).catch();

		}else if(localStorage.getItem("salesUsername")){
			var value = localStorage.getItem("salesUsername")
			localStorage.clear()
			localStorage.setItem("feature",1)
			localStorage.setItem("salesUsername",value) 
			
		}else if(localStorage.getItem("managementUsername")){
			var valuemanage = localStorage.getItem("managementUsername")
			localStorage.clear()
			localStorage.setItem("feature",1)
			localStorage.setItem("managementUsername",valuemanage) 
		}
		else{
			localStorage.clear()
			localStorage.setItem("feature",1)
		}
		TruncateGarmentCategoryData().then(res=>{
            
		}).catch();
	}

    return (
        <div className="wthree_agile_admin_info">
		  {/* /w3_agileits_top_nav*/}
		  {/* /nav*/}
		  <div className="w3_agileits_top_nav">
			<ul id="gn-menu" className="gn-menu-main" >
			  		 {/* /nav_agile_w3l */}
				
				{/* //nav_agile_w3l */}
				<li className="second logo"><div style={{display:'inline-block',width:'100%',height:'100%'}}><Link to='#'><img style={{display:'inline-block',width:'100%',height:'100%'}} src="kdtailor.jpeg" alt="logo"/></Link></div></li>
					
		
				

				
				{/* <li className="second full-screen">
					<section className="full-top">
						<button id="toggle"><i className="fa fa-arrows-alt" aria-hidden="true"></i></button>	
					</section>
				</li> */}
				<li className="second logo"><h1><Link to="/" onClick={(e)=>logout()}><i className="  fa fa-sign-out"></i> Logout</Link> </h1></li>

			</ul>
			{/* //nav */}
			
		</div>
		
		<div className="clearfix"></div>
		{/* //w3_agileits_top_nav*/}
		{/* /inner_content*/}
				<div className="inner_content">
					{/* /social_media*/}
				
						<div className="clearfix"></div>
											  
				  </div>
               
    {/* //inner_content*/}
</div>

    )
}

export default SideBar
