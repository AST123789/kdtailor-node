import React, { useEffect,useState } from 'react'

function PassPopUp() {

useEffect(()=>{
    
},[]);

const [passcode,setpasscode] = useState("")

if(passcode==="jgnvbkl"){
    localStorage.setItem("feature",1)
}
return (
    <>
    <div className="modal" id="passwordpopup" data-backdrop="static" data-keyboard="false">
        <div className="modal-dialog" style={{textAlign:'center'}}>
            <div className="modal-content" style={{width:'600px'}}>
                {/* Modal Header */}
                <div className="modal-header">
                <h4 className="modal-title"  style={{fontWeight:'bold'}}>Instruction</h4>
                <button type="button" className="close" data-dismiss="modal">&times;</button>
                </div>
                
                {/* Modal body */}
                <div className="modal-body">
                <input type="password" value={passcode} onChange={(e)=>setpasscode(e.target.value)}  style={{fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" />
                </div>
                    {/* Modal footer */}
                <div className="modal-footer">
                    {/* <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}}  onClick={(e)=>UpdateGarmentData(e)} data-dismiss="modal">Submit</button> */}
                    <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal" to="/barcodescan">Close</button>
                </div>
            </div>
        </div>
    </div>
    </>
  )
}

export default PassPopUp
