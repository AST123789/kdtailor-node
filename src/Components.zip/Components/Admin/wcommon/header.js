import React, { useEffect } from 'react'

function Header() {

    useEffect(()=>{
        localStorage.setItem("balance",0)
    },[]);
    
    return (
        <div className="row">
        <div className="col-md-2 socail_grid_agile facebook">
        <div className="clearfix"></div>
                    
                    <div className="col-md-4 agile_w3l_social_media_text_img">
                       
                    </div>

                    <h4 style={{paddingBottom:'1px'}}>Customer</h4>
                    <h4 style={{color:'red',fontWeight:'bold',fontSize:'25px',textAlign:'center'}}>{localStorage.getItem("customername")}</h4>
                
                <div className="clearfix"></div>
            </div>

            <div className="col-md-2 socail_grid_agile twitter">        
                <div className="clearfix"></div>
                    
                <div className="col-md-4 agile_w3l_social_media_text_img">
                </div>
                
    
                    <h4 style={{paddingBottom:'1px'}}>Prev. Depo</h4>
                    <h4 style={{color:'red',fontWeight:'bold',fontSize:'25px',textAlign:'center'}}>-{localStorage.getItem("prevpaidamount")}</h4>
                
                
                <div className="clearfix"></div>
            </div>


            <div className="col-md-2 socail_grid_agile gmail">                       
                <div className="clearfix"></div>
                    <div className="bottom_info_social">
                <div className="col-md-4 agile_w3l_social_media_text_img">
                
                </div>
                        <h4>Add Deposit</h4>
                        </div>
                
                <div className="clearfix"></div>
            </div>


            <div className="col-md-2 socail_grid_agile twitter">
                    <div className="clearfix"></div>
                    
                    <div className="col-md-4 agile_w3l_social_media_text_img">
                       
                    </div>
                    
                        <h4 style={{paddingBottom:'1px'}}>Balance </h4>
                        <h4 style={{color:'red',fontWeight:'bold',fontSize:'25px',textAlign:'center'}}>$ {parseFloat(Number(localStorage.getItem("garmentsumprice"))).toFixed(2)}</h4>
                    
                    
                    <div className="clearfix"></div>
            </div>

            <div className="col-md-2 socail_grid_agile gmail">
            <div className="clearfix"></div>
                    
                    <div className="col-md-4 agile_w3l_social_media_text_img">
                       
                    </div>
                <div className="bottom_info_social">
                
                
                    <h4>Due Date</h4>
                    <p></p>
                </div>
                
                <div className="clearfix"></div>
            </div>


            <div className="col-md-2 socail_grid_agile dribble">
            <div className="clearfix"></div>
                    
                    <div className="col-md-4 agile_w3l_social_media_text_img">
                       
                    </div>
                    
                
                    <h4 style={{paddingBottom:'1px'}}>Reference</h4>
                    <h4 style={{color:'red',fontWeight:'bold',fontSize:'25px',textAlign:'center'}}>{localStorage.getItem("refernceid")}</h4>
                
                <div className="clearfix"></div>
            </div>
    </div>
    
    )
}

export default Header
