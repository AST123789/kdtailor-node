import React,{useEffect, useState} from 'react'
import { useHistory } from 'react-router'
import { SelectGarmentList, TruncateGarmentCategoryData } from '../Function/Garment'
import { Deleteorder, Insertorder } from '../Function/Order'
import { Insertpayment, SelectPaymentid, UpdatepaymentDetail } from '../Function/Payment'
import moment from 'moment'

function Payment(props) {

    const history = useHistory()
    const [cash , setcash] = useState(localStorage.getItem("pricecash")?parseFloat(localStorage.getItem("pricecash")).toFixed(2):0)
    const [card, setcard] = useState(localStorage.getItem("pricecard")?parseFloat(localStorage.getItem("pricecard")).toFixed(2):0)
    const [account,setaccount] = useState(localStorage.getItem("priceaccount")?parseFloat(localStorage.getItem("priceaccount")).toFixed(2):0)
    const [sum , setsum] = useState('')
    const [call,setcall] = useState(0)
    const [paymentid , setpaymentid] = useState('');
    const [garmentlist,setgarmentlist] = useState([])
    const [changerupee,setchangerupee] = useState(0)
    const [changeduemode,setchangeduemode] = useState('')
    const d = new Date()

    useEffect(()=>{
        if(!(localStorage.getItem("username"))){
            history.push('/')
        }else{
            loadgarmentlist()
            setsum(localStorage.getItem('garmentsumprice'))
        }
    },[props.list])

    const loadgarmentlist=()=>{
        SelectGarmentList().then(res=>{
           const result = res;
           if(result !== undefined){
              if(result.data == null){
                 setgarmentlist([]);
              }else{
                  setgarmentlist(result.data)
              }
           }else{
               setgarmentlist([])
           }
        }).catch()
    }
    
      // Orders Data
    const SubmitOrderData = ()=>{
        if(localStorage.getItem("ticketid")){
            var req = {
                "customer_id":localStorage.getItem('customerid'),
                "payment_id":localStorage.getItem('ticketid'),
                "totalamount":localStorage.getItem('garmentsumprice'),
                "paidamount":(Number(cash)+Number(card)+Number(account)-Number(changerupee))>Number(localStorage.getItem('garmentsumprice'))?Number(localStorage.getItem('garmentsumprice')):(Number(cash)+Number(card)+Number(account)-Number(changerupee)),
                "dueamount":parseFloat(Number(localStorage.getItem('garmentsumprice')-cash-card-account)).toFixed(2)>=0?parseFloat(Number(localStorage.getItem('garmentsumprice')-cash-card-account)).toFixed(2):0,
                "discount":Number(localStorage.getItem("discount")),
                "totalgarmentamount":Number(localStorage.getItem("totalgarmentprice")),
                "date":String(moment(d).format('YYYY-MM-DD')),
                "cash":Number(localStorage.getItem('garmentsumprice')-cash-card-account)>=0?Number(cash):Number(cash)+Number(localStorage.getItem('garmentsumprice')-cash-card-account),
                "card":Number(card),
                "account":Number(account),
                "changedue":Number(localStorage.getItem('prevpaidamount')-localStorage.getItem('garmentsumprice'))>0?parseFloat(Math.abs(Number(localStorage.getItem('prevpaidamount')-localStorage.getItem('garmentsumprice')))).toFixed(2):0,
                "changeduemode":changeduemode,
                "alteration_value":Number(localStorage.getItem("alteration_sum")),
                "drycleaning_value":Number(localStorage.getItem("drycleaning_sum")),
            }
            
            UpdatepaymentDetail(req).then(res=>{
                if(res!==undefined){
                }
            }).catch();
            
            Deleteorder().then(res=>{
                if(res!==undefined){
                }
            }).catch();
        }
        else{
            var req = {
                "customer_id":localStorage.getItem('customerid'),
                "totalamount":localStorage.getItem('garmentsumprice'),
                "paidamount":(Number(cash)+Number(card)+Number(account))>Number(localStorage.getItem('garmentsumprice'))?Number(localStorage.getItem('garmentsumprice')):(Number(cash)+Number(card)+Number(account)),
                "dueamount":parseFloat(Number(localStorage.getItem('garmentsumprice')-cash-card-account)).toFixed(2)>=0?parseFloat(Number(localStorage.getItem('garmentsumprice')-cash-card-account)).toFixed(2):0,
                "discount":Number(localStorage.getItem("discount")),
                "totalgarmentamount":Number(localStorage.getItem("totalgarmentprice")),
                "date":String(moment(d).format('YYYY-MM-DD')),
                "cash":Number(localStorage.getItem('garmentsumprice')-cash-card-account)>=0?Number(cash):Number(cash)+Number(localStorage.getItem('garmentsumprice')-cash-card-account),
                "card":Number(card),
                "account":Number(account),
                "alteration_value":Number(localStorage.getItem("alteration_sum")),
                "drycleaning_value":Number(localStorage.getItem("drycleaning_sum")),
            }
           
            Insertpayment(req).then(res=>{
                if(res!==undefined){
                }
            }).catch();
        }
        
        setTimeout(function(){
            selectPaymentDetailAfterSeconds()
        },2000);
        
        TruncateGarmentCategoryData().then(res=>{
            
        }).catch();
        setcall(1)
    }

    const selectPaymentDetailAfterSeconds = ()=>{
        SelectPaymentid().then(res=>{
            const result = res;
            if(result!==undefined){
                if(result==null){
                    setpaymentid('');     
                }else{
                    setpaymentid(result.data.payment_id);
                    localStorage.setItem('paymentid',result.data.payment_id) 
                   
                    for(let i=0;i<garmentlist.length;i++){
                        var req={
                            "customername":localStorage.getItem("customername"),
                            "customerid":localStorage.getItem("customerid"),
                            "garmentname":garmentlist[i].garmentname,
                            "garmentmiddlename":garmentlist[i].garmentmiddlename,
                            "garmentchildname":garmentlist[i].garmentchildname,
                            "garmentprice":garmentlist[i].garmentchildprice,
                            "garmentcolor":garmentlist[i].color,
                            "pickupdate":localStorage.getItem("pickupdate"),
                            "pickupday":localStorage.getItem("pickupday"),
                            "garmentstatus":"",
                            "service":garmentlist[i].services,
                            "instruction":garmentlist[i].instructions,
                            "type":garmentlist[i].type,
                            "date":String(moment(d).format('YYYY-MM-DD')),
                            "pricediscount":garmentlist[i].pricediscount,
                            "garmentfinalamount":garmentlist[i].garmentfinalamount,
                            "reference_id":garmentlist[i].reference_id?garmentlist[i].reference_id:localStorage.getItem("refernceid"),
                            "pickuptime":localStorage.getItem("pickuptime"),
                            "colorcode":garmentlist[i].colorcode,
                            "payment_id":localStorage.getItem("ticketid")?Number(localStorage.getItem("ticketid")):result.data.payment_id
                        }
                        Insertorder(req).then(res=>{
                            const result = res;
                            if(result!==undefined){
                    }
                        }).catch();
                    }
                    history.push('/receipt')
                }
                
            }else{
                setpaymentid('');
            }
        }).catch();
    }

    return (
        <>
            <div className="modal" id="payment">
                <div className="modal-dialog" style={{textAlign:'center'}}>
                    <div className="modal-content" style={{width:'600px'}}>
                    
                        {/* Modal Header */}
                        <div className="modal-header">
                            <h4 className="modal-title" style={{fontWeight:'bold'}}>Tender Information</h4>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                        </div>
                    
                        {/* Modal body */}
                        <div className="modal-body">
                            {
                                localStorage.getItem("customername") && localStorage.getItem("pickupdate") && localStorage.getItem("pickuptime")?(
                                <>
                                    <div className="wthree_general">									
                                        <div className="grid-1 graph-form agile_info_shadow">
                                            <form className="form-horizontal">
                                                    <div className="form-group">
                                                        <label className="col-md-4 control-label">Cash</label>
                                                        <div className="col-md-4">
                                                            <div className="input-group">							
                                                                <span className="input-group-addon">
                                                                    <i className="fa fa-money"></i>
                                                                </span>
                                                                <input type="text"  style={{fontWeight:'bold',fontSize:'20px'}} value={cash} className="form-control1 icon" onChange={(e)=>{setcash(e.target.value);setsum(localStorage.getItem('garmentsumprice')-e.target.value-card-account)}}/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="col-md-4 control-label">Card</label>
                                                        <div className="col-md-4">
                                                            <div className="input-group">							
                                                                <span className="input-group-addon">
                                                                    <i className="fa fa-money"></i>
                                                                </span>
                                                                <input type="text"  style={{fontWeight:'bold',fontSize:'20px'}} value={card} className="form-control1 icon" onChange={(e)=>{setcard(e.target.value);setsum(localStorage.getItem('garmentsumprice')-e.target.value-cash-account)}}/>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div className="form-group">
                                                        <label className="col-md-4 control-label">Account</label>
                                                        <div className="col-md-4">
                                                            <div className="input-group">							
                                                                <span className="input-group-addon">
                                                                    <i className="fa fa-money"></i>
                                                                </span>
                                                                <input type="text"  style={{fontWeight:'bold',fontSize:'20px'}} value={account} className="form-control1 icon" onChange={(e)=>{setaccount(e.target.value);setsum(localStorage.getItem('garmentsumprice')-e.target.value-cash-card)}}/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    {
                                                        localStorage.getItem("ticketid")?<>
                                                        <div className="form-check form-check-inline">
                                                            <input className="form-check-input" type="radio" id="inlineRadio1" value="cash" onChange={(e)=>setchangeduemode(e.target.value)}/>
                                                            <label className="form-check-label" for="inlineRadio1">Cash</label>
                                                        </div>
                                                        <div className="form-check form-check-inline">
                                                            <input className="form-check-input" type="radio" id="inlineRadio2" value="card" onChange={(e)=>setchangeduemode(e.target.value)}/>
                                                            <label className="form-check-label" for="inlineRadio2">Card</label>
                                                        </div>
                                                        <div className="form-check form-check-inline">
                                                            <input className="form-check-input" type="radio" id="inlineRadio3" value="account" onChange={(e)=>setchangeduemode(e.target.value)}/>
                                                            <label className="form-check-label" for="inlineRadio3">Account</label>
                                                        </div>
                                                        <div className="form-group">
                                                            <label className="col-md-4 control-label">Return Amount</label>
                                                            <div className="col-md-4">
                                                                <div className="input-group">							
                                                                    <span className="input-group-addon">
                                                                        <i className="fa fa-money"></i>
                                                                    </span>
                                                                    <input type="text" readOnly style={{fontWeight:'bold',fontSize:'20px'}} value={Number(localStorage.getItem('prevpaidamount')-localStorage.getItem('garmentsumprice'))>0?parseFloat(Math.abs(Number(localStorage.getItem('prevpaidamount')-localStorage.getItem('garmentsumprice')))).toFixed(2):0} className="form-control1 icon" onChange={(e)=>{setchangerupee(e.target.value)}}/>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        </>:null
                                                    }
                                                </form>
                                        
                                        </div>
                                    </div>
                                    <div className="wthree_general">                                               
                                        <div className="grid-1 graph-form agile_info_shadow">
                                            <form className="form-horizontal">
                                                    <div className="form-group">
                                                        <label className="col-md-4 control-label"style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Balance</label>
                                                        <div className="col-md-4">
                                                            <div className="input-group">							
                                                                <span className="input-group-addon">
                                                                    <i className="fa fa-money"></i>
                                                                </span>
                                                                <input type="text" style={{color:'black',fontWeight:'bold',fontSize:'20px'}}  className="form-control1 icon" readOnly value={parseFloat(localStorage.getItem('garmentsumprice')).toFixed(2)}/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="col-md-4 control-label"style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Total Tendered</label>
                                                        <div className="col-md-4">
                                                            <div className="input-group">
                                                                <span className="input-group-addon">
                                                                    <i className="fa fa-money"></i>
                                                                </span>
                                                                <input type="text" style={{color:'black',fontWeight:'bold',fontSize:'20px'}} readOnly className="form-control1 icon" id="exampleInputPassword1" value={parseFloat(Number(cash)+Number(card)+Number(account)).toFixed(2)}/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    {parseFloat(Number(localStorage.getItem('garmentsumprice')-cash-card-account)).toFixed(2)>=0?
                                                    <div className="form-group">
                                                        <label className="col-md-4 control-label"style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Total Due</label>
                                                        <div className="col-md-4">
                                                            <div className="input-group input-icon right">
                                                                <span className="input-group-addon">
                                                                    <i className="fa fa-money"></i>
                                                                </span>
                                                                <input id="text"  style={{color:'black',fontWeight:'bold',fontSize:'20px'}}  readOnly className="form-control1 icon" type="text"  value={parseFloat(Number(localStorage.getItem('garmentsumprice')-cash-card-account-changerupee)).toFixed(2)}/>
                                                            </div>
                                                            
                                                        </div>
                                                    </div> :
                                                    <div className="form-group">
                                                        <label className="col-md-4 control-label"style={{fontWeight:"600",fontSize:"1.1em",color:"#000"}}>Change Rupee</label>
                                                        <div className="col-md-4">
                                                            <div className="input-group input-icon right">
                                                                <span className="input-group-addon">
                                                                    <i className="fa fa-money"></i>
                                                                </span>
                                                                <input id="text"  style={{color:'black',fontWeight:'bold',fontSize:'20px'}}  readOnly className="form-control1 icon" type="text"  value={parseFloat(Math.abs(Number(localStorage.getItem('garmentsumprice')-cash-card-account))).toFixed(2)}/>
                                                            </div>
                                                            
                                                        </div>
                                                        
                                                    </div> 
                                                    }
                                                        
                                            </form>
                                        </div>
                                    </div>
                                </>
                                )
                                :
                                <div>Please select customer or pickup time</div>
                            } 
                        </div>

                        {/* Modal footer */}
                        <div className="modal-footer">
                            {
                                localStorage.getItem("customerid") && localStorage.getItem("pickupdate") && localStorage.getItem("pickuptime")?   
                                <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal" onClick={(e)=>SubmitOrderData()}>Ok</button>
                                :null
                            }
                                <button type="button" className="btn btn" style={{backgroundColor:'black',color:'white',marginRight:'10px',fontSize:'15px',fontWeight:'bold'}} data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Payment
