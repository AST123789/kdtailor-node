import {toast} from 'react-toastify'

const API_Base_Url = process.env.REACT_APP_API_BASE_URL;


export const Insertorder = async (req) => {
    // alert(JSON.stringify(reqdata))
    try {
        const response = await fetch(API_Base_Url + "insertorder", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                
                "customername":req.customername,
                "customerid":req.customerid,
                "garmentname":req.garmentname,
                "garmentmiddlename":req.garmentmiddlename,
                "garmentchildname":req.garmentchildname,
                "garmentprice":req.garmentprice,
                "garmentcolor":req.garmentcolor,
                "pickupdate":req.pickupdate,
                "pickupday":req.pickupday,
                "garmentstatus":req.garmentstatus,
                "service":req.service,
                "instruction":req.instruction,
                "type":req.type,
                "date":req.date,
                "pricediscount":req.pricediscount,
                "garmentfinalamount":req.garmentfinalamount,
                "colorcode":req.colorcode,
                "reference_id":req.reference_id,
                "pickuptime":req.pickuptime,
                "payment_id":req.payment_id
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {
    
            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }
};

export const Selectorder = async (req) => {
    //alert(JSON.stringify(reqdata))
    try {
        const response = await fetch(API_Base_Url + "selectOrderList", {
            method: "GET",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            }  
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {
    
            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }
};

export const Updateorder = async (req) => {
    //alert(JSON.stringify(reqdata))
    try {
        const response = await fetch(API_Base_Url + "updateOrder", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                
                "orderid":req.orderid,
                "status":req.status
               
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {
    
            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }
};

export const Deleteorder = async () => {
    // alert(localStorage.getItem('ticketid'))
    try {
        const response = await fetch(API_Base_Url + "deleteorder", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                "payment_id":Number(localStorage.getItem('ticketid'))
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {
    
            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }
};