import {toast} from 'react-toastify'

const API_Base_Url = process.env.REACT_APP_API_BASE_URL;

export const InsertOpeningClosingBalance = async (req) => {
    // alert(JSON.stringify(reqdata))
    try {
        const response = await fetch(API_Base_Url + "insertOpeningBalance", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                
                "date":req.date,
                "openingbalance":req.openingbalance
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {

            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }
};

export const UpdateClosingBalance = async (req) => {
    // alert(JSON.stringify(reqdata))
    try {
        const response = await fetch(API_Base_Url + "updateClosingBalance", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                
                "date":req.date,
                "closingbalance":req.closingbalance
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {

            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }
};


export const SelectOpeningClosingBalance = async (req) => {
    try {
        const response = await fetch(API_Base_Url + "selectOpeningBalance", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                
                "date":req.date,
               
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {

            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }
};

export const SelectBalance = async (req) => {
    try {
        const response = await fetch(API_Base_Url + "selectBalance", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                "date":req.date,
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {

            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }
};