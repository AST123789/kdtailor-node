import {toast} from 'react-toastify'

const API_Base_Url = process.env.REACT_APP_API_BASE_URL;

export const Logindata = async(req)=>{

    try{
        const response = await fetch(API_Base_Url+'Logindata',{
            method: "POST",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body:JSON.stringify({
                "username":req.username,
                "password":req.password
            })
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
            if(result.status==='Fail'){
                alert(result.message)
                
            }
            return result;
        }
        else if(response.status===400){
            alert(result.data)
        }
        

    } catch(error){
        toast.error('Something went wrong , Please try again')
    }
};