import {toast} from 'react-toastify'

const API_Base_Url = process.env.REACT_APP_API_BASE_URL;


export const Insertpayment = async (req) => {
    //alert(JSON.stringify(reqdata))
    try {
        const response = await fetch(API_Base_Url + "insertpayment", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                
                "customer_id":req.customer_id,
                "totalamount":req.totalamount,
                "paidamount":req.paidamount,
                "dueamount":req.dueamount,
                "discount":req.discount,
                "totalgarmentamount":req.totalgarmentamount,
                "date":req.date,
                "cash":req.cash,
                "card":req.card,
                "account":req.account,
                "alteration_value":req.alteration_value,
                "drycleaning_value":req.drycleaning_value
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {
            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }   
};

export const UpdatepaymentDetail = async (req) => {
    // alert(req.changedue)
    try {
        const response = await fetch(API_Base_Url + "updatepayment", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                "customerid":req.customer_id,
                "payment_id":req.payment_id,
                "totalamount":req.totalamount,
                "paidamount":req.paidamount,
                "dueamount":req.dueamount,
                "discount":req.discount,
                "totalgarmentamount":req.totalgarmentamount,
                "date":req.date,
                "cash":req.cash,
                "card":req.card,
                "account":req.account,
                "changedue":req.changedue,
                "changeduemode":req.changeduemode,
                "alteration_value":req.alteration_value,
                "drycleaning_value":req.drycleaning_value
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {

            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }   
};

export const SelectPaymentid= async()=>{
    try{
        const response = await fetch(API_Base_Url+'selectpaymentid',{
            method: "GET",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
            return result;
        }
        else if(response.status===400){
            toast.error(result.error[0])
        }
        else{

        }

    } catch(error){
        toast.error('Something went wrong , Please try again')
    }
}

export const Updatepayment = async (req) => {
    try {
        const response = await fetch(API_Base_Url + "updatepaymentdata", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                "payment_id":req.payment_id,
                "paidamount":req.paidamount,
                "pickamount":req.pickamount,
                "dueamount":req.dueamount,
                "status":req.status,
                "cash":req.cash,
                "card":req.card,
                "account":req.account,
                "pickcash":req.pickcash,
                "pickcard":req.pickcard,
                "pickaccount":req.pickaccount,
                "pickdate":req.pickdate
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {
            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }   
};

export const UpdateOrderId = async (req) => {
    // alert("Updated")
    try {
        const response = await fetch(API_Base_Url + "updateorderid", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                
                "payment_id":req.payment_id,
                "orderid":req.orderid
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {
            
            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }   
};

export const DeletePayment = async (req) => {
    try {
        const response = await fetch(API_Base_Url + "deletepayment", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                "payment_id":localStorage.getItem("ticketid"),
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {
            
            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }   
};