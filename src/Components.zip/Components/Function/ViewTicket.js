import {toast} from 'react-toastify'
import { useHistory } from 'react-router';

const API_Base_Url = process.env.REACT_APP_API_BASE_URL;

export const SelectTicketData = async(id)=>{
    try{
        const response = await fetch(API_Base_Url+'viewticket',{
            method: "POST",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body:JSON.stringify({
                "OrderId":id
            })
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
            
            return result;
        }
        else if(response.status===400){
            alert(result.message)
        }
        else{

        }

    } catch(error){
        alert('Something went wrong , Please try again')
    }
};

export const InsertCustomerData= async(req)=>{
    const history = useHistory()

    try{
        const response = await fetch(API_Base_Url+'insertcustomer',{
            method: "POST",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body:JSON.stringify({
                "name":req.name,
                "surname":req.surname,
                "phone":req.phone,
                "email":req.email
            })
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
            
            return result;
        }
        else if(response.status===400){
            alert(result.message)
            
            history.push('/afterSign')
        }
        else{

        }

    } catch(error){
        toast.error('Something went wrong , Please try again')
    }
};