import {toast} from 'react-toastify'

const API_Base_Url = process.env.REACT_APP_API_BASE_URL;


export const DeleteGarment = async (id) => {
    //alert(JSON.stringify(reqdata))
    try {
        const response = await fetch(API_Base_Url + "deleteservicegarment", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                "garmentlistid":id
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {

            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }
};


export const DeleteGarmentCategoryData = async (name) => {
    
    try {
        const response = await fetch(API_Base_Url + "deletegarmentlistdata", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                "garmentname":name
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {

            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }
};


export const TruncateGarmentCategoryData = async (name) => {
    
    try {
        const response = await fetch(API_Base_Url + "truncategarmentlistdata", {
            method: "GET",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            }
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {

            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }
};


export const SelectGarmentList = async()=>{

    try{
        const response = await fetch(API_Base_Url+'selectgarmentlist',{
            method: "GET",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            }
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
;
            return result;
        }
        else if(response.status===400){
            toast.error(result.message)
        }
        else{

        }

    } catch(error){
        toast.error('Something went wrong , Please try again')
    }
};


export const SelectGarmentOnHoldList = async()=>{

    try{
        const response = await fetch(API_Base_Url+'selectOnholdlist',{
            method: "GET",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            }
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
;
            return result;
        }
        else if(response.status===400){
            toast.error(result.message)
        }
        else{

        }

    } catch(error){
        toast.error('Something went wrong , Please try again')
    }
};

export const Insertgarment = async (req) => {

    try {
        const response = await fetch(API_Base_Url + "insertgarment", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                // 'Authorization': 'Bearer ' + this.state.AccessToken
            },
            body:JSON.stringify({
                "garmentname":req.garmentname,
                "garmentmiddlename":req.garmentmiddlename,
                "garmentchildname":req.garmentchildname,
                "garmentprice":req.garmentprice,
                "garmentcolor":req.garmentcolor,
                "service":req.service,
                "type":req.type,
                "garmentdiscount":req.garmentdiscount,
                "garmentfinalamount":req.garmentfinalamount,
                "colorcode":req.colorcode
            })
            
        })
        if (response.status === 401) {
            toast.error('Your Session has been expired, Please login again.');
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href = "/#/";
            }, 1000);
        }
        const result = await response.json();
        if (response.ok) {

            return result;
        }
        else if (response.status === 400) {
            toast.error(result.errors[0])
        }
        else {

        }
    } catch (error) {
        toast.error('Something went wrong , Please try again later.')
    }
};

export const Updategarment = async (req) => {
    
        try {
            const response = await fetch(API_Base_Url + "updateinstruction", {
                method: "POST",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                    // 'Authorization': 'Bearer ' + this.state.AccessToken
                },
                body:JSON.stringify({
                    "garmentid":req.garmentid,
                    "instruction":req.instruction
                })
                
            })
            if (response.status === 401) {
                toast.error('Your Session has been expired, Please login again.');
                return window.setTimeout(function () {
                    localStorage.clear();
                    window.location.href = "/#/";
                }, 1000);
            }
            const result = await response.json();
            if (response.ok) {
    
                return result;
            }
            else if (response.status === 400) {
                toast.error(result.errors[0])
            }
            else {
    
            }
        } catch (error) {
            toast.error('Something went wrong , Please try again later.')
        }
    };

    export const Updateholddata = async (req) => {
        
            try {
                const response = await fetch(API_Base_Url + "updateholddata", {
                    method: "POST",
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                        // 'Authorization': 'Bearer ' + this.state.AccessToken
                    },
                    body:JSON.stringify({
                        "hold":req.hold,
                        "customerid":localStorage.getItem("customerid"),
                        "customername":localStorage.getItem("customername")
                    })
                    
                })
                if (response.status === 401) {
                    toast.error('Your Session has been expired, Please login again.');
                    return window.setTimeout(function () {
                        localStorage.clear();
                        window.location.href = "/#/";
                    }, 1000);
                }
                const result = await response.json();
                if (response.ok) {
        
                    return result;
                }
                else if (response.status === 400) {
                    toast.error(result.errors[0])
                }
                else {
        
                }
            } catch (error) {
                toast.error('Something went wrong , Please try again later.')
            }
        };

        export const UpdateUnholddata = async (req) => {
                try {
                    
                    const response = await fetch(API_Base_Url + "updateunholddata", {
                        method: "POST",
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                            // 'Authorization': 'Bearer ' + this.state.AccessToken
                        },
                        body:JSON.stringify({
                            "customerid":req.customerid,
                            "hold":req.hold
                        })
                        
                    })
                    if (response.status === 401) {
                        toast.error('Your Session has been expired, Please login again.');
                        return window.setTimeout(function () {
                            localStorage.clear();
                            window.location.href = "/#/";
                        }, 1000);
                    }
                    const result = await response.json();
                    if (response.ok) {
            
                        return result;
                    }
                    else if (response.status === 400) {
                        toast.error(result.errors[0])
                    }
                    else {
            
                    }
                } catch (error) {
                    toast.error('Something went wrong , Please try again later.')
                }
            };

    export const UpdatePriceData = async (req) => {
        //    alert(req.instruction)
            try {
                
                const response = await fetch(API_Base_Url + "updateprice", {
                    method: "POST",
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                        // 'Authorization': 'Bearer ' + this.state.AccessToken
                    },
                    body:JSON.stringify({
                        "garmentlistid":req.garmentlistid,
                        "garmentdiscount":req.garmentdiscount,
                        "garmentfinalamount":req.garmentfinalamount
                    })
                    
                })
                if (response.status === 401) {
                    toast.error('Your Session has been expired, Please login again.');
                    return window.setTimeout(function () {
                        localStorage.clear();
                        window.location.href = "/#/";
                    }, 1000);
                }
                const result = await response.json();
                if (response.ok) {
        
                    return result;
                }
                else if (response.status === 400) {
                    toast.error(result.errors[0])
                }
                else {
        
                }
            } catch (error) {
                toast.error('Something went wrong , Please try again later.')
            }
        };


        export const SelectPriceById = async (garmentlistid) => {
            //    alert(req.instruction)
                try {
                    const response = await fetch(API_Base_Url + "selectgarmentPriceById", {
                        method: "POST",
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                            // 'Authorization': 'Bearer ' + this.state.AccessToken
                        },
                        body:JSON.stringify({
                            "garmentlistid":garmentlistid,
                            
                        })
                        
                    })
                    if (response.status === 401) {
                        toast.error('Your Session has been expired, Please login again.');
                        return window.setTimeout(function () {
                            localStorage.clear();
                            window.location.href = "/#/";
                        }, 1000);
                    }
                    const result = await response.json();
                    if (response.ok) {
            
                        return result;
                    }
                    else if (response.status === 400) {
                        toast.error(result.errors[0])
                    }
                    else {
            
                    }
                } catch (error) {
                    toast.error('Something went wrong , Please try again later.')
                }
            };