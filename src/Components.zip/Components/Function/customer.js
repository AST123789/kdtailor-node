import {toast} from 'react-toastify'

const API_Base_Url = process.env.REACT_APP_API_BASE_URL;

export const SelectCustomerList = async()=>{

    try{
        const response = await fetch(API_Base_Url+'showCustomer',{
            method: "GET",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            }
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
            return result;
        }
        else if(response.status===400){
            toast.error(result.error[0])
        }
        else{

        }

    } catch(error){
        toast.error('Something went wrong , Please try again')
    }
};

export const InsertCustomerData= async(req)=>{

    try{
        const response = await fetch(API_Base_Url+'insertcustomer',{
            method: "POST",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body:JSON.stringify({
                "name":req.name,
                "surname":req.surname,
                "phone":req.phone,
                "email":req.email
            })
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
            return result;
        }
        else if(response.status===400){
            toast.error(result.error[0])
        }
        else{

        }

    } catch(error){
        toast.error('Something went wrong , Please try again')
    }
};

export const SelectCustomerData= async(id)=>{
    // alert(localStorage.getItem("customerid"))
    try{
        const response = await fetch(API_Base_Url+'customertokendetails',{
            method: "POST",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body:JSON.stringify({
                "customer_id":id
            })
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
            return result;
        }
        else if(response.status===400){
            toast.error(result.error[0])
        }
        else{

        }

    } catch(error){
        toast.error('Something went wrong , Please try again')
    }
};


export const UpdateCustomerData= async(req)=>{

    try{
        const response = await fetch(API_Base_Url+'updateCustomer',{
            method: "POST",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body:JSON.stringify({
                "cust_id":req.cust_id,
                "name":req.name,
                "surname":req.surname,
                "phone":req.phone,
                "email":req.email
            })
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
            return result;
        }
        else if(response.status===400){
            toast.error(result.error[0])
        }
        else{

        }

    } catch(error){
        toast.error('Something went wrong , Please try again')
    }
};

export const SelectCustomerById= async(req)=>{
    
    // alert(localStorage.getItem("customerid"))
    try{
        const response = await fetch(API_Base_Url+'selectcustomerbyid',{
            method: "POST",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body:JSON.stringify({
                "cust_id":req.cust_id
            })
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
            return result;
        }
        else if(response.status===400){
            toast.error(result.error[0])
        }
        else{

        }

    } catch(error){
        toast.error('Something went wrong , Please try again')
    }
};
