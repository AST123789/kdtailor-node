import {toast} from 'react-toastify'

const API_Base_Url = process.env.REACT_APP_API_BASE_URL;

export const JeansServicesCategoryData = async()=>{

    try{
        const response = await fetch(API_Base_Url+'/selectjeans',{
            method: "GET",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            }
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
        
            return result;
        }
        else if(response.status===400){
            toast.error(result.error[0])
        }
        else{

        }

    } catch(error){
        toast.error('Something went wrong , Please try again')
    }
} 

export const PantInnerServices = async(parentServices)=>{
    try{
        const response = await fetch(API_Base_Url+'/selectmiddlepant',{
            method: "POST",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body:JSON.stringify({
                "pant_service":parentServices
            })
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
        
            return result;
        }
        else if(response.status===400){
            toast.error(result.error[0])
        }
        else{

        }

    } catch(error){
        toast.error('Something went wrong , Please try again')
    }
}


export const JeansInnerChildServices = async(middleServices)=>{
    try{
        const response = await fetch(API_Base_Url+'selectchildjeans',{
            method: "POST",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body:JSON.stringify({
                "jeans_middle_service":middleServices
            })
        })
        if(response.status===401){
            toast.error('Your Session has been Expired')
            return window.setTimeout(function () {
                localStorage.clear();
                window.location.href='/#/';
            },1000);
        }
        const result = await response.json();
        if(response.ok){
        
            return result;
        }
        else if(response.status===400){
            toast.error(result.error[0])
        }
        else{

        }

    } catch(error){
        toast.error('Something went wrong , Please try again')
    }
}